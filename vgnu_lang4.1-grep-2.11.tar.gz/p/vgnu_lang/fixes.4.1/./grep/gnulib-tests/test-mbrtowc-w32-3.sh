#!/bin/sh

# Test a CP932 locale.
./test-mbrtowc-w32${EXEEXT} Japanese_Japan 932
