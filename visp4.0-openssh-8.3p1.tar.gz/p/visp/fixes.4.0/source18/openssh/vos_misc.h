/*  +++begin copyright+++ *******************************  */
/*                                                         */
/*  STRATUS CONFIDENTIAL INFORMATION                       */
/*  COPYRIGHT (c) 2017 Stratus Technologies Bermuda Ltd.   */
/*  All Rights Reserved.                                   */
/*                                                         */
/*  This  program  contains  confidential and proprietary  */
/*  information of Stratus Technologies Bermuda Ltd., and  */
/*  any reproduction, disclosure, or use in whole  or  in  */
/*  part  is  expressly  prohibited,  except  as  may  be  */
/*  specifically authorized by prior written agreement or  */
/*  permission of Stratus.                                 */
/*                                                         */
/*  +++end copyright+++ *********************************  */

#define   CHECK_FILE          0
#define   CHECK_DEFAULT_ACL   1
#define   CHECK_DIR           2
#define   MAX_INDEXSTR        32
#define   MAX_PATH 256

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <os_return_codes.incl.c>

#include "log.h"
#include "xmalloc.h"

typedef char_varying(MAX_PATH) path_cv;
typedef char_varying(66) module_cv;
typedef char_varying(66) disk_cv;
typedef char_varying(32) name_cv;

typedef struct
{
     char_varying(65)    user_name;
     char                access_code;
}
ACL_ENTRY;

typedef struct
{
     short     max_entries;
     short     num_entries;
     ACL_ENTRY entries[];     /* Variable Sized.  */
}
ACL;

/* VOS entries */
extern void s$c_expand_path(const char **, path_cv *, short *);
extern void s$get_master_disk(module_cv *, disk_cv*, short *);
extern void s$get_default_access_list(const char_varying *, short *, short *,
                                      ACL_ENTRY *, short *);
extern void s$get_access_list(const char_varying *, short *, short *,
                              ACL_ENTRY *, short *);
extern void s$where_path(const char_varying *, path_cv *, short *, module_cv*, 
                         short *);

/* local */
int
auth_secure_path(const char *name, struct stat *stp, const char *pw_dir,
     const char *pw_name, char *err, size_t errlen);
