/*
 *
 * Copyright (c) 2005, 2006, 2008 Herbie Robinson and Paul Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Beginning of modification history */
/* Initial writing 05-02-08 by Herbie Robinson to add pseudo terminal support
   to OpenSSH.*/
/* Modified 05-02-28 by Robinson to fix GCC warnings (with ssl-104). */
/* Modified 05-03-23 by Derek Shute to eliminate misspelling */
/* Modified 05-04-12 by Mani Sundaram to fix ssl-172 */
/* Modified 05-03-25 by Robinson to use the new pseudo-terminal 
     package names.  */
/* Modified 06-01-09 by HWR to handle more than one socket per service. */
/* Modified 08-08-08 by Paul Green for Releases 1.1 and 2.1. (ssl-297) */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* Modified 18-09-19 by HsuenJu Ko for LDAP (SED-4165). */
/* End of modification history */

/* This acts as a null value in the tty_fd field in the session structure:
   it indicates that the session is connected directly to a VOS application
   without any sort of login connection.  */

#define   VOS_SLAVE_NON_FD    -99

#define __VOS_PTY_DEFINE_OLD_NAMES 0         /* Gets new names. */

#include <vos_slave_ip_match_params.h>
#include <vos_slave_services.h>

/* The following is the format of entries for each ssh service.  */

typedef
struct $longmap protocol_service
{
     struct svc_node    *servicep;           /* The node in the s$pt database
                                                (hidden to the sshd code */
     char                service_name[36];   /* Service name */
     int                 local_port;         /* Port for the service */
     unsigned short      is_login;           /* True if it's a login service */
     unsigned short      slave_available;    /* True if at least one device is 
                                                available for incoming slave 
                                                connections to this service */
     unsigned short      disable_requests;   /* If true, most of the channel
                                                and global requests will be
                                                disabled:  This defaults true
                                                for slave services and false
                                                for login services.  */
     unsigned short      disable_x11;        /* If true, x22 forwarding
                                                will be disabled:  This 
                                                defaults true for slave 
                                                services and false
                                                for login services.  */
     unsigned short      use_shell;          /* If true, the user gets a
                                                shell instead of a vos login.
                                                This default to false.  */
}
ssh_service;

/* The following is extra information kept for every socket sshd is
   listening on.  */

typedef
struct $longmap ssh_socket_info
{
     char                service_name[36];   /* The service name associated with
                                                the local_port.  */
     int                 local_port;         /* The port being listened on. */
     int                 service_index;      /* The index of the service for
                                                  this port.  */
}
ssh_socket_info;

#define        MAX_SERVICE_ENTRIES      64

int            num_ssh_services;

/* The following structure is passed from vos_pty_find_service to
   vos_pty_allocate.  It also may be accessed by process creation 
   code (for the privileged_sw).  */

typedef
struct $longmap vos_service_params
{
     int                 service_index;
     unsigned short      local_port;
     unsigned short      remote_port;
     struct in6_addr     local_ip;
     struct in6_addr     remote_ip;
     struct svc_device  *login_dev;
     unsigned short      privileged_sw;
     unsigned short      disable_requests;
     unsigned short      disable_x11;
     unsigned short      use_shell;
}
vos_service_params;


/* Called from openSSH code.  */

struct Session;
extern int vos_pty_allocate(struct Session *s);
extern int vos_pty_find_service( struct vos_service_params *p_spp, 
                                 int p_listener_index, int p_socket);
extern int vos_ssh_init( int max_socks, int socks);
extern void adjust_vos_library_path(int use_shell);
void ldap_init();
void chroot_init();
