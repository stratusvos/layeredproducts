/*
 *
 * Copyright (c) 2005, 2006, 2008, 2011 Herbie Robinson and Paul Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Beginning of modification history */
/* Initial writing 05-02-08 by Herbie Robinson to add pseudo terminal support
   to OpenSSH. (ssl-128)
*/
/* Modified 05-02-28 by Robinson to fix GCC warnings (with ssl-104). */
/* Modified 05-03-08 by Mani Sundaram to fix ssl-144 (rename sshservice as 
   sshservices) */
/* Modified 05-04-04 by Mani Sundaram to fix ssl-170 ("priveleged" typo) */
/* Modified 05-04-11 by HWR to use window_control_opcodes.incl.c instead of
   window_term_opcodes.incl.c (ssl-178). */
/* Modified 05-03-25 by Robinson to use the new pseudo-terminal
     package names and fix ssl-163.  */
/* Modified 05-04-06 by HWR to check the can_add_sockets (ssl-155) and
   to parse protocol options to control whether services allow ssh
   requests other than pty-req and shell (ssl-130).  */
/* Modified 05-04-16 by Paul Green to get loopback tests to work. (ssl-93) */
/* Modification 05-06-03 by HWR to augment the "secure_filename" check
     for VOS (ssl-197).  */
/* Modified 05-06-17 by HWR to redirect s$pt_ errors to the log (ssl-201).  */
/* Modified 05-10-11 by HWR to use s$pt_perror for all services related
     error reporting (ssl-238).  */
/* Modified 05-08-12 by HWR to make failure to locate a slave device
     fatal (ssl-228).  */
/* Modified 06-01-09 by HWR to handle more than one socket per service.
     (ssl-244) */
/* Modified 06-03-08 by HWR to add adjust_vos_library_path (ssl-248). */
/* Modified 08-11-10 by PG to insert >system>openssl>bin and
     >system>gnu_library>bin ahead of the other command library
     search paths. (ssl-301) */
/* Modified 08-08-08 by Paul Green for Releases 1.1 and 2.1. (ssl-297) */
/* Modified 09-05-29 by Miguel Suarez to specify sshservices file is 
     under >opt in release 2.1. (ssl-309/vos_pt-16) */
/* Modified 10-03-24 by Miguel Suarez for Release 2.1 (ssl-326). */
/* Modified 10-07-19 by Miguel Suarez to use VOS compile macros
     to keep this file the same as 1.1 version. (ssl-346). */
/* Modified 12-01-05 by Paul Green to fix this program to build
     on 17.1 by removing the incorrect use of #undef $longmap.
     (ssl-395) */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* Modified 13-07-09 by Paul Green to use a custom version of
     auth_secure_path (formerly "secure_filename"). (ssl-433) */
/* Modified 14-03-26 by Miguel Suarez to fix ssl-453. */
/* End of modification history */

#define _POSIX_C_SOURCE 200112L

#include <errno.h>
#include <fcntl.h>
#include <pty_ioctls.h>
#include <pwd.h>
#include <string.h>
#include <stropts.h>
#include <unistd.h>
#include <dlfcn.h>

#include "includes.h"
#include "ssh.h"
#include "ssh2.h"
#include "compat.h"
#include "xmalloc.h"
#include "sshpty.h"
#include "openbsd-compat/sys-queue.h"
#include "channels.h"
#include "log.h"
#include "hostfile.h"
#include "auth.h"
#include "session.h"
#ifdef WITH_OPENSSL
#include <openssl/bn.h>
#include <openssl/dh.h>
#include <openssl/evp.h>
#endif
#include "monitor_wrap.h"

#include "vos_specific.h"
#include "vos_misc.h"

#include <window_control_opcodes.incl.c>
#include <channel_info_structure.incl.c>
#include <os_error_codes.incl.c>

extern int  s$c_get_portid_from_fildes(int);
extern int  can_add_sockets;
extern void s$expand_path(const char_varying *, const char_varying *,
          path_cv *, short *);
extern void s$c_expand_path(const char **, path_cv *, short *);
extern void s$get_channel_info(const char_varying *, CHANNEL_INFO_STRUCTURE *, 
                               short *);
extern void s$get_library_paths(const char_varying *lp_name, const short *eval,
               const short *max, short * num, path_cv *paths, short *code);
extern void s$set_library_paths(const char_varying *lp_name, const short *num, 
               const path_cv *paths, short *code);
extern void s$update_channel_info(const char_varying *, CHANNEL_INFO_STRUCTURE *, short *);
extern int  set_errno(int);

static int  default_services;


/* Callbacks from the s$pt_ routines.  */

static int  vos_ssh_is_service_supported( const char* p_service_name);

static int  vos_ssh_new_service( const char * p_service_namep, int login, 
               const char * p_proto_optionsp, const char * p_descriptionp,
               struct svc_node* p_tsp, struct protocol_service **p_servicepp);

static int vos_ssh_service_available(struct protocol_service *p_servicep);

static void vos_ssh_service_unavailable(struct protocol_service *p_servicep);

static int  vos_ssh_service_modified( struct protocol_service *p_servicep,
               int p_available, const char * p_proto_optionsp,
               const char * p_descriptionp);

/* Transfer vector that assigns callbacks from the s$pt database.  */
protocol_callbacks ssh_callbacks = 
     _VOS_SLAVE_INIT_CALLBACKS(vos_ssh_is_service_supported, 
                               vos_ssh_new_service,
                               vos_ssh_service_available,
                               vos_ssh_service_unavailable,
                               vos_ssh_service_modified, 
                               NULL /* service_deleted */,
                               NULL /* compute_telnet_peername */,
                               NULL /* add_termination_event */);


/* Shared with sshd (the main program).  */

static int listen_socks[MAX_SERVICE_ENTRIES];    /* Array of sockets sshd is listening on in 
                                   standalone case. */
static int num_listen_socks;  /* Number of sockets sshd is listening on in
                                   standalone case. */
extern int sockets_changed;   /* Flag to indicate sockets have changed in
                                   standalone case. */

static int *socketsp;         /* Pointer to sockets being listened on:
                                   points to listen_socks or inetd_socket. */
static int *socket_countp;    /* Pointer to current socket count:  NULL means
                                   count is 1 and cannnot be changed.  */
static int max_sockets;       /* Max number of sockets allowed.  */
static int inetd_socket;      /* Socket number in the inetd case.  */
int        ssh_socket_count;  /* Local copy of the socket count that doesn't
                                   get set to -1 when forking.  */

/* The following table holds the actual ssh login and slave terminal
   services.  There will be an entry here for each service in the
   sshservices file.  */

ssh_service         ssh_service_table[MAX_SERVICE_ENTRIES];

/* The following table caches information about open sockets.  It
   parallels the socketsp (aka listen_socks) array used by sshd to listen.
   There may be entries here that are not in the ssh_service table.  */

ssh_socket_info     ssh_socket_info_table[MAX_SERVICE_ENTRIES];

typedef union sockaddr_union
{
     struct sockaddr_in  v4;
     struct sockaddr_in6 v6;
} sockaddr_union;


/******************************************************************
 *   Function: get_socket_count
 *   Output:   # of sockets sshd currently knows about.
 *   Action:   First, pick up the number of sockets
 *             If it comes up -1, pick up the correct count from
 *             the local copy; otherwise, update the local copy of
 *             the count to the current value.
 ****************************************************************/

static int 
get_socket_count()
{
     int count = (socket_countp) ? *socket_countp : 1;

     /* If we are in a forked process, the sockets have been
        closed and the count set to -1.  The info we collected 
        for the sockets is still valid, as is the socket index.
        If the count is valid, then update our count.  */

     if (count < 0)
          count = ssh_socket_count;
     else
          ssh_socket_count = count;

     return count;
}

/******************************************************************
 *   Function: fill_socket_info
 *   Input:    Index of the socket in the socketsp and 
 *             ssh_socket_info_table arrays.
 *   Action:   Gets the local address for the socket.
 *             Looks up the service name associated with the IP.
 *             Puts the info into the ssh_socket_info_table entry.
 *
 ****************************************************************/

static void
fill_socket_info(int j)
{
     int                 err;
     sockaddr_union      socket_addr;
     int                 socket_addrlen = sizeof(struct sockaddr_in6);
     struct servent *    sep;
     ssh_socket_info *   sp = ssh_socket_info_table + j;
     uint16_t            port = -1;

     err = getsockname (socketsp[j], (struct sockaddr *) &socket_addr,
                        &socket_addrlen);
     if (!err)
     {
          port = (socket_addr.v4.sin_family == AF_INET) ? socket_addr.v4.sin_port : socket_addr.v6.sin6_port;

          sep = getservbyport(port, 0);
     
          if (sep || port == 22)
          {
               char * name = (sep) ? sep->s_name : "ssh";
     
               strlcpy (sp->service_name, name, 36);
               sp->service_name[35] = '\0';
               sp->local_port = port;
               return;
          }
     }

     sp->service_name[0] = '\0';
     sp->local_port = port;
     sp->service_index = -1;
}

/******************************************************************
 *   Function: vos_ssh_init
 *   Input:
 *        The maximum number of sockets or zero if called in the inetd case.
 *        The socket number to use in the inetd case.
 *
 *   Output:   0 for success, -1 for failure.
 *             s$pt_perror is called whenever a failure is returned.
 *   Action:   Set up the socketsp array.
 *             Initialize the ssh_socket_info_table for the sockets opened.
 *             by sshd.
 *             Call s$pt_initialize and s$pt_init_services to initialize
 *             the services database and open the "sshservices" file.
 *
 ****************************************************************/

int 
vos_ssh_init( int max_socks, int sock)
{
     int j;
     int num_sockets;

     s$pt_set_perror_log_routine (error);    /* ssl-201 */

     max_sockets = (MAX_SERVICE_ENTRIES < max_socks) 
                                        ? MAX_SERVICE_ENTRIES : max_socks;

     if (max_socks > 0)
     {
          socketsp = listen_socks;
          socket_countp = &num_listen_socks;
          ssh_socket_count = num_listen_socks;
     }
     else
     {
          inetd_socket = sock;
          socketsp = &inetd_socket;
          socket_countp = NULL;
          ssh_socket_count = 1;
     }

     num_ssh_services = 0;
     num_sockets = get_socket_count();

     for( j = 0; j < num_sockets; j++ )
     {
          fill_socket_info(j);
     }

     /* Initialize the service database. */

     if (s$pt_initialize(&ssh_callbacks, 0, NULL, NULL) < 0)
     {
          s$pt_perror("");
          return -1;
     }

     /* Read the "sshservices" file into the service database.  This
        may result in calls to vos_ssh_is_service_supported, 
        vos_ssh_new_service, vos_ssh_service_available and
        several s$ip_ routines.  */

     if (s$pt_init_services( ">opt>openssl>etc>sshservices") < 0)
     {
          s$pt_perror("");

          default_services = 1;

          if (s$pt_default_service() < 0)
          {
               s$pt_perror("Initializing default services.");
               return -1;
          }
     }

     return 0;
}


/******************************************************************
 *   Function: vos_ssh_is_service_supported
 *             This is called by the s$pt library to determine if
 *             the deamon can support a given service.
 *
 *   Input:    service name
 *
 *   Output:   Whether this daemon supports that service.
 *
 *   Action:   Search the existing sockets for a match on the service name.
 *             If not found, return false for the inetd case (can't add 
 *             sockets) or true for the standalone case, because
 *             we can add more sockets.  We don't check the max here, because
 *             we want to know if the array limit is hit.
 *
 ****************************************************************/

static int  
vos_ssh_is_service_supported(const char* p_service_name)
{
     int j;
     int num_sockets = get_socket_count();

     /* If it's in our list, we support it. */

     for( j = 0; j < num_sockets; j++ )
     {
          if ( !strncmp( ssh_socket_info_table[j].service_name, 
                                                  p_service_name, 35)
            || ( ssh_socket_info_table[j].local_port == 22 
              && default_services ) )
          {
               return 1;
          }
     }

     /* We also support it if we can add sockets to the array.  */

     return (socket_countp != 0 && can_add_sockets);
}

/******************************************************************
 *   Function: vos_ssh_new_service
 *
 *        This is called by the s$pt library to do whatever is
 *        necessary to support listening for incoming connections
 *        on that service.
 *
 *   Input:    
 *        p_service_namep     The service name
 *        p_login             Whether or not it's a login service
 *        p_proto_optionsp    The protocol options string (none for SSH, now)
 *        p_descriptionp      The description of the service.
 *        p_tsp               The service node in the internal database.
 *
 *   Output:
 *        *p_servicepp is set to service node visible to this code.
 *        Returns -1 for error, 0 for success.
 *
 *   Action:
 *        Look for the service in the sockets that are already open.
 *        If not found, setup a new socket for the service (find port 
 *             number, get socket, set socket options, bind and listen).
 *        Fill in the new socket data structure.
 ****************************************************************/

static int  
vos_ssh_new_service(
     const char * p_service_namep,
     int p_login, 
     const char * p_proto_optionsp,
     const char * p_descriptionp,
     struct svc_node* p_tsp,
     struct protocol_service **p_servicepp)
{
     int j = num_ssh_services;
     ssh_service *sp = ssh_service_table + j;
     int k;
     int num_matched = 0;
     int num_sockets = get_socket_count();
     int new_socket_fd = -1;
     int disable_requests = !p_login;
     int disable_x11 = !p_login;
     int use_shell = 0;

     if (*p_proto_optionsp)
     {
          /* Parse the protocol options.  */

          int offset = 0;
          const char *tokenp;
          int token_len;

          for (;;)
          {
               offset = s$pt_parse_token(p_proto_optionsp, offset, 
                                         &tokenp, &token_len);
               if (token_len <= 0)
                    break;

               if (!strncmp("-enable_requests", tokenp, token_len))
               {
                    disable_requests = 0;
               }
               else if (!strncmp("-disable_requests", tokenp, token_len))
               {
                    disable_requests = 1;
               }
               else if (!strncmp("-enable_x11", tokenp, token_len))
               {
                    disable_x11 = 0;
               }
               else if (!strncmp("-disable_x11", tokenp, token_len))
               {
                    disable_x11 = 1;
               }
               else if (!strncmp("-shell", tokenp, token_len))
               {
                    use_shell = 1;
               }
               else 
               {
                    return set_errno(e$invalid_arg_format);
               }
          }

     }

     if (num_ssh_services >= MAX_SERVICE_ENTRIES)
     {
          return set_errno(e$too_many_entries);
     }

     sp->servicep = p_tsp;
     strlcpy (sp->service_name, p_service_namep, 36);
     sp->service_name[35] = '\0';
     sp->is_login = p_login;
     sp->slave_available = 0;
     sp->disable_requests = disable_requests;
     sp->disable_x11 = disable_x11;
     sp->use_shell = use_shell;

     for( k = 0; k < num_sockets; k++ )
     {
          if ( !strncmp( ssh_socket_info_table[k].service_name, 
                                                  p_service_namep, 35)
            || ( ssh_socket_info_table[k].local_port == 22 
              && default_services ) )
          {
               if (num_matched++ > 0)
               {
                    if (sp->local_port != ssh_socket_info_table[k].local_port)
                    {
                         /* This can't happen unless the Internet database
                              is broken.  */

                         error("%s service defined on port %d and port %d.",
                              p_service_namep,  
                              sp->local_port, 
                              ssh_socket_info_table[k].local_port);
                         continue;
                    }
               }
               else
                    sp->local_port = ssh_socket_info_table[k].local_port;

               ssh_socket_info_table[k].service_index = j + 1;

               debug2("Socket #%d points to service #%d.", k, j);
          }
     }

     if (num_matched == 0)
     {
          ssh_socket_info *   pp = ssh_socket_info_table + num_sockets;
          int                 off = 0;
          int                 on = 1;
          struct sockaddr_in6 socket_addr;
          int                 socket_addrlen = sizeof(struct sockaddr_in6);
          struct servent *    sep;
          int                 port=22;


          if (!socket_countp || k >= max_sockets)
          {
               return set_errno(e$too_many_entries);
          }

          sep = getservbyname(p_service_namep, 0);
          if (sep){
               port = sep->s_port;
          }
          else
          {
               if (strcmp(p_service_namep,"ssh")!=0)
                    return set_errno(e$name_not_found);
          }

          /* Create socket for listening. */
          new_socket_fd = socket(AF_INET6, SOCK_STREAM, 0);
          if (new_socket_fd < 0) 
          {
               /* kernel may not support ipv6 */
               goto error_return;
          }

          if (fcntl(new_socket_fd, F_SETFL, O_NONBLOCK) < 0) 
          {
               goto error_return;
          }

          /*
           * Set socket options.
           * Allow local port reuse in TIME_WAIT.
           */
          if (setsockopt(new_socket_fd, SOL_SOCKET, SO_REUSEADDR,
                         (char *)&on, sizeof(on)) == -1)
          {
               goto error_return;
          }

          /* 
           * Allow IPv4 over IPv6 API (default for this is settable, but
           * we always want it). 
           */
          if (setsockopt(new_socket_fd, IPPROTO_IPV6, IPV6_V6ONLY,
                         (char *)&off, sizeof(off)) == -1)
          {
               goto error_return;
          }

          debug("Bind to port %d.", port);

          /* Bind the socket to the desired port. */
          memset(&socket_addr, 0, sizeof(socket_addr));
          socket_addr.sin6_family = AF_INET6;
          socket_addr.sin6_port = port;
          if (bind(new_socket_fd, (struct sockaddr *) &socket_addr, 
                                                  socket_addrlen) < 0) 
          {
               goto error_return;
          }

          /* Start listening on the port. */
          if (listen(new_socket_fd, 5) < 0)
          {
               goto error_return;
          }

          strlcpy (pp->service_name, p_service_namep, 36);
          pp->service_name[35] = '\0';
          pp->local_port = port;

          sockets_changed = 1;

          sp->local_port = pp->local_port;
          pp->service_index = j + 1;
          logit("Socket #%d points to service #%d.", k, j);

          if (new_socket_fd >= 0)
          {
               socketsp[k++] = new_socket_fd;
               *socket_countp = k;
               ssh_socket_count = k;
          }
     }

     num_ssh_services++;

     logit("Service %s is on port %d.", p_service_namep, sp->local_port);

     *p_servicepp = sp;
     return 0;

error_return:
     if (new_socket_fd >= 0)
          close(new_socket_fd);
     return -1;
}


/******************************************************************
 *   Function: vos_ssh_service_available
 *             This is called by the s$pt library when at least one 
 *             slave terminal is available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as being available:  We need to 
 *             know whether to accept incoming slave connections.
 *
 ****************************************************************/

static int 
vos_ssh_service_available(
     struct protocol_service *p_servicep)
{
     p_servicep->slave_available = 1;
     return 0;
}

/******************************************************************
 *   Function: vos_ssh_service_unavailable
 *             This is called by the s$pt library when no slave 
 *             terminals are available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as not being available:  We need to 
 *             know whether to accept incoming slave connections.
 *
 ****************************************************************/

static void 
vos_ssh_service_unavailable(
     struct protocol_service *p_servicep)
{
     p_servicep->slave_available = 0;
}

/******************************************************************
 *   Function: vos_ssh_service_modified
 *             This routine is called whenever the service database
 *             is modified by an external admin command.
 *   Input:    The service node visible to this code.
 *             Whether it is available.
 *             The protocol options string.
 *             The description.
 *   Output:   Returns -1 for failure, 0 for success.
 *   Action:   Report an error if protocol options were given.
 *             Don't need to do anything else, because all other
 *             attributes are either unused or supported dynamically.
 *
 ****************************************************************/

static int  
vos_ssh_service_modified(
     struct protocol_service *p_servicep, 
     int p_available,
     const char * p_proto_optionsp,
     const char * p_descriptionp)
{
     p_servicep->slave_available = p_available;

     if (*p_proto_optionsp)
     {
          return set_errno(e$invalid_arg_format);
     }

     return 0;
}


/******************************************************************
 *   Function: vos_pty_find_service
 *
 *        This is called from the daemon listening routine to look
 *        up the service being used so we can know whether it is a 
 *        login or slave service.  This is called before authentication
 *        because, when there are no devices ready, we want to reject 
 *        incoming slaves before the user is required to type in a user 
 *        ID and password.
 *
 *   Input:
 *        A pointer to the structure to hold vos specific stuff in
 *             sshd structures (vos_service_params).
 *        The index in the array of sockets.
 *        The socket number.
 *
 *   Output:
 *        The vos_service_params structure is filled in.
 *        Returns -1 for error, 0 for success.
 *        Errors are already reported when -1 is returned.
 *
 *   Action:
 *        Find out the IP address and port we are connected to.
 *        And the local IP address.
 *        Find the service that references the given socket.
 *        If it isn't there, null some things in vos_service_params
 *             and return (because this socket can still be used 
 *             without a pseudo-terminal).
 *        Call s$pt_find_login_device to get the privileged switch
 *             and save the returned pointer in the login_dev field 
 *             for use later.
 *
 ****************************************************************/

int
vos_pty_find_service(
     struct vos_service_params *p_spp, 
     int p_listener_index, 
     int p_socket)
{
     int                 j;
     int                 priv_sw = 0;
     sockaddr_union      remote_addr;
     int                 remote_addrlen = sizeof(struct sockaddr_in6);
     sockaddr_union      local_addr;
     int                 local_addrlen = sizeof(struct sockaddr_in6);
     ssh_service        *sp = 0;
     ssh_socket_info    *pp = ssh_socket_info_table + p_listener_index;

     if (p_listener_index < 0 || p_listener_index >= get_socket_count())
     {
          error("vos_pty_find_service: Bad socket index (%d)", 
                    p_listener_index);
          goto error_return;
     }

     /* Figure out who is connecting.  */

     if (getpeername (p_socket, (struct sockaddr *) &remote_addr,
                      &remote_addrlen) < 0)
     {
          /* allow this for self-tests. */

          _IN6_SET_ADDR_ANY(&p_spp->remote_ip);
          p_spp->remote_port = 0;
          _IN6_SET_ADDR_ANY(&p_spp->local_ip);
          p_spp->local_port = 0;
          p_spp->service_index = -1;
          p_spp->login_dev = NULL;
          p_spp->privileged_sw = 0;
          p_spp->disable_requests = 0;
          p_spp->disable_x11 = 0;
          p_spp->use_shell = 0;
          return 0;
     }

     if (remote_addr.v4.sin_family == AF_INET)
     {
          _IN6_V4_INTO_V4MAPPED(&p_spp->remote_ip, remote_addr.v4.sin_addr.s_addr);
          p_spp->remote_port = remote_addr.v4.sin_port;
     }
     else
     {
          p_spp->remote_ip = remote_addr.v6.sin6_addr;
          p_spp->remote_port = remote_addr.v6.sin6_port;
     }

     /* Figure out which port they connected on (there could be more
        than one adapter).  */

     if (getsockname (p_socket, (struct sockaddr *) &local_addr,
                             &local_addrlen) < 0)
     {
          error("getsockname failed: %.100s", strerror(errno));
          goto error_return;
     }

     if (remote_addr.v4.sin_family == AF_INET)
          _IN6_V4_INTO_V4MAPPED(&p_spp->local_ip, local_addr.v4.sin_addr.s_addr);
     else
          p_spp->local_ip = local_addr.v6.sin6_addr;

     p_spp->local_port = pp->local_port;

     /* Get the service for this port.  */

     j = pp->service_index - 1;

     if (j < 0)
     {
          /* This isn't in the services file, but could be used for
             other SSH functions.  */

          p_spp->service_index = -1;
          p_spp->login_dev = NULL;
          p_spp->privileged_sw = 0;
          p_spp->disable_requests = 0;
          p_spp->disable_x11 = 0;
          p_spp->use_shell = 1;
          return 0;
     }

     /* So we know what it came in on.  */

     sp = ssh_service_table + j;
     p_spp->service_index = j;

     if (sp->is_login)
     {
          protocol_addrs      addrs;
          char                local_name[257];
          char                remote_name[257];

          addrs.family   = remote_addr.v4.sin_family;
          addrs.local_ip = p_spp->local_ip;
          addrs.remote_ip = p_spp->remote_ip;
          addrs.remote_port = p_spp->remote_port;

          p_spp->login_dev = s$pt_find_login_device (sp->servicep, &addrs, 
                                                     &priv_sw);
          if (!p_spp->login_dev)
          {
               s$pt_perror("vos_pty_find_service");
               goto error_return;
          }

          if (getnameinfo((struct sockaddr *) &local_addr, sizeof(local_addr), 
                          local_name, sizeof(local_name), NULL, 0,
                          NI_NUMERICHOST|NI_NUMERICSCOPE))
               strlcpy(local_name, "???", sizeof(local_name));

          if (getnameinfo((struct sockaddr *) &remote_addr, sizeof(remote_addr), 
                          remote_name, sizeof(remote_name), NULL, 0,
                          NI_NUMERICHOST|NI_NUMERICSCOPE))
               strlcpy(remote_name, "???", sizeof(remote_name));

          debug("%s service (#%d, port %d) on %s,%d, from %s,%d.", 
                sp->service_name, j, sp->local_port, 
                local_name, p_spp->local_port, 
                remote_name, addrs.remote_port);

     }
     else if (!sp->slave_available)
     {
          error("No devices ready for %.35s service.", sp->service_name);
          goto error_return;
     }

     p_spp->privileged_sw = (priv_sw != 0);
     p_spp->disable_requests = sp->disable_requests;
     p_spp->disable_x11 = sp->disable_x11;
     p_spp->use_shell = sp->use_shell;
     return 0;

error_return:
     return -1;
}


/******************************************************************
 *   Function: vos_plink_login_pt
 *             This is a glue routine used to call s$pt_plink_login_pt
 *             using privilege separation.
 *   Input:    Same as s$pt_plink_login_pt with the addition of the 
 *             fd for the master end of the pseudo-terminal.
 ****************************************************************/

int
vos_plink_login_pt(struct svc_node *servicep, int tli_fd, int pty_fd,
                   struct svc_device * p_devicep,
                   struct protocol_addrs *p_addrsp, int SEQ_number, 
                   char * p_device_name)
{
     return s$pt_plink_login_pt(servicep, tli_fd, p_devicep, p_addrsp, 
                                SEQ_number, p_device_name);
}

/******************************************************************
 *   Function: vos_plink_slave_pt
 *             This is a glue routine used to call s$pt_plink_slave_pt
 *             using privilege separation.
 *   Input:    Same as s$pt_plink_slave_pt with the addition of the 
 *             fd for the master end of the pseudo-terminal.
 ****************************************************************/

int
vos_plink_slave_pt(const char *p_device_namep, int tli_fd, int pty_fd,
                   int use_protocol, int SEQ_number, short p_msg_port_id,
                   long p_msg_id, char * p_device_name)
{
     return s$pt_plink_slave_pt(p_device_namep, tli_fd, use_protocol, SEQ_number,
                                p_msg_port_id, p_msg_id, p_device_name);
}

/******************************************************************
 *   Function: vos_pty_allocate
 *
 *   Input:    The sshd session structure.
 *
 *   Output:   Returns -1 for error, 0 for success.
 *
 *   Action:
 *        if it's a login:
 *             create a pipe for the pseudo-terminal
 *             call vos_plink_login_pt to connect a window term device to it
 *                  (using the device found earlier and saved in login_dev).
 *             close the slave end of the pipe.
 *             call set_ptsname, grantpt and unlockpt
 *             open the window term device.
 *        otherwise, for slaves:
 *             call s$pt_find_device to look up and reserve the device
 *                  in the server queue.
 *             create a pipe for the pseudo-terminal
 *             call vos_plink_slave_pt to connect the window term device to
 *                  the pipe (also responds to the server queue).
 *             close the slave end of the pipe.
 *             call set_ptsname
 *             note that we don't use grantpt with slaves as the device is
 *                  already open; so, whatever permissions are needed are
 *                  already in place.
 *             also, note that we don't call unlockpt in this routine, because
 *                  the application on the slave terminal may be ready to
 *                  inundate us with output data and we don't want the pipe
 *                  congested until after we are done configuring everything.
 *             we do NOT open the slave device in the daemon.
 *
 *        in both cases, we force the data with to 8 bits per char and
 *        set the terminal type if a terminal type is given.  Note that
 *        we must use s$update_channel_info to set the terminal type,
 *        because we only have the slave end open for login terminals
 *        and we aren't using the pt_tli_mod; so, we can't use the master 
 *        end to set the terminal type.  
 *
 ****************************************************************/

int
vos_pty_allocate(Session *s)
{
     struct Authctxt *at = s->authctxt;
     vos_service_params *spp = at->vos_service_paramsp;
     int j = spp->service_index;
     ssh_service *sp = 0;
     char device_name[MAX_PTY_NAME];
     int  master_fd = -1;
     int  slave_fd = -1;
     protocol_addrs addrs;
     char bits_per_char = 8;
     strioctl ioc;
     int return_status = 0;
     extern void s$control (short *, short *, const char_varying *, short *);

     if (j < 0 || j >= num_ssh_services)
     {
          error("No pseudo-terminal in the sshservices file for port %d. j=%d, num_ssh_services=%d", 
                    spp->local_port, j, num_ssh_services);
          goto error_return;
     }

     sp = ssh_service_table + j;

     addrs.local_ip = spp->local_ip;
     addrs.remote_ip = spp->remote_ip;
     addrs.remote_port = spp->remote_port;
     addrs.family = AF_INET6;

     if (sp->is_login)
     {
          /* Create a pseudo terminal and open its master port */

          if (s$pt_open_pt_tioc_pipe(&master_fd, &slave_fd) < 0)
          {
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               goto error_return;
          }

          if (PRIVSEP(vos_plink_login_pt(sp->servicep, slave_fd, 
                                         master_fd, spp->login_dev, 
                                         &addrs, 0, device_name)) < 0)
          if (!device_name)
          {
               s$pt_perror("s$pt_plink_login_pt");
               goto error_return;
          }

          close(slave_fd);

          if (s$pt_set_ptsname(master_fd, device_name) < 0)
          {
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }
     
          if (grantpt(master_fd) < 0)
          {
               s$pt_perror("grantpt");
               goto error_return;
          }
     
          if (unlockpt(master_fd) < 0)
          {
               s$pt_perror("unlockpt");
               goto error_return;
          }

          /* Open the device whether it login or slave:  We need a port
             to the window term device in order to set the terminal type.
             We will close the slave terminal case after setting the
             terminal type.   */

          slave_fd = open(device_name, O_RDWR | O_NOCTTY);
          if (slave_fd < 0)
          {
               error("%.100s: %.100s", device_name, strerror(os_errno));
               goto error_return;
          }

     }
     else 
     {
          /* Must be a VOS slave devices that is already being opened
             by an application process.  */

          svc_found_device dev;

          return_status = -1;

          if (s$pt_find_device (sp->servicep, &addrs, &dev) < 0)
          {
               s$pt_perror("s$pt_find_device");
               goto error_return;
          }

          if (s$pt_open_pt_tioc_pipe(&master_fd, &slave_fd) < 0)
          {
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               goto error_return;
          }

          if (PRIVSEP(vos_plink_slave_pt(dev.device_name, slave_fd, 
                                         master_fd, 0, 0, 
                                         dev.message_port_id, 
                                         dev.message_id,
                                         device_name)) < 0)
          {
               s$pt_perror("s$pt_plink_login_pt");
               goto error_return;
          }

          close(slave_fd);

          if (s$pt_set_ptsname(master_fd, device_name) < 0)
          {
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }

          slave_fd = VOS_SLAVE_NON_FD;
     }


     /* We want to force the bits per char to 8 no matter how the user
        may have messed up the device.tin entries.  */

     ioc.ic_cmd = SVC_SET_BITS_PER_CHAR;
     ioc.ic_timout = -1;
     ioc.ic_len = 1;
     ioc.ic_dp = &bits_per_char;

     if (ioctl(master_fd, I_STR, &ioc) < 0)
     {
          error("SVC_SET_BITS_PER_CHAR: %.100s: %.100s", device_name,
                         strerror(os_errno));
          goto error_return;
     }

     /* Pick up the ttp before setting modes and window size, as
        they are dependent on it.  */

     if (s->term)
     {
          short opcode = TERM_SET_TERMINAL_TYPE;
          char_varying(32) ttp_name;
          short code;

          if (slave_fd == VOS_SLAVE_NON_FD)
          {
               /* If we try to open the slave port and the application that
                  opened the slave terminal has aborted, we will hang trying
                  to open a connection to ourselves.  Try using 
                  s$update_channel_info to set the slave terminal type.  */

               path_cv path_in;
               path_cv path_out;
               char_varying(1) suffix;

               strncpy_vstr_nstr(&suffix, "", 1);
               strncpy_vstr_nstr(&path_in, device_name, MAX_PATH);

               s$expand_path (&path_in, &suffix, &path_out, &code);
               if (!code)
               {
                    CHANNEL_INFO_STRUCTURE info;

                    info.version = CHAN_INFO_VERSION_9;

                    s$get_channel_info (&path_out, &info, &code);
                    if (!code)
                    {
                         strncpy_vstr_nstr(&info.terminal_type_name, 
                                           s->term, 32);

                         s$update_channel_info (&path_out, &info, &code);
                    }

                    /* It is possible for clone devices to go away
                       before we get to them.  Those errors will
                       be reported elsewhere.  */

                    if (code == e$device_not_found)
                         code = 0;
               }
          }
          else
          {
               short portid = s$c_get_portid_from_fildes(slave_fd);

               strncpy_vstr_nstr(&ttp_name, s->term, 32);

               s$control(&portid, &opcode, &ttp_name, &code);
          }

          if (code)
          {
               error("Can't set ttp for %s to %s: %.100s", 
                    device_name, s->term, strerror(code));
               /* This is non-fatal. */
          }
     }

     /* Put everything in session structure.  */

     strlcpy(s->tty, device_name, sizeof(s->tty));
     s->ptyfd = master_fd;
     s->ttyfd = slave_fd;
     return 1;

error_return:
     {
          int save_errno = errno;
          int save_os_errno = os_errno;

          if (master_fd >= 0)
               close(master_fd);

          if (slave_fd >= 0)
               close(slave_fd);

          errno = save_errno;
          os_errno = save_os_errno;
     }

     s->ptyfd = -1;
     s->ttyfd = -1;
     return return_status;
}

static void 
add_path(path_cv *lib_pathsp, short *num_pathsp, const disk_cv *master_disk, 
               const char *subdir )
{
     path_cv path;
     path_cv path_out;
     short type;
     module_cv module_name;
     short code;
     int j;

     /* Build a complete pathname. */
     strcpy_vstr_vstr(&path, master_disk);
     strcat_vstr_nstr(&path, subdir);

     /* Make sure it exists and is a directory.  */
     s$where_path (&path, &path_out, &type, &module_name, &code);
     if (code || type != 2)
          return;

     /* If it's already in the search paths, we don't need to add it. */
     for(j = 0; j < *num_pathsp; j++)
     {
          if (strcmp_vstr_vstr(&path, lib_pathsp+j) == 0)
               return;

          if (strcmp_vstr_vstr(&path_out, lib_pathsp+j) == 0)
               return;
     }

     /* We want to insert these directories before the other search
        directories but after the "(current_dir)" rule.  Note that
        even if the "(current_dir)" rule is the last entry in the
        list, this logic is safe; there is always room in the array to
        add the pathname.  */

     for (j = *num_pathsp; j > 0; --j)
          if (!strncmp_vstr_nstr(lib_pathsp+j-1, "(current_dir)", MAX_PATH))
               break;
          else strncpy_vstr_vstr(lib_pathsp+j, lib_pathsp+j-1, MAX_PATH);

     strncpy_vstr_vstr(lib_pathsp+j, &path_out, MAX_PATH);
     *num_pathsp += 1;
}

extern void 
adjust_vos_library_path(int use_shell)
{
     short num_paths = 0;
     name_cv lp_name;
     path_cv path;
     short code;

     /* Set all library paths back to the default (side effect of num=0).  */
     strncpy_vstr_nstr(&lp_name, "include", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "object", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "message", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "command", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     if (use_shell)
     {
          path_cv *lib_paths;
          short max_paths = 0;
          short eval = 0;
          disk_cv master_disk;
          module_cv module_name;

          /* Get the master disk name. */
          strncpy_vstr_nstr(&module_name, "", 0);
          s$get_master_disk(&module_name, &master_disk, &code);
          if (code)
               return;

          /* Find out how many command library paths there are. */
          strncpy_vstr_nstr(&lp_name, "command", 32);
          s$get_library_paths(&lp_name, &eval, &max_paths, &num_paths, &path,
                              &code);
          if (code)
               return;

          /* Allocate space for the existing paths plus 2.  */
          lib_paths = xmalloc(sizeof(path_cv) * (num_paths+2));


          /* Get the library paths. */
          max_paths = num_paths;
          s$get_library_paths(&lp_name, &eval, &max_paths, &num_paths, 
                              lib_paths, &code);
          if (code)
               return;

          /* Make sure that (master_disk)>opt>openssl>bin
             [or (master_disk)>system>openssl>bin for 1.1] and
             (master_disk)>system>gnu_library>bin are in the library
             paths.  */

          add_path(lib_paths, &num_paths, &master_disk, ">opt>openssl>bin");
          add_path(lib_paths, &num_paths, &master_disk, ">system>gnu_library>bin");

          if (num_paths == max_paths)   /* Did we add any. */
               return;

          s$set_library_paths(&lp_name, &num_paths, lib_paths, &code);
     }
}

/* At some point VOS will support chroot() and when it
 * does SSH will be ready. Determine this at runtime by
 * calling dlsym() and friends. This is only meant 
 * to get called by the SSH daemon. */

static int (*chroot_func)(const char *path);

void chroot_init(){

     void *handle;
     char *error;

     chroot_func=NULL;

     if((handle=dlopen("libvosposix.1.so", RTLD_LAZY))==NULL)
          return;

     dlerror();

     *(void **) (&chroot_func)=dlsym(handle, "chroot");

     if ((error = dlerror()) != NULL)
          debug2("chroot_init: %s", error);

     dlclose(handle);
}

int chroot_wrap(const char *path){

     if (chroot_func != NULL)
          return ((*chroot_func)(path));
     else
          return (0);
}
