/*
 * Maxim Tishkov 2016
 * This file is distributed under the same license as OpenSSL
 */

#if defined(__cplusplus)
extern "C" {
#endif

#include "gost_grasshopper_mac.h"



#if defined(__cplusplus)
}
#endif

