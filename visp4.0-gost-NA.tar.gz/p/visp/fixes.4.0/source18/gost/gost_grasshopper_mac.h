/*
 * Maxim Tishkov 2016
 * This file is distributed under the same license as OpenSSL
 */

#ifndef GOST_GRASSHOPPER_MAC_H
#define GOST_GRASSHOPPER_MAC_H

#if defined(__cplusplus)
extern "C" {
#endif



#if defined(__cplusplus)
}
#endif

#endif
