/* This header hold most if not all definitions VOS port of SSH.
 * Anything defined here will be included by most SSH source files.
 */

/* ------------ VOS custom settings ----------------*/

/* Enable custom checks for login. */
#define CUSTOM_SYS_AUTH_ALLOWED_USER 1

/* Enable VOS password expiration support. */
#define CUSTOM_SYS_AUTH_PASSWD 1

/* Enable logging of successful logins. */
#define CUSTOM_SYS_AUTH_RECORD_LOGIN 1

/* Enable logging of login failures. */
#define CUSTOM_FAILED_LOGIN 1

#define VOS_MAX_SERVICE_ENTRIES 64

/* Enables the HPN code layered on top of the SSH source base */
#define VOS_HPN 1

/* Enables the tcpwrappers code */
#define VOS_TCPWRAPPERS 1 

/* Enables code to allow root login */
#define VOS_ROOT 1

#define VOS_FD_OFFSET 2

/* ------------ VOS functions used by SSH ----------------*/

void vos_closefrom_fallback(int lowfd);

int vos_ssh_init_pt(void);

int vos_sshd_setup(int listener_index);

int vos_session_setup(void);

void clear_can_add_sockets();

int vos_mux_check_open(int self_id);

int check_cli_support(void);

unsigned short
get_vparm_privileged(void);

short
get_vparm_root_login(void);

unsigned short
get_vparm_sysadmin(void);

unsigned short
get_vparm_disable_requests(void);

unsigned short
get_vparm_disable_x11(void);

unsigned short
get_vparm_use_shell(void);

void
set_vparm_use_shell(void);

int
check_tty_slave(int ttyfd);

void adjust_vos_library_path(int use_shell);

int chroot_wrap(const char *path);

void vos_exec_native (char *const envp []);

char *check_for_vos_path(char *vpath);

void fixup_stat(struct stat *st);

struct passwd *vos_getpwnam(const char *user);

int check_mux_flag_support(void);

int ppoll_with_events(struct pollfd *fds, nfds_t nfds, const struct timespec *tmoutp, const sigset_t *sigmask, int *event_id, int *count, short total_events, short *event_no);
