/* 
 * -------------------- [The Big Picture] ------------------- 
 *
 * + This file holds all the major functions with VOS specific
 *   code used in the VOS port of OpenSSH. Starting with OpenSSH 10.2
 *   most if not all VOS code that had been scattered throughout
 *   the SSH source tree from the last 20 years of development
 *   is placed here. The port of SSH is the most customized and most
 *   used port out of all the VOS open source ports. Features added
 *   to the base source include:
 *
 *        - Tcpwrappers
 *        - Option to hide SSH version when pinged on telnet port
 *        - High-Speed Network performance boost
 *        - Allowing root login via VOS sshservices file
 *        - Enforcing VOS login admin rules
 *
 * + It's in our best interest to consolidate VOS code to reduce
 *   bug regressions and make it easier to merge future versions
 *   of SSH. So the following guidelines will be in place:
 *
 *        - Use port-vos.h/port-vos.h according to convention. The
 *          idea is code here gets rolled into libopenbsd-compat.a
 *          which is then bound into SSH binaries by default. Examples
 *          from other platforms reside in ./source/openssh/openbsd-compat.
 *
 *        - VOS functions and global variables should be hidden (ie. static)
 *          by default unless there is a need to call them from the 
 *          SSH source base.
 *
 *        - VOS functions called from SSH source base will be declared
 *          by port-vos.h
 *
 *        - VOS functions here should return 1 on success and 0 on failure.
 *
 * + I know..this is a big file but I'd rather have all the VOS code in
 *   one *.c file until we figure out the best way to organize functions
 *   in separate source files.
 *
 */


#include "includes.h"

/* --------------------- POSIX headers ------------------- */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stropts.h>
#include <pty_ioctls.h>

/* --------------------- VOS headers --------------------- */

#include <vos_slave_ip_match_params.h>
#include <vos_slave_services.h>
#include <registration_info.h>
#include <os_return_codes.incl.c>
#include <window_control_opcodes.incl.c>
#include <channel_info_structure.incl.c>
#include <error_codes.incl.c>
#include <system_io_constants.incl.c>
#include <login_event_constants.incl.c>
#include <ext_auth_message.incl.c>
#include <c_env_data.h>
#include <dlfcn.h>

/* --------------------- internal definitions -------------------*/

#define CHECK_FILE          0
#define CHECK_DEFAULT_ACL   1
#define CHECK_DIR           2
#define MAX_INDEXSTR        32
#define MAX_PATH 256

#define PT_DEVICE "#s$pt_"

/* This acts as a null value in the tty_fd field in the session structure:
   it indicates that the session is connected directly to a VOS application
   without any sort of login connection.  */

#define VOS_SLAVE_NON_FD    -99

/* Need enough for: "PTY=%s,%d,%d"
 * Going allocate 10 bytes for each int. This should be more than enough.
 * Same below.
 */
#define MAX_PTY_BUF MAX_PTY_NAME+10+10

/* Need enough for: "VPARM=%d,%d,%d,%d,%d,%d,%d,%s".
 * FYI, check every now and then with what's actually
 * written out in vos_write_pty_env. */
#define MAX_VPARM ((11*7)+MAX_PTY_NAME)

#define USE_EXTERNAL_NAME REGISTRATION_INFO_VERSION_6

#define MAX_PASSWORD_LEN 1024

#define MAX_EXEC_PROGRAM_LEN  32766

#define MAX_ARG_LEN           8190

#define MAX_LISTEN_SOCKS VOS_MAX_SERVICE_ENTRIES

/* ------------------ SSH headers we need -------------------- */

#include "xmalloc.h"
#include "sshbuf.h"
#include "ssherr.h"
#include "sshkey.h"
#include "hostfile.h"
#include "auth.h"
#include "packet.h"
#include "log.h"
#include "misc.h"
#include "servconf.h"
#include "ssh.h"
#include "channels.h"
#include "session.h"
#include "monitor.h"

#include "port-vos.h"

/* ------------------ struct definitions ------ */

typedef
struct $longmap protocol_service
{
     struct svc_node    *servicep;           /* The node in the s$pt database
                                                (hidden to the sshd code */
     char                service_name[36];   /* Service name */
     int                 local_port;         /* Port for the service */
     unsigned short      is_login;           /* True if it's a login service */
     unsigned short      slave_available;    /* True if at least one device is 
                                                available for incoming slave 
                                                connections to this service */
     unsigned short      disable_requests;   /* If true, most of the channel
                                                and global requests will be
                                                disabled:  This defaults true
                                                for slave services and false
                                                for login services.  */
     unsigned short      disable_x11;        /* If true, x22 forwarding
                                                will be disabled:  This 
                                                defaults true for slave 
                                                services and false
                                                for login services.  */
     unsigned short      use_shell;          /* If true, the user gets a
                                                shell instead of a vos login.
                                                This default to false.  */
     short               permit_root_login;  /* Same as global SSH option */
     unsigned short      permit_sysadmin;    /* If true (the default), the
                                                SysAdmin group is allowed. */
}
ssh_service;

/* The following is extra information kept for every socket sshd is
   listening on.  */

typedef
struct $longmap ssh_socket_info
{
     char                service_name[36];   /* The service name associated with
                                                the local_port.  */
     int                 local_port;         /* The port being listened on. */
     int                 service_index;      /* The index of the service for
                                                  this port.  */
}
ssh_socket_info;

/* The following structure is passed from vos_pty_find_service to
   vos_pty_allocate.  It also may be accessed by process creation 
   code (for the privileged_sw).  */

typedef
struct $longmap vos_service_params
{
     int                 service_index;
     unsigned short      local_port;
     unsigned short      remote_port;
     struct in6_addr     local_ip;
     struct in6_addr     remote_ip;
     struct svc_device  *login_dev;
     unsigned short      privileged_sw;
     unsigned short      disable_requests;
     unsigned short      disable_x11;
     unsigned short      use_shell;
     short               permit_root_login;
     unsigned short      permit_sysadmin;
     char                service_name[36];
}
vos_service_params;

typedef struct $longmap lka_type
{
     void *code_ptr;
     void *static_ptr;
}lka_type;

typedef union sockaddr_union
{
     struct sockaddr_in  v4;
     struct sockaddr_in6 v6;
} sockaddr_union;

typedef char_varying(PATH_MAX) cvPATH_MAX;
typedef char_varying(66)       cv66;
typedef char_varying(32)      *cv32p, cv32;
typedef char_varying(256)      cv256;

typedef struct
{
     char_varying(65)    user_name;
     char                access_code;
}ACL_ENTRY;

typedef struct
{
     short     max_entries;
     short     num_entries;
     ACL_ENTRY entries[];     /* Variable Sized.  */
}ACL;

/* ------------------ globals (internal) ----------------- */

/* The real definitions for these PTY variables are in bsd-closefrom.c.
 * We declare them as extern here to avoid undefined symbol binder errors
 * since vos_specific.o gets bound into other SSH .pm's. Note these
 * variables only get accessed by vos_read_pty_env() and that is only
 * called by sshd-session.pm which also binds bsd-closefrom.o */

static int     master_fd_ext            = -1;
static int     slave_fd_ext             = -1;
static int     gbl_cli_support          = -1;
static int     gbl_vos_mux_use_flag     =  0;

static ssh_service
               ssh_this_service_mux[VOS_MAX_SERVICE_ENTRIES];

static int     ssh_this_service_index=0;
static int     current_num_socks;
static int     default_services = 0;

static int     max_sockets;  /* Max number of sockets allowed.  */
static int     num_ssh_services;
static int     can_add_sockets = 1;

/* The following table holds the actual ssh login and slave terminal
   services.  There will be an entry here for each service in the
   sshservices file.  */

static ssh_service         ssh_service_table[VOS_MAX_SERVICE_ENTRIES];

/* The following table caches information about open sockets.  It
   parallels the socketsp (aka listen_socks) array used by sshd to listen.
   There may be entries here that are not in the ssh_service table.  */

static ssh_socket_info     ssh_socket_info_table[VOS_MAX_SERVICE_ENTRIES];

/* Parameters valid for the current sshservice */
static vos_service_params vos_params;

/* ------------------ globals (external) ----------------- */

/* Shared with sshd (the main program).  */

int listen_socks[MAX_LISTEN_SOCKS];  /* Array of sockets sshd is listening
                                        on for standalone case. */

/* Allow sites to adjust these values */

short int sshd_use_external_name$  = (REGISTRATION_INFO_VERSION_6 + 0);
short int sshd_auth_priority$      = 5;
int sshd_auth_timeout_ms$          = 61440;        /* ssl-276 */

/*------------------- VOS s$ declarations ------------------------- */

void s$c_expand_path(const char **, cvPATH_MAX *, short *);

void s$get_master_disk(cv66 *, cv66*, short *);

void s$get_default_access_list(const char_varying *, short *, short *,
                               ACL_ENTRY *, short *);

void s$get_access_list(const char_varying *, short *, short *,
                             ACL_ENTRY *, short *);

void s$where_path(const char_varying *, cvPATH_MAX *, short *, cv66*, 
                         short *);

void s$lookup_kernel_address(
               short int * module_id,
               cv32p name,
               short int * flags,
               void * link,
               short int * error_code);

void s$perform_ext_authentication (
     const int               *p_msg_type,       /* (in) msg type */
     const short int         *p_msg_priority,   /* (in) msg priority */
     const char_varying      *p_client_handle,  /* (in) client handle */
     const char_varying      *p_person_name,    /* (in) person name */
     const char_varying      *p_password,       /* (in) password */
     const int               *p_chal_type,      /* (in) challenge type */
     const int               *p_auth_type,      /* (in) auth type */
     const int               *p_timeout,        /* (in) timeout (1/1024ths) */
           int               *p_response,       /* (out) accept/deny/chal */
           char_varying      *p_chal_cookie,    /* (in/out) challenge cookie */
           char_varying      *p_challenge,      /* (out) challenge string */
           short int         *p_code);          /* (out) status code */

void s$security_log_write (
               const char_varying       *user_name,
               const char_varying       *message,
               const short int          *msg_code,
               const char_varying       *comment,
               short int                *code);

void s$set_login_violations (
               const char_varying       *module_name,
               const char_varying       *person,
               const short int          *violation,
               const short int          *num,
               short int                *code);

void s$sleep (
               long int                 *time_period, 
               short int                *error_code);

void s$get_registration_info (
               char_varying *,
		     char_varying *,
               registration_info_v6_type *,
               short *, char_varying *);

int  s$control (
               const int16_t *, 
               const int16_t *, 
               void *, 
               int16_t *);

int  s$c_get_portid_from_fildes(int);

void s$expand_path (
               const char_varying *,
               const char_varying *,
               cvPATH_MAX *, short *);

void s$get_channel_info (
               const char_varying *,
               CHANNEL_INFO_STRUCTURE *,
               short *);

void s$get_library_paths (
               const char_varying *lp_name,
               const short *eval,
               const short *max,
               short * num,
               cvPATH_MAX *paths,
               short *code);

void s$set_library_paths (
          const char_varying *lp_name,
          const short *num,
          const cvPATH_MAX *paths,
          short *code);

void s$update_channel_info (
          const char_varying *,
          CHANNEL_INFO_STRUCTURE *,
          short *);

void s$get_port_ranges (
          short int *,
          short int *,
          short int *,
          short int *);

void s$get_port_attachment (
          short int *,
          cv256 *,
          cv32 *,
          short int *,
          short int *,
          short int *,
          short int *,
          short int *);

int  set_errno(int);

void s$get_c_env_data_ptr (ed_type **edpp);

void s$stop_program (
          const char_varying *,
          short *);

int s$c_select_with_events2(int nfds, fd_set *readfds,
          fd_set *writefds, fd_set *exceptfds,
          const struct timespec *timeout, int *os_event_ids,
          int *os_event_counts, short total_os_events,
          short *os_event_no);

/*------------------- VOS local declarations ------------------------- */

static void vos_login_violation (Authctxt *p_authctxt, const short int p_violation);

static int
vos_pty_find_service(
     struct vos_service_params *p_spp, 
     int listener_index,
     int p_socket);

static int
vos_pty_allocate(vos_service_params *spp, char *device_name, int *master_fd, 
                 int *slave_fd);

static int vos_ssh_init_mux();

/*------------------- callback setup (mux) --------------------- */

static int  vos_ssh_is_service_supported_mux( const char* p_service_name);

static int  vos_ssh_new_service_mux( const char * p_service_namep, int login, const char * p_proto_optionsp, const char * p_descriptionp, struct svc_node* p_tsp, struct protocol_service **p_servicepp);

static int  vos_ssh_service_available_mux(struct protocol_service *p_servicep);

static void vos_ssh_service_unavailable_mux(struct protocol_service *p_servicep);

static int vos_ssh_service_modified_mux(struct protocol_service *p_servicep, int p_available, const char * p_proto_optionsp, const char * p_descriptionp);

/*------------------- callback setup (non-mux) --------------------- */

static int  vos_ssh_is_service_supported( const char* p_service_name);

static int  vos_ssh_new_service( const char * p_service_namep, int login,
          const char * p_proto_optionsp, const char * p_descriptionp,
          struct svc_node* p_tsp, struct protocol_service **p_servicepp);

static int vos_ssh_service_available(struct protocol_service *p_servicep);

static void vos_ssh_service_unavailable(struct protocol_service *p_servicep);

static int  vos_ssh_service_modified( struct protocol_service *p_servicep,
          int p_available, const char * p_proto_optionsp,
          const char * p_descriptionp);

/* Transfer vectors that assigns callbacks from the s$pt database.
 * They have to be declared after the funtions.
 */

protocol_callbacks ssh_callbacks_mux =
               _VOS_SLAVE_INIT_CALLBACKS(
               vos_ssh_is_service_supported_mux, 
               vos_ssh_new_service_mux,
               vos_ssh_service_available_mux,  /* service available */
               vos_ssh_service_unavailable_mux,/* service unavailable */
               vos_ssh_service_modified_mux,   /* service modified */ 
               NULL                            /* service_deleted */,
               NULL                            /* compute_telnet_peername */,
               NULL);                          /* add_termination_event */

protocol_callbacks ssh_callbacks =
          _VOS_SLAVE_INIT_CALLBACKS(
          vos_ssh_is_service_supported,
          vos_ssh_new_service,
          vos_ssh_service_available,
          vos_ssh_service_unavailable,
          vos_ssh_service_modified,
          NULL /* service_deleted */,
          NULL /* compute_telnet_peername */,
          NULL /* add_termination_event */);

/*=====================================================================*/
/*==================== SECTION: functions =============================*/
/*=====================================================================*/

/*--------------- sys_auth_allowed_user() ------------------*/

/* With CUSTOM_SYS_AUTH_ALLOWED_USER enabled we
 * define VOS version of sys_auth_allowed_user().
 * Check if specified account is permitted to log in.
 * Returns 1 if login is allowed, 0 if not allowed.
 */
int sys_auth_allowed_user(struct passwd *pw, struct sshbuf *loginmsg)
{
     return 1;
}

/*--------------- sys_auth_passwd() ------------------*/

/*
 * With CUSTOM_SYS_AUTH_PASSWD enabled we define VOS version of
 * sys_auth_passwd().
 */

int
sys_auth_passwd(struct ssh *mssh, const char *password)
{

	int authenticated;
	Authctxt *authctxt = mssh->authctxt;
	struct passwd *pw = authctxt->pw;
	char *encrypted_password;
	char_varying(128) client_handle;
	int msg_type;
	short int msg_priority;
	int chal_type;
	int auth_type;
	int timeout;
	int response;
	char_varying(128) cookie;
	char_varying(128) challenge;
	short int error_code;
	char_varying(128) password_vs;
	char_varying(32) person_name;
	char_varying(66) module_name;
	registration_info_v6_type ri;
	char_varying(256) text;

	/* Just use the supplied fake password if authctxt is invalid */
	char *pw_password = authctxt->valid ? shadow_pw(pw) : pw->pw_passwd;

     debug("%s: entering", __func__);

	strcpy_vstr_nstr (&module_name, "");
	strcpy_vstr_nstr (&person_name, pw->pw_name);

     if (pw->pw_vos_flags & _PASSWD_VOS_EXT_AUTHENTICATION)
	{

		/* The following macro expression evaluates to TRUE
		   when this code is built on a version of VOS that
		   supports external names, and evaluates to FALSE
		   otherwise.  */

#  if ((USE_EXTERNAL_NAME+0) == REGISTRATION_INFO_VERSION_6)
		if (sshd_use_external_name$ > 0)
		{
			strcpy_vstr_nstr (&text, "");
			ri.v4_data.version = REGISTRATION_INFO_VERSION_6;
               /* Lookup the external name in the registration record.
                * All users should return zero except root which will be
                * set to e$user_is_root in which case we ignore it. */
			s$get_registration_info (&module_name, &person_name, &ri,
				&error_code, &text);
			if ((error_code == 0) || 
                  ((error_code == e$user_is_root) && 
                   (strcmp_vstr_nstr (&person_name, "root") == 0)))
			{
				if (strcmp_vstr_nstr (&ri.external_person, ""))
				{
					logit ("Using external name %.32v to authenticate %.32s.",
						&ri.external_person, pw->pw_name);
					strcpy_vstr_vstr (&person_name, &ri.external_person);
				}
			}
		}
#  endif /* REGISTRATION_INFO_VERSION_6 */

		msg_type = EAM_MSG_INITIAL;
		msg_priority = sshd_auth_priority$;
		strcpy_vstr_nstr (&client_handle, "sshd");
		strcpy_vstr_nstr (&password_vs, password);
		chal_type = EAM_CHAL_FORBID;
		auth_type = EAM_AUTH_OTHER;
		timeout = sshd_auth_timeout_ms$;

		s$perform_ext_authentication (&msg_type, &msg_priority,
			&client_handle, &person_name, &password_vs,
			&chal_type, &auth_type, &timeout, &response,
			&cookie, &challenge, &error_code);
		if (error_code != 0)
		{
			logit ("External authentication server unavailable. %.32s",
				pw->pw_name);
			authenticated = 0;
		}
		else if (response != EAR_RESPONSE_ACCEPTED)
		{
			logit ("External authentication server denied login. %.32s",
				pw->pw_name);
			authenticated = 0;
		}
		else authenticated = 1;
	}
	else
	{
		/* Check for users with no password. */
		if (strncmp(pw_password, "", 1) == 0 && strncmp(password, "", 1) == 0)
			return (1);

		/* Encrypt the candidate password using the proper salt. */
		encrypted_password = xcrypt(password,
		    (pw_password[0] && pw_password[1]) ? pw_password : "xx");

		/*
		 * Authentication is accepted if the encrypted passwords
		 * are identical.
           * [04/14/202] - Use MAX_PASSWORD_LEN with same value defined
           * in auth-passwd.c Might be too much as s$encipher_password2
           * encrypts up to 128 bytes but this could change some day
           * (ssl-683).
		 */
		if (encrypted_password)
			authenticated = 
				(strncmp(encrypted_password, pw_password, MAX_PASSWORD_LEN) == 0);
		else
			authenticated = 0;

          if (authenticated)
               vos_login_violation (authctxt, LOGIN_RESET_VIOLATIONS);
          else vos_login_violation (authctxt, LOGIN_ADD_VIOLATIONS);
	}

	return authenticated;
}

/*--------------- vos_login_violation() ------------------*/

/* Update the VOS counter that records
   the number of consequtive bad passwords, and
   terminate the account if the limit is exceeded. 
   If there is no limit for this user, don't track
   the changes.  This code is similar to login_violation in
   login.pl1. Declared as static as it's only used in this
   port.c file. */

static void
vos_login_violation (Authctxt *p_authctxt, const short int p_violation)
{

char_varying(66) module_name;
char_varying(32) person;
struct passwd *pw = p_authctxt -> pw;
struct spwd *spw;
short int num;
short int code;
short int open_attempts;
long int sleep_time;
short int violation;

/* Note:  In a multi-module VOS system, a copy of the VOS
   password database is maintained on each module, and one copy
   is the master copy.  The getspnam function reads the values
   from the copy of the database on the current module, but the
   s$set_login_violations subroutine updates the master copy and
   then broadcasts it to the other modules.  Therefore, the
   shadow password values returned by getspnam will lag behind
   the values in the master copy.  A user may actually get more
   attempts to login than VOS allows if a single SSH
   authentication session does not hit the VOS limit.  */

     strcpy_vstr_nstr (&module_name, "");

     violation = p_violation;
     num = 0;
     switch (violation)
     {
          case (LOGIN_RESET_VIOLATIONS):

                    // begin ssl-311
                    num = -1;
                    spw = getspnam (pw->pw_name);
                    if (spw != NULL)
                         if (spw->sp_num_login_violations > 0)
                              num = 0;
                    // end ssl-311

                    break;

          case (LOGIN_ADD_VIOLATIONS):
                    num = -1;
                    spw = getspnam (pw->pw_name);
                    if (spw != NULL)
                    {
                         if (spw->sp_max_bad_logins > 0)
                         {
                              num = spw->sp_num_login_violations + 1;
                              if (num >= spw->sp_max_bad_logins)
                                   violation = LOGIN_TERMINATE_ACCOUNT;
                         }
                    }
                    break;

          case (LOGIN_TERMINATE_ACCOUNT):
          default:;
                    num = 1;
                    break;
     }

     if (num >= 0)
     {
          strcpy_vstr_nstr (&module_name, "");
          strcpy_vstr_nstr (&person, pw->pw_name);
          open_attempts = 0;
          sleep_time = 2 * 1024;
          s$set_login_violations (&module_name, &person, &violation,
               &num, &code);
          while (code == e$file_in_use && open_attempts < 30)
          {
               ++open_attempts;
               s$sleep (&sleep_time, &code);
               s$set_login_violations (&module_name, &person, &violation,
                    &num, &code);
          }
          if (code)
               logit("Unable to set bad password count for account %.100s to %d",
                    pw->pw_name, num);
     }
}

/*--------------- sys_auth_record_login() ------------------*/

/* With CUSTOM_SYS_AUTH_RECORD_LOGIN enabled we define
 * VOS version of sys_auth_record_login(). This function is
 * called by login_write when a user logs in.
 * Returns 1 if successful, 0 if not successful.
 */

int
sys_auth_record_login(const char *user, const char *host, const char *ttyname, struct sshbuf *loginmsg)
{
     return 1;
}

/*--------------- record_failed_login() ------------------*/

/* With CUSTOM_FAILED_LOGIN enabled we define VOS version
 * of record_failed_login(). This function is called when
 * a password-based authentication fails.  */

void
record_failed_login(struct ssh *ssh, const char *user, const char *hostname, const char *ttyname)
{
     short int code;
     short int msg_code;
     char_varying (256) comments_vs;
     char_varying (256) temp_vs;
     char_varying (32) user_vs;

     strcpy_vstr_nstr (&user_vs, user);
     strcpy_vstr_nstr (&temp_vs, "login ");
     strcat_vstr_nstr (&temp_vs, user);
     strcat_vstr_nstr (&temp_vs, " (from host ");
     strcat_vstr_nstr (&temp_vs, hostname);
     strcat_vstr_nstr (&temp_vs, ") (via ");
     strcat_vstr_nstr (&temp_vs, ttyname);
     strcat_vstr_nstr (&temp_vs, ")");
     msg_code = e$login_access_denied;
     strcpy_vstr_nstr (&comments_vs, "");
     s$security_log_write (&user_vs, &temp_vs, &msg_code,
          &comments_vs, &code);
}

/*--------------- vos_terminated_user() ------------------*/

/* Check if a user's account is valid or terminated. 
 * This routine has to be called by a privileged process.
 * We check sp_vos_flags_account_terminated which 
 * gets toggled by registration_admin and then call
 * auth_shadow_acctexpired() for additional checks. */

short int vos_terminated_user(Authctxt *authctxt, int (*ptr)(struct spwd *spw), ServerOptions *options)
{
     short int terminated=0;
     struct spwd *spw = NULL;
	
     debug_f("entering");

     if ((spw = getspnam(authctxt->user)) == NULL) {
          error("Could not get shadow information for %.100s", authctxt->user);
          return (terminated);
     }

     /* Check if VOS registration has already terminated account. */
     if ((spw->sp_vos_flags & sp_vos_flags_account_terminated))
     {
          /* (ssl-691) root's VOS registration record is always terminated
           * but mark record as valid under the following conditions:
           *   -- external authentication is ON 
           *   -- we are allowing root logins
           *   -- we are indeed root
           */

          if ((authctxt->pw->pw_vos_flags & _PASSWD_VOS_EXT_AUTHENTICATION) &&
              (options->permit_root_login == PERMIT_YES) &&
              ((authctxt->pw->pw_uid==0) && (authctxt->pw->pw_gid==0)))
          {
               terminated=0;
          }else{
               terminated=1;
          }
     }else if((terminated=(*ptr)(spw)))
     {
          /* If we haven't terminated the user do so now. */
          vos_login_violation (authctxt, LOGIN_TERMINATE_ACCOUNT);
     }

     debug_f("user %s account %s",
          spw->sp_namp, terminated ? "terminated" : "valid");

     return (terminated);
}

/*--------------- set_cli_support() ------------------*/

static void set_cli_support(void)
{
     short code = 0;
     cv32 entry_name;
     short flags = 0;
     lka_type lka;
     short module_id = 0;

     strlcpy_vstr_nstr(&entry_name, "s$stop_program_do_cli", 32);
     s$lookup_kernel_address (&module_id, &entry_name, &flags, &lka, &code);
     if (code) {
          gbl_cli_support = 0; /* not found */
     }

     gbl_cli_support = 1; /* found */
}

/*--------------- check_cli_support() ------------------*/

int check_cli_support(void){
     if (gbl_cli_support < 0){
          set_cli_support();
     }
     return(gbl_cli_support);
}

/*--------------- check_mux_flag_support() ------------------*/

int check_mux_flag_support(void){
     return(gbl_vos_mux_use_flag);
}

/*--------------- get_acl() ------------------*/

static ACL *
get_acl (const char_varying *path, int type, ACL **aclpp, short *codep)
{
     ACL  *path_acl = *aclpp;
     short     code = 0;
     short     max = 4;

     for(;;)
     {
          if (!path_acl)
          {
               size_t s = sizeof(ACL) + sizeof(ACL_ENTRY)*max;

               path_acl = xmalloc(s);
               path_acl->max_entries = max;
               path_acl->num_entries = 0;
          }

          if (type == CHECK_DEFAULT_ACL)
          {
               s$get_default_access_list( path, &path_acl->max_entries,
                                          &path_acl->num_entries, 
                                          path_acl->entries, &code);
          }
          else
          {
               s$get_access_list( path, &path_acl->max_entries,
                                  &path_acl->num_entries, 
                                  path_acl->entries, &code);
          }

          if (code != e$too_many_entries)
          {
               *codep = code;
               *aclpp = path_acl;
               char path_str[MAX_PATH+1];

               strncpy_nstr_vstr (path_str, path, MAX_PATH);
               path_str[MAX_PATH] = '\0';
               debug3("secure_filename: ACL for '%s'", path_str);

               if (!code && path_acl)
               {
                    int k;
                    for (k = 0; k < path_acl->num_entries; k++)
                    {
                         char name[66];

                         strncpy_nstr_vstr(name, &(path_acl->entries[k].user_name), 65);
                         name[65] = '\0';
                         debug3("secure_filename: %c for %s",
                                path_acl->entries[k].access_code, name);
                    }
               }

               return path_acl;
          }

          max = path_acl->num_entries;
          free(path_acl);
          path_acl = NULL;
     }
}

/*--------------- check_acls() ------------------*/

static int 
check_acls(const char *path, const char *pw_name, int type,
           char *indexstr, ACL  *p_master_acl, ACL **p_aclpp)
{
     ACL  *path_acl = NULL;
     int  j, k;
     int  namelen;
     cvPATH_MAX path_out;
     short code;
     char write_access_code;

     strncpy_vstr_nstr(&path_out, path, MAX_PATH);
     indexstr[0] = '\0';

     path_acl = get_acl (&path_out, type, p_aclpp, &code);
     if (code)
          goto error_return;

     if (path_acl->num_entries <= 0)
     {
          /* No ACL at all means a directory can't be accessed by
             anybody; so, it's kind of useless.
             For a file, no ACL just means the default ACL must
             be checked.  */

          if (type == CHECK_FILE)
               code = -2;
          else
               code = -1;

          goto error_return;
     }

     if (type == CHECK_DIR)
          write_access_code = 'm';
     else
          write_access_code = 'w';

     namelen = strnlen(pw_name, 65);

     debug3("secure_filename: User name = %s, len = %d", pw_name, namelen);
                                  
     /* Loop through all the ACL entries.  */

     for (j = 0; j < path_acl->num_entries; j++)
     {
          char user_name[66];

          char access_code = path_acl->entries[j].access_code;

          /* If this isn't modify or write, we don't
             care about it.  */

          if (access_code != write_access_code)
               continue;

          /* Get a copy of the user name we can substring. */
          strncpy_nstr_vstr (user_name, &(path_acl->entries[j].user_name), 65);
          user_name[65] = '\0';

          /* Any ACL entry beginning with the user name followed by a '.'
             is OK.  */

          if ( memcmp(pw_name, user_name, namelen) == 0
            && user_name[namelen] == '.' )
               continue;

          /* The only other good modify/write entries are those in the
             ACL for the master disk.  */

          for (k = 0; k < p_master_acl->num_entries; k++)
          {
               char master_access_code = p_master_acl->entries[k].access_code;

               /* Only look at modify/write entries.  */
               if (master_access_code != 'm')
                    continue;

               /* If the names match, stop looking.  */
               if (!strcmp_nstr_vstr(user_name, 
                                   &(p_master_acl->entries[k].user_name)))
                    break;
          }

          /* This is not a good ACL entry.  */

          if (k >= p_master_acl->num_entries)
          {
               snprintf(indexstr, MAX_INDEXSTR, " (entry %d)", j+1);
               debug3("secure_filename: Failed Entry = %d", j);
               code = -1;
               goto error_return;
          }
     }

     code = 0;

error_return:
     return code;
}

/*--------------- auth_secure_path() ------------------*/

/*
 * Check a given directory for security. The Unix definition is all components
 * of the path to the file must be owned by either the owner of
 * of the file or root and no directories must be group or world writable.
 * The VOS equivalent of this is going to ensure that any modify/write ACL 
 * entries for the path and it's parent directories either begin with the 
 * user name from the passwd structure OR appear on the master disk.
 *
 * Takes an optional open file descriptor, the file name, the stat structure
 * for the file, the user home dir, the user name, and an error buffer
 * (plus max buffer size) as arguments.
 *
 * Returns 0 on success and -1 on failure
 */

int
vos_auth_secure_path(const char *name, struct stat *stp, const char *pw_dir,
     const char *pw_name, char *err, size_t errlen)
{
     ACL  *master_acl = NULL;
     ACL  *path_acl = NULL;
     cv66 master_disk;
     char buf[MAX_PATH+1], homedir[MAX_PATH+1];
     char indexstr[MAX_INDEXSTR];
     int comparehome = 0;
     int j;
     int ret = -1;
     cv66 module_name;
     cvPATH_MAX expanded_path;
     cvPATH_MAX path_out;
     short type;
     short code;

     strncpy_vstr_nstr(&module_name, "", 0);
     s$get_master_disk(&module_name, &master_disk, &code);
     if (code)
     {
          snprintf(err, errlen, "Master disk:  %s", strerror(code));
          goto error_return;
     }

     get_acl (&master_disk, CHECK_DIR, &master_acl, &code);
     if (code)
     {
          strcpy_nstr_vstr(buf, &master_disk);
          snprintf(err, errlen, "%s:  %s", buf, strerror(code));
          goto error_return;
     }

     /* perform the same steps as realpath(name) but leave the
        final pathname in VOS form.  */

     s$c_expand_path (&name, &expanded_path, &code);
     if (code)
     {
          snprintf(err, errlen, "%s:  %s", name, strerror(code));
          goto error_return;
     }

     s$where_path (&expanded_path, &path_out, &type, &module_name,
          &code);
     if (code)
     {
          strcpy_nstr_vstr(buf, &expanded_path);
          snprintf(err, errlen, "%s:  %s", buf, strerror(code));
          goto error_return;
     }

     strcpy_nstr_vstr(buf, &path_out);

     /* perform the same steps as realpath(pw_dir) but leave the
        final pathname in VOS form.  */

     if (pw_dir != NULL)
     {
          s$c_expand_path (&pw_dir, &expanded_path, &code);
          if (!code)
          {
               s$where_path (&expanded_path, &path_out, &type,
                    &module_name, &code);
               if (!code)
               {
                    strcpy_nstr_vstr(homedir, &path_out);
                    comparehome = 1;
               }
          }
     }
     
     if (!S_ISREG(stp->st_mode))
     {
          snprintf(err, errlen, "%s is not a regular file", buf);
          return -1;
     }

     if ( (code = check_acls(buf, pw_name, CHECK_FILE, indexstr,
                    master_acl, &path_acl)) 
       && code != -2)
     {
          if (code > 0)
               snprintf(err, errlen, "ACL%s for %s:  %s", 
                        indexstr, buf, strerror(code));
          else
               snprintf(err, errlen,
                   "Bad ACL%s for file %s", indexstr, buf);
          goto error_return;
     }

     /* for each component of the canonical path, walking upwards */
     for (j = strlen(buf); j > 0; j--)
     {
          if (buf[j] != '>')
               continue;

          buf[j] = '\0';

          if (code == -2)
          {
               if ((code = check_acls(buf, pw_name, CHECK_DEFAULT_ACL,
                         indexstr, master_acl, &path_acl)))
               {
                    if (code > 0)
                         snprintf(err, errlen, "Default ACL for %s:  %s", 
                                  buf, strerror(code));
                    else
                         snprintf(err, errlen, 
                                  "Bad default ACL%s for directory %s", 
                                  indexstr, buf);
                    goto error_return;
               }
          }

          if ((code = check_acls(buf, pw_name, CHECK_DIR, indexstr,
                         master_acl, &path_acl)))
          {
               if (code > 0)
                    snprintf(err, errlen, "ACL for %s:  %s", 
                             buf, strerror(code));
               else
                    snprintf(err, errlen, "Bad ACL%s for directory %s", 
                             indexstr, buf);
               goto error_return;
          }

          /* If past the homedir then we can stop */
          if (comparehome && strcmp(homedir, buf) == 0) 
               break;
     }

     ret = 0;

error_return:
     if (master_acl)
          free(master_acl);

     if (path_acl)
          free(path_acl);

     return ret;
}

/*--------------- isvosname() ------------------*/

/* Returns 1 (true) if the string we're pointing to is the start
 * of a VOS pathname or module name of the form "%system#".
 * Otherwise returns 0 (false).
 */
int isvosname(const char *vospath){
     char *hashptr;
     char_varying(MAX_PATH) name_vs;
     int namelen;
     extern int s$found_sys_or_dev_name (char_varying *);

     /* Sanity check */

     if (vospath[0] != '%')
          return 0;

	/* We interpret any input value of the form "%xxx#..."
	 * as the start of a VOS name. This allows any system
	 * name, device name, or path name to be recognized.
	 * We don't verify characters after the "#".
	 */

     if ((hashptr = strchr (vospath, '#')) == NULL)
          return 0;

     /* Include the leading "%" in the name */

     if ((namelen = hashptr - vospath) > MAX_PATH)
          return 0;

     strncpy_vstr_nstr (&name_vs, vospath, namelen);

     if (s$found_sys_or_dev_name (&name_vs) == 0)
          return 0;

     return 1;
}

/*--------------- vos_write_pty_env() ------------------*/

/* Action: Sets the following environment variables:
 *             NO_SERV_OK
 *             PTY
 *             VPARM
 *         Used in conjunction with vos_read_pty_env().
 *
 * Output: 0 (success), -1 (failure)
 */

int
vos_write_pty_env(char *device_name, int master_fd, int slave_fd, 
                  vos_service_params *params)
{

     char bufpty[MAX_PTY_BUF];
     char bufvparm[MAX_VPARM];

     if (snprintf(bufpty, sizeof(bufpty), "%s,%d,%d", device_name, master_fd, slave_fd)<0){
          error_f("snprintf for PTY failed");
          return 0;
     }

     setenv("PTY", bufpty, 1);

     debug2_f("PTY=%s", bufpty);

     if (snprintf(bufvparm, sizeof(bufvparm), "%d,%d,%d,%d,%d,%d,%d,%s", 
                  params->privileged_sw,
                  params->disable_requests, 
                  params->disable_x11,
                  params->use_shell, 
                  params->permit_root_login,
                  params->permit_sysadmin,
                  params->service_index,
                  params->service_name) < 0)
     {
          error_f("snprintf for VPARM failed");
          return 0;
     }

     setenv("VPARM", bufvparm, 1);

     debug2_f("VPARM=%s", bufvparm);

     return 1;
}

/*--------------- vos_closefrom_fallback() ------------------*/

void
vos_closefrom_fallback(int lowfd)
{
	int port_fd;
	short ll_port, lh_port, hl_port, hh_port;
	short port, log, org, type, access, err;
	cv256 path_name;
	cv32  port_name;

	s$get_port_ranges(&ll_port, &lh_port, &hl_port, &hh_port);

	for(port=TERMINAL_PORT_ID; port<=lh_port; port++){

		char cpath[256]="";

		s$get_port_attachment(&port, 
							&path_name,
							&port_name,
							&log,
							&org,
							&type,
							&access,
							&err);

		port_fd = (int) (port - 2);

		strlcpy_nstr_vstr(cpath, &path_name, sizeof(cpath));

          /* Honor the closefrom() request as best we can in spite of
           * not being able to close the following ports:
           *  
           *  - VOS port 1 DEFAULT_INPUT_PORT_ID
           *  - VOS port 2 TERMINAL_OUTPUT_PORT_ID
           *  - VOS port 3 COMMAND_INPUT_PORT_ID
           *  - VOS port 4 DEFAULT_OUTPUT_PORT_ID
           *  - ports attached to: server queues,
           *                       master end of PTY,
           *                       slave end of PTY,
           *                       MUX devices for WTM (like s$pt_al.*)
           */

		if((org!=SERVER_QUEUE_FILE) && 
				((org==STREAMS_TYPE) && (strstr(cpath, PT_DEVICE)==NULL)) && 
				(port_fd!=master_fd_ext) &&
				(port_fd!=slave_fd_ext) &&
				(port_fd>=lowfd)){
			     close(port_fd);
		}
	}
}

/*=====================================================================*/
/*================= SECTION: sshd functions ===========================*/
/*=====================================================================*/

/*--------------- vos_sshd_setup() ------------------*/

/* The great refactoring! SSH deciced to break up sshd daemon into
 * 3 binaries: sshd, sshd-session, and sshd-auth. This splits our
 * calls to WTM down the middle. Since we need a device list in memory
 * to update it as connections come in we chose to have the the bulk
 * of our calls in sshd. So any VOS specific info will be passed
 * over to ssh-session via environment values passed to execve().
 * This includes the port numbers for the master/slave devices
 * which we create before the execve and before SSH forks a child 
 * to service the connection To make sure the ports survive the
 * execve() we set them with FD_CLOEXEC. Better to run this code
 * AFTER closefrom()/closefrom_fallback() do their fd cleanup.
 */

int vos_sshd_setup(int listener_index){

     vos_service_params params;
     char device_name[MAX_PTY_NAME]; /* defined by vos_slave_services.h */
     int master_fd = -1;
     int slave_fd = -1;
     int flags;
     int status;

     /* default_services: the global flag which gets set to 1 when
      *                   /opt/openssl/etc/sshservices is NOT available.
      *                   For example when running the SSH self-tests.
      *
      * listener_index: Gets set anytime a connection comes in. When
      *                 it remains -1 it's probably because SSHD is
      *                 acting as a proxy.
      */

     if((default_services) || (listener_index == -1)){
         /* Set ENV variable to let ourselves know after
          * the exec() in sshd-session and sshd-auth that the
          * other ENV variables (VPARM, PTY) are not available
          */
         setenv("NO_SERV_OK", "1", 1);
         return(1);
     }

     if (vos_pty_find_service(&params, listener_index, STDIN_FILENO))
     {
          return(0);
     }

     if ((status = vos_pty_allocate(&params, device_name, &master_fd, 
                                    &slave_fd)) <= 0) {
          return(0);
     }

     if ((flags=fcntl(master_fd, F_GETFD)) == -1){
          return(0);
     }

     flags &= ~FD_CLOEXEC;
     if (fcntl(master_fd, F_SETFD, flags) == -1){
          return(0);
     }

     if (slave_fd != VOS_SLAVE_NON_FD){

          if ((flags=fcntl(slave_fd, F_GETFD)) == -1){
               return(0);
          }

          flags &= ~FD_CLOEXEC;
          if (fcntl(slave_fd, F_SETFD, flags) == -1){
               return(0);
          }
     }

     /* Write out the string values for PTY and VPARM. */
     if (!vos_write_pty_env(device_name, master_fd, slave_fd, &params)){
          return(0);
     }

     return(1);
}

/******************************************************************
 *   Function: get_socket_count
 *   Output:   # of sockets sshd currently knows about.
 *   Action:   First, pick up the number of sockets
 *             If it comes up 0, pick up the correct count from
 *             the local copy; otherwise, update the local copy of
 *             the count to the current value.
 ****************************************************************/

static int 
get_socket_count(void)
{
     if (current_num_socks <= 0){
          return 1;
     }

     return current_num_socks;
}

/******************************************************************
 *   Function: fill_socket_info
 *   Input:    Index of the socket in the socketsp and 
 *             ssh_socket_info_table arrays.
 *   Action:   Gets the local address for the socket.
 *             Looks up the service name associated with the IP.
 *             Puts the info into the ssh_socket_info_table entry.
 *
 ****************************************************************/

static void
fill_socket_info(int j)
{
     int                 err;
     sockaddr_union      socket_addr;
     int                 socket_addrlen = sizeof(struct sockaddr_in6);
     struct servent *    sep;
     ssh_socket_info *   sp = ssh_socket_info_table + j;
     uint16_t            port = -1;

     err = getsockname (listen_socks[j], 
                        (struct sockaddr *) &socket_addr,
                        &socket_addrlen);
     if (!err)
     {
          port = (socket_addr.v4.sin_family == AF_INET) ? 
                  socket_addr.v4.sin_port : socket_addr.v6.sin6_port;

          sep = getservbyport(port, 0);
     
          if (sep || port == 22)
          {
               char * name = (sep) ? sep->s_name : "ssh";
     
               strlcpy (sp->service_name, name, 36);
               sp->service_name[35] = '\0';
               sp->local_port = port;
               return;
          }
     }

     /* If this port is not tied to a service we still need to write
      * out some string (aka. "null") because value will be read by
      * sshd-session program. */
     strlcpy (sp->service_name, "null", 36);
     sp->service_name[35] = '\0';
     sp->local_port = port;
     sp->service_index = -1;
}

static void ssherror(const char *fmt,...)
{
	va_list args;

	va_start(args, fmt);
	sshlogv(__FILE__, __func__, __LINE__, 0, SYSLOG_LEVEL_ERROR, NULL, fmt, args);
	va_end(args);
}

/*--------------- set_num_socks() ------------------*/

void set_num_socks(int num_listen_socks){
     current_num_socks = num_listen_socks;
}

/******************************************************************
 *   Function: vos_ssh_init_pt
 *   Input:
 *        The maximum number of sockets or zero if called in the inetd case.
 *        The socket number to use in the inetd case.
 *
 *   Output:   0 for success, -1 for failure.
 *             s$pt_perror is called whenever a failure is returned.
 *   Action:   Set up the socketsp array.
 *             Initialize the ssh_socket_info_table for the sockets opened.
 *             by sshd.
 *             Call s$pt_initialize and s$pt_init_services to initialize
 *             the services database and open the "sshservices" file.
 *
 ****************************************************************/

int vos_ssh_init_pt(void)
{
     int j;
     int num_sockets;

     s$pt_set_perror_log_routine (ssherror);    /* ssl-201 */

     max_sockets = MAX_LISTEN_SOCKS; /* init global */

     num_ssh_services = 0;
     num_sockets = get_socket_count();

     for( j = 0; j < num_sockets; j++ )
     {
          fill_socket_info(j);
     }

     /* Initialize the service database. */

     if (s$pt_initialize(&ssh_callbacks, 0, NULL, NULL) < 0)
     {
          s$pt_perror("");
          return -1;
     }

     /* Read the "sshservices" file into the service database.  This
        may result in calls to vos_ssh_is_service_supported, 
        vos_ssh_new_service, vos_ssh_service_available and
        several s$ip_ routines.  */

     if (s$pt_init_services( ">opt>openssl>etc>sshservices") < 0)
     {
          s$pt_perror("");

          default_services = 1;

          if (s$pt_default_service() < 0)
          {
               s$pt_perror("Initializing default services.");
               return -1;
          }
     }

     return 0;
}

/*--------------- clear_can_add_sockets() ------------------*/

void clear_can_add_sockets(){
     can_add_sockets = 0;
}

/******************************************************************
 *   Function: vos_ssh_is_service_supported
 *             This is called by the s$pt library to determine if
 *             the deamon can support a given service.
 *
 *   Input:    service name
 *
 *   Output:   Whether this daemon supports that service.
 *
 *   Action:   Search the existing sockets for a match on the service name.
 *             If not found, return false for the inetd case (can't add 
 *             sockets) or true for the standalone case, because
 *             we can add more sockets.  We don't check the max here, because
 *             we want to know if the array limit is hit.
 *
 ****************************************************************/

static int  
vos_ssh_is_service_supported(const char* p_service_name)
{
     int j;
     int num_sockets = get_socket_count();

     /* If it's in our list, we support it. */

     for( j = 0; j < num_sockets; j++ )
     {
          if ( !strncmp( ssh_socket_info_table[j].service_name, 
                                                  p_service_name, 35)
            || ( ssh_socket_info_table[j].local_port == 22 
              && default_services ) )
          {
               return 1;
          }
     }

     /* We also support it if we can add sockets to the array.  */

     return (current_num_socks != 0 && can_add_sockets);
}

/******************************************************************
 *   Function: tokencmp
 *             Compare tokens and allow some differnt word separation 
 *             conventions within the token:  '_', '-' or camel case.
 *             The main reason for doing this is because SSH uses
 *             camel case in the sshd_config file and Unix tends
 *             to use '-' instead of '_'.
 *
 *   Input:    A string contsant template.  Known to be nul terminated.
 *                  It must be lower case with '_' separating words
 *                  and may begin with a single '-'.
 *             A token pointer and length.  Not nul terminated.
 *
 *   Output:   Standard string compare output:
 *                  < 0 --> A < B
 *                 == 0 --> A == B
 *                  > 0 --> A < B
 *
 *   For camel case we allow the first letter to be upper
 *   or lower case when the token doens't begin with '-', but it it
 *   follows the initial '-', the first character must be a cap
 *   to match camel case.  So with a template of "-foo_bar"  The 
 *   following are matches:
 *
 *          -foo_bar
 *          --foo_bar
 *          -foo-bar
 *          --foo-bar
 *          -FooBar
 *          --FooBar
 *
 *   With the template "foo_bar", the following are matches:
 *
 *          foo_bar
 *          foo-bar
 *          fooBar
 *          FooBar
 *
 ****************************************************************/

static int
tokencmp(const char *template, const char *tokenp, int token_len)
{
     int j = 0;
     int k = 0;
     int camelCase = -1; /* Unknown. */

     if (template[j] == '-' && k < token_len && tokenp[k] == '-')
     {
          j++;
          k++;

          if (k < token_len && tokenp[k] == '-')
               k++;
     }
     if ( template[j] >= 'a' && template[j] <= 'z' 
       && (int) template[j] == (int) tokenp[k] + ('a' - 'A') )
     {
          camelCase = 1;
          j++;
          k++;
     }
     else if (j > 0)
     {
          /* Without a '-' in front, we'll let the first character
             for camel case be UC or LC.  But with the '-', we want
             UC for the first character when doing camel case.  */

          camelCase = 0;
     }

     for (; template[j] && k < token_len; j++, k++)
     {
          if (template[j] != '_')
          {
               if (template[j] != tokenp[k])
                    break;

               continue;
          }

          if (camelCase)
          {
               if ( template[j+1] < 'a' || template[j+1] > 'z'
                 || (int) template[j+1] != (int) tokenp[k] + ('a' - 'A') )
               {
                    if (camelCase == 1)
                         break;

                    /* Now we know it's not camel case. */
                    camelCase = 0;

                    /* Drop through to the '_' / '-' compare. */
               }
               else
               {
                    /* Now we know it's camel case. */
                    camelCase = 1;
                    j++;
                    continue;
               }
          }

          if (tokenp[k] != '_' && tokenp[k] != '-')
               break;
     }

     if (template[j])
     {
          unsigned short a;
          unsigned short b;

          if (k >= token_len)
               return 1;

          a = template[j];
          b = tokenp[k];

          if (a == '_' && b == '_' && camelCase)
               return -1;

          else if (b >= 'A' && b <= 'Z')
               b += ('z' - 'Z');

          return a - b;
     }
     else if (k < token_len)
     {
          return -1;
     }

     return 0;
}

/******************************************************************
 *   Function: vos_ssh_new_service
 *
 *        This is called by the s$pt library to do whatever is
 *        necessary to support listening for incoming connections
 *        on that service.
 *
 *   Input:    
 *        p_service_namep     The service name
 *        p_login             Whether or not it's a login service
 *        p_proto_optionsp    The protocol options string (none for SSH, now)
 *        p_descriptionp      The description of the service.
 *        p_tsp               The service node in the internal database.
 *
 *   Output:
 *        *p_servicepp is set to service node visible to this code.
 *        Returns -1 for error, 0 for success.
 *
 *   Action:
 *        Look for the service in the sockets that are already open.
 *        If not found, setup a new socket for the service (find port 
 *             number, get socket, set socket options, bind and listen).
 *        Fill in the new socket data structure.
 ****************************************************************/

static int  
vos_ssh_new_service(
     const char * p_service_namep,
     int p_login, 
     const char * p_proto_optionsp,
     const char * p_descriptionp,
     struct svc_node* p_tsp,
     struct protocol_service **p_servicepp)
{
     int j = num_ssh_services;
     ssh_service *sp = ssh_service_table + j;
     int k;
     int num_matched = 0;
     int num_sockets = get_socket_count();
     int new_socket_fd = -1;
     int disable_requests = !p_login;
     int disable_x11 = !p_login;
     int use_shell = 0;
     int permit_root_login = PERMIT_NO;
     int permit_sysadmin = 1;
     int have_options = 0;
     const char *login_slave = (p_login) ? "Login" : "Slave";

     if (*p_proto_optionsp)
     {
          /* Parse the protocol options.  */

          int offset = 0;
          const char *tokenp;
          int token_len;

          for (;;)
          {
               offset = s$pt_parse_token(p_proto_optionsp, offset, 
                                         &tokenp, &token_len);
               if (token_len <= 0)
                    break;

               have_options = 1;

               if (!tokencmp("-enable_requests", tokenp, token_len))
               {
                    disable_requests = 0;
               }
               else if (!tokencmp("-disable_requests", tokenp, token_len))
               {
                    disable_requests = 1;
               }
               else if (!tokencmp("-enable_x11", tokenp, token_len))
               {
                    disable_x11 = 0;
               }
               else if (!tokencmp("-disable_x11", tokenp, token_len))
               {
                    disable_x11 = 1;
               }
               else if (!tokencmp("-shell", tokenp, token_len))
               {
                    use_shell = 1;
               }
               else if (!tokencmp("-no_sysadmin", tokenp, token_len))
               {
                    permit_sysadmin = 0;
               }
               else if (!tokencmp("-permit_root_login", tokenp, token_len))
               {
                    offset = s$pt_parse_token(p_proto_optionsp, offset,
                                         &tokenp, &token_len);
                    if (token_len <= 0)
                         break;

                    if (!tokencmp("yes", tokenp, token_len))
                    {
                         permit_root_login = PERMIT_YES;
                    }
                    else if (!tokencmp("prohibit_password", tokenp, token_len))
                    {
                         permit_root_login = PERMIT_NO_PASSWD;
                    }
                    else if (!tokencmp("forced_commands_only", tokenp, 
                                        token_len))
                    {
                         permit_root_login = PERMIT_FORCED_ONLY;
                    }
                    else if (!tokencmp("no", tokenp, token_len))
                    {
                         permit_root_login = PERMIT_NO;
                    }
                    else 
                    {
                         return set_errno(e$invalid_arg_format);
                    }
               }
               else 
               {
                    return set_errno(e$invalid_arg_format);
               }
          }
     }

     if (num_ssh_services >= VOS_MAX_SERVICE_ENTRIES)
     {
          return set_errno(e$too_many_entries);
     }

     /* Update ssh_service_table entry */
     sp->servicep = p_tsp;
     strlcpy (sp->service_name, p_service_namep, 36);
     sp->service_name[35] = '\0';
     sp->is_login = p_login;
     sp->slave_available = 0;
     sp->disable_requests = disable_requests;
     sp->disable_x11 = disable_x11;
     sp->use_shell = use_shell;
     sp->permit_sysadmin = permit_sysadmin;
     sp->permit_root_login = permit_root_login;

     for( k = 0; k < num_sockets; k++ )
     {
          if ( !strncmp( ssh_socket_info_table[k].service_name, 
                                                  p_service_namep, 35)
            || ( ssh_socket_info_table[k].local_port == 22 
              && default_services ) )
          {
               if (num_matched++ > 0)
               {
                    if (sp->local_port != ssh_socket_info_table[k].local_port)
                    {
                         /* This can't happen unless the Internet database
                              is broken.  */

                         error("%s service defined on port %d and port %d.",
                              p_service_namep,  
                              sp->local_port, 
                              ssh_socket_info_table[k].local_port);
                         continue;
                    }
               }
               else
                    sp->local_port = ssh_socket_info_table[k].local_port;

               ssh_socket_info_table[k].service_index = j + 1;

               debug2_f("Socket #%d [index=%d], fd %d, points to service %s, (#%d).", k, ssh_socket_info_table[k].service_index, 
                      listen_socks[k], p_service_namep, j);
          }
     }

     if (num_matched == 0)
     {
          debug_f("No socket match for service %s.", p_service_namep);
     }

     num_ssh_services++;

     if (have_options)
          logit("%s service %s (#%d) port %d, reqs %d, x11 %d, "
                    "shell %d, sysadmin %d, root %d.", 
                login_slave, p_service_namep, j, sp->local_port, 
                sp->disable_requests, sp->disable_x11, sp->use_shell,
                sp->permit_sysadmin, sp->permit_root_login);
     else 
          logit("%s service %s (#%d) is on port %d.", login_slave, 
                p_service_namep, j, sp->local_port);

     /* pointer to ssh_service_table entry goes back to 
      * protocol_service pointer */

     *p_servicepp = sp;
     return 0;

error_return:
     if (new_socket_fd >= 0)
          close(new_socket_fd);
     return -1;
}


/******************************************************************
 *   Function: vos_ssh_service_available
 *             This is called by the s$pt library when at least one 
 *             slave terminal is available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as being available:  We need to 
 *             know whether to accept incoming slave connections.
 *
 ****************************************************************/

static int 
vos_ssh_service_available(
     struct protocol_service *p_servicep)
{
     p_servicep->slave_available = 1;
     return 0;
}

/******************************************************************
 *   Function: vos_ssh_service_unavailable
 *             This is called by the s$pt library when no slave 
 *             terminals are available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as not being available:  We need to 
 *             know whether to accept incoming slave connections.
 *
 ****************************************************************/

static void 
vos_ssh_service_unavailable(
     struct protocol_service *p_servicep)
{
     p_servicep->slave_available = 0;
}

/******************************************************************
 *   Function: vos_ssh_service_modified
 *             This routine is called whenever the service database
 *             is modified by an external admin command.
 *   Input:    The service node visible to this code.
 *             Whether it is available.
 *             The protocol options string.
 *             The description.
 *   Output:   Returns -1 for failure, 0 for success.
 *   Action:   Report an error if protocol options were given.
 *             Don't need to do anything else, because all other
 *             attributes are either unused or supported dynamically.
 *
 ****************************************************************/

static int  
vos_ssh_service_modified(
     struct protocol_service *p_servicep, 
     int p_available,
     const char * p_proto_optionsp,
     const char * p_descriptionp)
{
     p_servicep->slave_available = p_available;

     if (*p_proto_optionsp)
     {
          return set_errno(e$invalid_arg_format);
     }

     return 0;
}

/******************************************************************
 *   Function: vos_pty_find_service
 *   Return: 0=pass, non-zero=fail
 ****************************************************************/

static int
vos_pty_find_service(
     struct vos_service_params *p_spp, 
     int listener_index,
     int p_socket)
{
     int                 j;
     int                 priv_sw = 0;
     sockaddr_union      remote_addr;
     int                 remote_addrlen = sizeof(struct sockaddr_in6);
     sockaddr_union      local_addr;
     int                 local_addrlen = sizeof(struct sockaddr_in6);
     ssh_service        *sp = 0;
     ssh_socket_info    *pp = ssh_socket_info_table + listener_index;

     debug_f("listener_index=%d, p_socket=%d", listener_index, p_socket);

     if (listener_index < 0 || listener_index >= get_socket_count())
     {
          error_f("Bad socket index (%d)", listener_index);
          goto error_return;
     }

     /* Figure out who is connecting.  */

     if (getpeername (p_socket, (struct sockaddr *) &remote_addr,
                      &remote_addrlen) < 0)
     {
          /* allow this for self-tests. */

          _IN6_SET_ADDR_ANY(&p_spp->remote_ip);
          p_spp->remote_port = 0;
          _IN6_SET_ADDR_ANY(&p_spp->local_ip);
          p_spp->local_port = 0;
          p_spp->service_index = -1;
          p_spp->login_dev = NULL;
          p_spp->privileged_sw = 0;
          p_spp->disable_requests = 0;
          p_spp->disable_x11 = 0;
          p_spp->use_shell = 0;
          p_spp->permit_sysadmin = 1;
          p_spp->permit_root_login = PERMIT_NO;
          return 0;
     }

     if (remote_addr.v4.sin_family == AF_INET)
     {
          _IN6_V4_INTO_V4MAPPED(&p_spp->remote_ip, remote_addr.v4.sin_addr.s_addr);
          p_spp->remote_port = remote_addr.v4.sin_port;
     }
     else
     {
          p_spp->remote_ip = remote_addr.v6.sin6_addr;
          p_spp->remote_port = remote_addr.v6.sin6_port;
     }

     /* Figure out which port they connected on (there could be more
        than one adapter).  */

     if (getsockname (p_socket, (struct sockaddr *) &local_addr,
                             &local_addrlen) < 0)
     {
          error_f("getsockname failed: %.100s", strerror(errno));
          goto error_return;
     }

     if (remote_addr.v4.sin_family == AF_INET)
          _IN6_V4_INTO_V4MAPPED(&p_spp->local_ip, local_addr.v4.sin_addr.s_addr);
     else
          p_spp->local_ip = local_addr.v6.sin6_addr;

     p_spp->local_port = pp->local_port;

     /* Get the service for this port.  */

     j = pp->service_index - 1;

     if (j < 0)
     {
          /* This isn't in the services file, but could be used for
             other SSH functions.  */

          p_spp->service_index = -1;
          p_spp->login_dev = NULL;
          p_spp->privileged_sw = 0;
          p_spp->disable_requests = 0;
          p_spp->disable_x11 = 0;
          p_spp->use_shell = 1;
          p_spp->permit_sysadmin = 1;
          p_spp->permit_root_login = PERMIT_NO;
          return 0;
     }

     /* So we know what it came in on.  */

     sp = ssh_service_table + j;
     p_spp->service_index = j;

     debug3_f("service_index=%d", pp->service_index);

     /* Report to sshd-session which service this is */
     strlcpy(p_spp->service_name, sp->service_name, sizeof(p_spp->service_name));
     if (sp->is_login)
     {
          protocol_addrs      addrs;
          char                local_name[257];
          char                remote_name[257];

          addrs.family   = remote_addr.v4.sin_family;
          addrs.local_ip = p_spp->local_ip;
          addrs.remote_ip = p_spp->remote_ip;
          addrs.remote_port = p_spp->remote_port;

          p_spp->login_dev = s$pt_find_login_device (sp->servicep, &addrs, 
                                                     &priv_sw);
          if (!p_spp->login_dev)
          {
               s$pt_perror("vos_pty_find_service");
               goto error_return;
          }

          if (getnameinfo((struct sockaddr *) &local_addr, sizeof(local_addr), 
                          local_name, sizeof(local_name), NULL, 0,
                          NI_NUMERICHOST|NI_NUMERICSCOPE))
               strlcpy(local_name, "???", sizeof(local_name));

          if (getnameinfo((struct sockaddr *) &remote_addr, sizeof(remote_addr), 
                          remote_name, sizeof(remote_name), NULL, 0,
                          NI_NUMERICHOST|NI_NUMERICSCOPE))
               strlcpy(remote_name, "???", sizeof(remote_name));

          debug_f("%s service (#%d, port %d) on %s,%d, from %s,%d.", 
                sp->service_name, j, sp->local_port, 
                local_name, p_spp->local_port, 
                remote_name, addrs.remote_port);

     }
     else if (!sp->slave_available)
     {
          error_f("No devices ready for %.35s service.", sp->service_name);
          goto error_return;
     }

     p_spp->privileged_sw = (priv_sw != 0);
     p_spp->disable_requests = sp->disable_requests;
     p_spp->disable_x11 = sp->disable_x11;
     p_spp->use_shell = sp->use_shell;
     p_spp->permit_sysadmin = sp->permit_sysadmin;
     p_spp->permit_root_login = sp->permit_root_login;
     return 0;

error_return:
     return -1;
}

/******************************************************************
 *   Function: vos_plink_login_pt
 *             This is a glue routine used to call s$pt_plink_login_pt
 *             using privilege separation.
 *   Input:    Same as s$pt_plink_login_pt with the addition of the 
 *             fd for the master end of the pseudo-terminal.
 ****************************************************************/

int
vos_plink_login_pt(struct svc_node *servicep, int tli_fd, int pty_fd,
                   struct svc_device * p_devicep,
                   struct protocol_addrs *p_addrsp, int SEQ_number, 
                   char * p_device_name)
{
     return s$pt_plink_login_pt(servicep, tli_fd, p_devicep, p_addrsp, 
                                SEQ_number, p_device_name);
}

/******************************************************************
 *   Function: vos_plink_slave_pt
 *             This is a glue routine used to call s$pt_plink_slave_pt
 *             using privilege separation.
 *   Input:    Same as s$pt_plink_slave_pt with the addition of the 
 *             fd for the master end of the pseudo-terminal.
 ****************************************************************/

int
vos_plink_slave_pt(const char *p_device_namep, int tli_fd, int pty_fd,
                   int use_protocol, int SEQ_number, short p_msg_port_id,
                   long p_msg_id, char * p_device_name)
{
     return s$pt_plink_slave_pt(p_device_namep, tli_fd, use_protocol, SEQ_number,
                                p_msg_port_id, p_msg_id, p_device_name);
}

/******************************************************************
 *   Function: vos_pty_allocate
 *
 ****************************************************************/

static int
vos_pty_allocate(vos_service_params *spp, char *device_name, int *master_fd, 
                 int *slave_fd)
{
     int j = spp->service_index;
     ssh_service *sp = 0;
     protocol_addrs addrs;
     char bits_per_char = 8;
     strioctl ioc;
     int return_status = 0;

     if (j < 0 || j >= num_ssh_services)
     {
          /* Only do debug() here as error() message can get 
           * flagged by the customer, resulting in a CAC call.
           * Having more ports than entries in sshservices is a
           * hack customers use to enable ports for end to end
           * socket data transfers (sftp and scp) but disable SSH
           * connections. So we want to know this is happening
           * when debugging but not show by default. (ssl-689) */
          debug_f("No pseudo-terminal in the sshservices file for port %d. j=%d, num_ssh_services=%d", 
                    spp->local_port, j, num_ssh_services);
          goto error_return;
     }

     addrs.local_ip = spp->local_ip;
     addrs.remote_ip = spp->remote_ip;
     addrs.remote_port = spp->remote_port;
     addrs.family = AF_INET6;

     sp = ssh_service_table + j;

     if (sp->is_login)
     {

          /* Create a pseudo terminal and open its master port */

          if (s$pt_open_pt_tioc_pipe(master_fd, slave_fd) < 0)
          {
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               goto error_return;
          }

          /* As of SSH 9.8 there is no PRIVSEP */
          if (vos_plink_login_pt(sp->servicep, *slave_fd, 
                                         *master_fd, spp->login_dev, 
                                         &addrs, 0, device_name) < 0){
               error_f("vos_plink_login_pt failed");
               goto error_return;
          }

          if (!device_name)
          {
               error_f("device_name is null");
               goto error_return;
          }

          debug3_f("device_name=%s", device_name);

          close(*slave_fd);

          if (s$pt_set_ptsname(*master_fd, device_name) < 0)
          {
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }

          if (grantpt(*master_fd) < 0)
          {
               s$pt_perror("grantpt");
               goto error_return;
          }
     
          if (unlockpt(*master_fd) < 0)
          {
               s$pt_perror("unlockpt");
               goto error_return;
          }

          /* Open the device whether it login or slave:  We need a port
             to the window term device in order to set the terminal type.
             We will close the slave terminal case after setting the
             terminal type.   */

          *slave_fd = open(device_name, O_RDWR | O_NOCTTY);
          if (*slave_fd < 0)
          {
               error_f("%.100s: %.100s", device_name, strerror(os_errno));
               goto error_return;
          }

     }
     else 
     {
          /* Must be a VOS slave devices that is already being opened
             by an application process.  */

          svc_found_device dev;

          return_status = -1;

          if (s$pt_find_device (sp->servicep, &addrs, &dev) < 0)
          {
               s$pt_perror("s$pt_find_device");
               goto error_return;
          }

          if (s$pt_open_pt_tioc_pipe(master_fd, slave_fd) < 0)
          {
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               goto error_return;
          }

          if (vos_plink_slave_pt(dev.device_name, *slave_fd, 
                                         *master_fd, 0, 0, 
                                         dev.message_port_id, 
                                         dev.message_id,
                                         device_name) < 0)
          {
               s$pt_perror("s$pt_plink_login_pt");
               goto error_return;
          }

          close(*slave_fd);

          if (s$pt_set_ptsname(*master_fd, device_name) < 0)
          {
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }

          *slave_fd = VOS_SLAVE_NON_FD;
     }


     /* We want to force the bits per char to 8 no matter how the user
        may have messed up the device.tin entries.  */

     ioc.ic_cmd = SVC_SET_BITS_PER_CHAR;
     ioc.ic_timout = -1;
     ioc.ic_len = 1;
     ioc.ic_dp = &bits_per_char;

     if (ioctl(*master_fd, I_STR, &ioc) < 0)
     {
          error_f("SVC_SET_BITS_PER_CHAR: %.100s: %.100s", device_name,
                         strerror(os_errno));
          goto error_return;
     }

     return 1;

error_return:
     {
          int save_errno = errno;
          int save_os_errno = os_errno;

          if (*master_fd >= 0)
               close(*master_fd);

          if (*slave_fd >= 0)
               close(*slave_fd);

          errno = save_errno;
          os_errno = save_os_errno;
     }

     return return_status;
}

/*------------------- ppoll_with_events ------------------------- */

/* A copy/paste job from ppoll() in ./openbsd-compat/bsd-poll.c
 * except for use of s$c_select_with_events2() instead of
 * pselect(). */
int
ppoll_with_events(struct pollfd *fds, nfds_t nfds, const struct timespec *tmoutp, const sigset_t *sigmask, int *event_id, int *count, short total_events, short *event_no)
{
	nfds_t i;
	int ret, fd, maxfd = 0;
	fd_set readfds, writefds, exceptfds;

	for (i = 0; i < nfds; i++) {
		fd = fds[i].fd;
		if (fd != -1 && fd >= FD_SETSIZE) {
			errno = EINVAL;
			return -1;
		}
		maxfd = MAX(maxfd, fd);
	}

	/* populate event bit vectors for the events we're interested in */
	FD_ZERO(&readfds);
	FD_ZERO(&writefds);
	FD_ZERO(&exceptfds);
	for (i = 0; i < nfds; i++) {
		fd = fds[i].fd;
		if (fd == -1)
			continue;
		if (fds[i].events & POLLIN)
			FD_SET(fd, &readfds);
		if (fds[i].events & POLLOUT)
			FD_SET(fd, &writefds);
		if (fds[i].events & POLLPRI)
			FD_SET(fd, &exceptfds);
	}

     /* This is basically the code from VOS pselect() with the
      * exception that the event values are passed down from
      * the caller. */
     {
          sigset_t            sigs;

          if (sigmask)
               sigprocmask(SIG_SETMASK, sigmask, &sigs);

          ret = s$c_select_with_events2(maxfd + 1,
                    &readfds, &writefds, &exceptfds, tmoutp,
                    event_id, count, total_events, event_no);

          if (sigmask)
               sigprocmask(SIG_SETMASK, &sigs, NULL);
     }

	/* scan through select results and set poll() flags */
	for (i = 0; i < nfds; i++) {
		fd = fds[i].fd;
		fds[i].revents = 0;
		if (fd == -1)
			continue;
		if ((fds[i].events & POLLIN) && FD_ISSET(fd, &readfds))
			fds[i].revents |= POLLIN;
		if ((fds[i].events & POLLOUT) && FD_ISSET(fd, &writefds))
			fds[i].revents |= POLLOUT;
		if ((fds[i].events & POLLPRI) && FD_ISSET(fd, &exceptfds))
			fds[i].revents |= POLLPRI;
	}

	return ret;
}

/*=====================================================================*/
/*==================== SECTION: session functions =====================*/
/*=====================================================================*/

unsigned short
get_vparm_privileged(void){
     return(vos_params.privileged_sw);
}

short
get_vparm_root_login(void){
     return(vos_params.permit_root_login);
}

unsigned short
get_vparm_sysadmin(void){
     return(vos_params.permit_sysadmin);
}

unsigned short
get_vparm_disable_requests(void){
     return(vos_params.disable_requests);
}

unsigned short
get_vparm_disable_x11(void){
     return(vos_params.disable_x11);
}

unsigned short
get_vparm_use_shell(void){
     return(vos_params.use_shell);
}

void
set_vparm_use_shell(void){
     vos_params.use_shell = 1;
}

/* ------------- check_tty_slave() ------------------ */

int
check_tty_slave(int ttyfd){
     return(ttyfd == VOS_SLAVE_NON_FD);
}

/* ------------- vos_read_vparm() ------------------ */

int vos_read_vparm()
{
     char *pgetenv;
     char *token;
     int vparm_ushort;
     char bufvparm[MAX_VPARM];

     /* The only possible values for default_services is 0 or 1.
      * It gets initialized to 0 so the only other valid value
      * is 1. If it is 1 then /opt/openssl/etc/sshservices was
      * not found which is expected when running the self-tests.
      * Is there's no sshservices file then there will be no
      * VPARM environment value. */
     if ((pgetenv=getenv("NO_SERV_OK")) != NULL) {
          if (sscanf(pgetenv, "%d", &default_services)){
               if (default_services==1){
                    debug_f("sshservices not available");
                    return 1;
               }
          }
     }

     /* Sanity check. We're going to first set to default
      * values and then read in values passed via environment. */
     vos_params.privileged_sw = 0;
     vos_params.disable_requests = 0;
     vos_params.disable_x11 = 0;
     vos_params.use_shell = 0;
     vos_params.permit_root_login = PERMIT_NO;
     vos_params.permit_sysadmin = 0;

     if ((pgetenv=getenv("VPARM")) == NULL) {
          error_f("VPARM not set");
          return 0;
     }

     /* Careful. These values have to be read back in the same
      * order they were written in by vos_write_pty_env(). */

     if (snprintf(bufvparm, sizeof(bufvparm), "%s", pgetenv) < 0) {
          error_f("VPARM: could not copy vparm string");
          return 0;
     }

     if (!(token=strtok(bufvparm, ","))){
          error_f("VPARM: Cannot get privileged_sw");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.privileged_sw = (unsigned short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get disable_requests");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.disable_requests = (unsigned short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get disable_x11");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.disable_x11 = (unsigned short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get use_shell");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.use_shell = (unsigned short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get permit_root_login");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.permit_root_login = (short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get permit_sysadmin");
          return 0;
     }else{
          sscanf(token, "%d", &vparm_ushort);
     }

     vos_params.permit_sysadmin = (unsigned short) vparm_ushort;

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get service_index");
          return 0;
     }else{
          sscanf(token, "%d", &vos_params.service_index);
     }

     if (!(token=strtok(NULL, ","))){
          error_f("VPARM: Cannot get service_name");
          return 0;
     }else{
          sscanf(token, "%s", vos_params.service_name);
     }

     debug2_f("privileged_sw=%d, disable_requests=%d, disable_x11=%d, use_shell=%d, permit_root_login=%d, permit_sysadmin=%d, service_index=%d, service_name=%s",
          vos_params.privileged_sw,
          vos_params.disable_requests,
          vos_params.disable_x11,
          vos_params.use_shell,
          vos_params.permit_root_login,
          vos_params.permit_sysadmin,
          vos_params.service_index,
          vos_params.service_name);

     return 1;
}

/* ------------- vos_read_pty() ------------------ */

int
vos_read_pty(Session *s)
{
     char dev_name[MAX_PTY_NAME];
     char *pgetenv;
     char *token;
     char bufpty[MAX_PTY_BUF];

     if ((pgetenv=getenv("NO_SERV_OK")) != NULL) {
          if (sscanf(pgetenv, "%d", &default_services)){
               if (default_services==1){
                    debug_f("sshservices not available");
                    return 1;
               }
          }
     }

     if((pgetenv=getenv("PTY")) == NULL){
          error_f("PTY not set");
          return 0;
     }

     if (snprintf(bufpty, sizeof(bufpty), "%s", pgetenv) < 0) {
          error_f("could not copy bufpty string");
          return 0;
     }

     if (!(token=strtok(bufpty, ","))){
          error_f("could not get dev_name");
          return 0;
     }else{
          sscanf(token, "%s", dev_name);
     }

     if (!(token=strtok(NULL, ","))){
          error_f("could not get master_fd_ext");
          return 0;
     }else{
          sscanf(token, "%d", &master_fd_ext);
     }

     if (!(token=strtok(NULL, ","))){
          error_f("could not get slave_fd_ext");
          return 0;
     }else{
          sscanf(token, "%d", &slave_fd_ext);
     }

     /* Put everything in session structure if requested. */
     if(s != NULL){
          strlcpy(s->tty, dev_name, sizeof(s->tty));
          s->ptyfd = master_fd_ext;
          s->ttyfd = slave_fd_ext;

          debug3_f("device_name=%s, ptyfd=%d, ttyfd=%d", s->tty, s->ptyfd, s->ttyfd);
     }else{
          debug3_f("device_name=%s, ptyfd=%d, ttyfd=%d", dev_name, master_fd_ext, slave_fd_ext);
     }

     return 1;
}

/* ------------- vos_session_setup() ------------------ 
 *
 * info: Called from sshd-session.pm to read back
 *       settings about current SSH service and pseudo
 *       terminal.
 * input: none
 * output: 1 (success), 0 (failure)
 */

int vos_session_setup(void){

     if (!vos_read_vparm()){
          return 0;
     }

     if (!vos_read_pty(NULL)){
          return 0;
     }

     if (!vos_ssh_init_mux()){
          return 0;
     }

     return 1;
}

/*-------------- vos_set_term() --------------------*/

/* Action: Fill out vos_service_params struct from ENV
 * Output:   1 (success), 0 (failure)
 */

void vos_set_term(Session *s)
{
     /* FYI: 
      *        s->tty   = device_name
      *        s->ptyfd = master_fd
      *        s->ttyfd = slave_fd
      */

     if (s->term)
     {
          short opcode = TERM_SET_TERMINAL_TYPE;
          char_varying(32) ttp_name;
          short code;

          debug3_f("tty=%s, term=%s, ttyfd=%d, uid=%u", s->tty, s->term, s->ttyfd, (unsigned int) getuid());

          if (s->ttyfd == VOS_SLAVE_NON_FD)
          {
               /* If we try to open the slave port and the application that
                  opened the slave terminal has aborted, we will hang trying
                  to open a connection to ourselves.  Try using 
                  s$update_channel_info to set the slave terminal type.  */

               cvPATH_MAX path_in;
               cvPATH_MAX path_out;
               char_varying(1) suffix;

               strncpy_vstr_nstr(&suffix, "", 1);
               strncpy_vstr_nstr(&path_in, s->tty, MAX_PATH);

               s$expand_path (&path_in, &suffix, &path_out, &code);
               if (code){
                         error_f("s$expand_path: failed: %.100s", strerror(code));
               }else{
                    CHANNEL_INFO_STRUCTURE info;

                    info.version = CHAN_INFO_VERSION_9;

                    s$get_channel_info (&path_out, &info, &code);
                    if (code){
                              debug3_f("s$get_channel_info: failed: %.100s", strerror(code)); /* non-fatal */
                    }else{
                         strncpy_vstr_nstr(&info.terminal_type_name, s->term, 32);
                         s$update_channel_info (&path_out, &info, &code);

                         /* It is possible for clone devices to go away
                            before we get to them.  Those errors will
                            be reported elsewhere.  */
                         if (code){
                              debug3_f("s$update_channel_info: can't set ttp for %s to %s: %.100s", s->tty, s->term, strerror(code)); /* non-fatal */
                         }
                    } /* s$get_channel_info */
               } /* s$expand_path*/
          }
          else
          {
               short portid = s$c_get_portid_from_fildes(s->ttyfd);

               strncpy_vstr_nstr(&ttp_name, s->term, 32);

               s$control(&portid, &opcode, &ttp_name, &code);

               if (code){
                    debug3_f("s$control: can't set ttp for %s to %s: %.100s: uid=%u", s->tty, s->term, strerror(code), (unsigned int) getuid()); /* non-fatal */
               }

          }
     }
}

/*-------------- add_path() --------------------*/

static void 
add_path(cvPATH_MAX *lib_pathsp, short *num_pathsp, const cv66 *master_disk, 
               const char *subdir )
{
     cvPATH_MAX path;
     cvPATH_MAX path_out;
     short type;
     cv66 module_name;
     short code;
     int j;

     /* Build a complete pathname. */
     strcpy_vstr_vstr(&path, master_disk);
     strcat_vstr_nstr(&path, subdir);

     /* Make sure it exists and is a directory.  */
     s$where_path (&path, &path_out, &type, &module_name, &code);
     if (code || type != 2)
          return;

     /* If it's already in the search paths, we don't need to add it. */
     for(j = 0; j < *num_pathsp; j++)
     {
          if (strcmp_vstr_vstr(&path, lib_pathsp+j) == 0)
               return;

          if (strcmp_vstr_vstr(&path_out, lib_pathsp+j) == 0)
               return;
     }

     /* We want to insert these directories before the other search
        directories but after the "(current_dir)" rule.  Note that
        even if the "(current_dir)" rule is the last entry in the
        list, this logic is safe; there is always room in the array to
        add the pathname.  */

     for (j = *num_pathsp; j > 0; --j)
          if (!strncmp_vstr_nstr(lib_pathsp+j-1, "(current_dir)", MAX_PATH))
               break;
          else strncpy_vstr_vstr(lib_pathsp+j, lib_pathsp+j-1, MAX_PATH);

     strncpy_vstr_vstr(lib_pathsp+j, &path_out, MAX_PATH);
     *num_pathsp += 1;
}

/*-------------- adjust_vos_library_path() --------------------*/

void adjust_vos_library_path(int use_shell)
{
     short num_paths = 0;
     cv32 lp_name;
     cvPATH_MAX path;
     short code;

     /* Set all library paths back to the default (side effect of num=0).  */
     strncpy_vstr_nstr(&lp_name, "include", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "object", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "message", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     strncpy_vstr_nstr(&lp_name, "command", 32);
     s$set_library_paths(&lp_name, &num_paths, &path, &code);

     if (use_shell)
     {
          cvPATH_MAX *lib_paths;
          short max_paths = 0;
          short eval = 0;
          cv66 master_disk;
          cv66 module_name;

          /* Get the master disk name. */
          strncpy_vstr_nstr(&module_name, "", 0);
          s$get_master_disk(&module_name, &master_disk, &code);
          if (code)
               return;

          /* Find out how many command library paths there are. */
          strncpy_vstr_nstr(&lp_name, "command", 32);
          s$get_library_paths(&lp_name, &eval, &max_paths, &num_paths, &path,
                              &code);
          if (code)
               return;

          /* Allocate space for the existing paths plus 2.  */
          lib_paths = xmalloc(sizeof(cvPATH_MAX) * (num_paths+2));


          /* Get the library paths. */
          max_paths = num_paths;
          s$get_library_paths(&lp_name, &eval, &max_paths, &num_paths, 
                              lib_paths, &code);
          if (code)
               return;

          /* Make sure that (master_disk)>opt>openssl>bin
             [or (master_disk)>system>openssl>bin for 1.1] and
             (master_disk)>system>gnu_library>bin are in the library
             paths.  */

          add_path(lib_paths, &num_paths, &master_disk, ">opt>openssl>bin");
          add_path(lib_paths, &num_paths, &master_disk, ">system>gnu_library>bin");

          if (num_paths == max_paths)   /* Did we add any. */
               return;

          s$set_library_paths(&lp_name, &num_paths, lib_paths, &code);
     }
}

/*-------------- chroot_init() --------------------*/

/* At some point VOS will support chroot() and when it
 * does SSH will be ready. Determine this at runtime by
 * calling dlsym() and friends. This is only meant 
 * to get called by the SSH daemon. */

static int (*chroot_func)(const char *path);

void chroot_init(){

     void *handle;
     char *error;

     chroot_func=NULL;

     if((handle=dlopen("libvosposix.1.so", RTLD_LAZY))==NULL)
          return;

     dlerror();

     *(void **) (&chroot_func)=dlsym(handle, "chroot");

     if ((error = dlerror()) != NULL)
          debug2("chroot_init: %s", error);

     dlclose(handle);
}

/*-------------- chroot_wrap() --------------------*/

int chroot_wrap(const char *path){

     if (chroot_func != NULL)
          return ((*chroot_func)(path));
     else
          return (0);
}

/*-------------- vos_exec_native() --------------------*/

void vos_exec_native (char *const envp [])
{

     char                                         *name;
     int                                          j;
     ed_type                                      *edp;
     extern char                                  **environ;
     
     /* Sets the per-process env variables to values specified by ENVP */
     if(envp != NULL)
     {

       /* Force a copy of env variables from user to process space
          by changing environ address before calling putenv .*/
                        
          s$get_c_env_data_ptr(&edp);
          environ = (char **)((int)edp + sizeof(ed_type));

          unsetenv("PTY");
          unsetenv("VPARM");

       /* VOS must use putenv if we are going to use s$stop_program to
          start a VOS login session. */          

          for (j = 0; envp[j]; j++)
          {
               name = envp[j];

               putenv(name);
          }

          /* We don't return from either s$stop_program_do_cli
           * or s$stop_program.
           */
          if(check_cli_support()){
               short code = 0;
               cv32 entry_name;
               short flags = 0;
               short module_id = 0;
               void *lka[2];
               void *ev_ptrs[3];
               void (*func)();

               strlcpy_vstr_nstr(&entry_name, "s$stop_program_do_cli", 32);
               s$lookup_kernel_address (&module_id, &entry_name, &flags, lka, &code);
               if (code) {
                    /* At this point we fail and let SSH error out for us. */
                    debug3_f("s$lookup_kernel_address failed. code: %d", code);
                    return;
               }

               ev_ptrs[0] = OS_NULL_PTR;
               ev_ptrs[1] = lka[0];
               ev_ptrs[2] = lka[1];

               debug3_f("calling s$stop_program_do_cli: %#lx", (long) getpid());

               func = (void *) ev_ptrs;

               (*func) ();
          }else{

               char_varying (MAX_EXEC_PROGRAM_LEN)          cmd_line;
               short                                        zero = 0;

               strcpy_vstr_nstr(&cmd_line,"");

               s$stop_program(&cmd_line, &zero);
          }
     }
}

/*-------------- vos_ssh_init_mux() --------------------*/

/* Action:   Kick off multiplexing support by calling
 *           s$pt_initialize and s$pt_init_services.
 * Output:   1 (success), 0 (failure)
 */

static int vos_ssh_init_mux()
{
     char *pgetenv;

     if ((pgetenv=getenv("NO_SERV_OK")) != NULL) {
          if (sscanf(pgetenv, "%d", &default_services)){
               if (default_services==1){
                    debug_f("sshservices not available");
                    return 1;
               }
          }
     }

     if (s$pt_initialize(&ssh_callbacks_mux, 0, NULL, NULL) < 0)
     {
          error_f("failed s$pt_initialize");
          s$pt_perror("s$pt_initialize");
          return 0;
     }

     if (s$pt_init_services(">opt>openssl>etc>sshservices") < 0)
     {
          /* If we fail here we're done. There's no fallback
           * to default services. */
          error_f("failed s$pt_init_services");
          s$pt_perror("s$pt_init_services");
          return 0;
     }

     return 1;
}

/*-------------- vos_pty_allocate_mux() --------------------*/

/* Action:   Tie master/slave ports to the login device.
 *           The assumption is vos_params has already been set
 *           by vos_read_vparm().
 * Output:   0 (success), -1 (failure) 
 */

int
vos_pty_allocate_mux(struct svc_device *login_dev, char *device_name, int *master_fd, int *slave_fd)
{
     ssh_service *sp     = 0;
     protocol_addrs addrs;
     char bits_per_char  = 8;
     strioctl ioc;
     int i, found        = 0;

     for (i=0; i<VOS_MAX_SERVICE_ENTRIES; i++){
          sp = &ssh_this_service_mux[i];
          if (strncmp(vos_params.service_name, sp->service_name, sizeof(vos_params.service_name)) == 0){
               debug_f("service=%s: index=%d: found", vos_params.service_name, vos_params.service_index);
               found++;
               break;
          }
     }

     if(!found){
          error_f("service %s: index %d: not found", vos_params.service_name, vos_params.service_index);
          return -1;
     }

     if (sp->is_login)
     {

          /* Create a pseudo terminal and open its master port */
          if (s$pt_open_pt_tioc_pipe(master_fd, slave_fd) < 0)
          {
               error_f("s$pt_open_pt_tioc_pipe: failed");
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               return -1;
          }

          if (s$pt_plink_login_pt(sp->servicep, *slave_fd, login_dev, &addrs, 0, device_name) < 0){
               error_f("s$pt_plink_login_pt: failed");
               s$pt_perror("s$pt_plink_login_pt");
               goto error_return;
          }

          if (!device_name)
          {
               error_f("device_name is null");
               goto error_return;
          }

          debug3_f("device_name=%s", device_name);

          close(*slave_fd);

          if (s$pt_set_ptsname(*master_fd, device_name) < 0)
          {
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }

          if (grantpt(*master_fd) < 0)
          {
               error_f("grantpt: %s)", strerror(errno));
               goto error_return;
          }

          if (unlockpt(*master_fd) < 0)
          {
               error_f("unlockpt: %s)", strerror(errno));
               goto error_return;
          }

          /* Open the device whether it login or slave:  We need a port
             to the window term device in order to set the terminal type.
             We will close the slave terminal case after setting the
             terminal type.   */

          *slave_fd = open(device_name, O_RDWR | O_NOCTTY);
          if (*slave_fd < 0)
          {
               error_f("open: %s)", strerror(errno));
               goto error_return;
          }

     }else{

          /* Must be a VOS slave devices that is already being opened
             by an application process.  */

          svc_found_device dev;

          if (s$pt_find_device (sp->servicep, &addrs, &dev) < 0)
          {
               error_f("s$pt_find_device: failed");
               s$pt_perror("s$pt_find_device");
               goto error_return;
          }

          if (s$pt_open_pt_tioc_pipe(master_fd, slave_fd) < 0)
          {
               error_f("s$pt_open_pt_tioc_pipe: failed");
               s$pt_perror("s$pt_open_pt_tioc_pipe");
               goto error_return;
          }

          if (s$pt_plink_slave_pt(dev.device_name, *slave_fd, 
                                         0, 0, 
                                         dev.message_port_id, 
                                         dev.message_id,
                                         device_name) < 0)
          {
               error_f("s$pt_plink_slave_pt: failed");
               s$pt_perror("s$pt_plink_slave_pt");
               goto error_return;
          }

          close(*slave_fd);

          if (s$pt_set_ptsname(*master_fd, device_name) < 0)
          {
               error_f("s$pt_set_ptsname: failed");
               s$pt_perror("s$pt_set_ptsname");
               goto error_return;
          }

          *slave_fd = VOS_SLAVE_NON_FD;
     }

     /* We want to force the bits per char to 8 no matter how the user
        may have messed up the device.tin entries.  */

     ioc.ic_cmd = SVC_SET_BITS_PER_CHAR;
     ioc.ic_timout = -1;
     ioc.ic_len = 1;
     ioc.ic_dp = &bits_per_char;

     if (ioctl(*master_fd, I_STR, &ioc) < 0)
     {
          error_f("SVC_SET_BITS_PER_CHAR: %.100s: %.100s", device_name, strerror(os_errno));
          goto error_return;
     }

     return 0;

error_return:

     if (*master_fd >= 0)
          close(*master_fd);

     if (*slave_fd >= 0)
          close(*slave_fd);

     return -1;
}

/*--------- vos_ssh_is_service_supported_mux() -----------*/

/* Action:   A callback. Just a stub that get called back by WTM
 *           but doesn't do anything useful.
 * Output:   1 (success)
 */

static int  
vos_ssh_is_service_supported_mux(const char* p_service_name)
{
#ifdef DEBUG
     error_f("service name=%s, uid=%d", p_service_name, getuid());
#endif
     return 1;
}

/*--------- vos_ssh_new_service_mux() -----------*/

/* Action:   A callback. Gets called for each entry in the sshservices file and
 *           for the entry which matches the current connection
 *           sets vparm values. When ssh-session starts the first
 *           thing we do is call vos_read_pty_env() which sets
 *           vos_params so it should be defined before we're called
 *           here.
 * Output:   0 (success), -1 (failure)
 */

static int  
vos_ssh_new_service_mux(
     const char                *p_service_namep,
     int                        p_login, 
     const char                *p_proto_optionsp,
     const char                *p_descriptionp,
     struct svc_node           *p_tsp,
     struct protocol_service  **p_servicepp)
{

     /* Fill in from function arguments or pass on defaults
      * what we really want is to setup 'servicep' so it 
      * can get dereferenced later by s$pt_find_login_device().
      * All the other 'service'
      * values get ignored or overwritten later. */

     ssh_service *sp     = ssh_this_service_mux + ssh_this_service_index;

     /* Increment to mark the fact that we called this function
      * because this means WTM is processing sshservices line by line */

     ssh_this_service_index++;

     /* If we made it this far we should be pointing to the correct
      * service entry that matches this TCP connection */

     sp->servicep = p_tsp;
     strlcpy (sp->service_name, p_service_namep, 36);
     sp->service_name[35]          = '\0';
     sp->is_login                  = p_login;
     sp->slave_available           = 0; /* gets set by callback */
     sp->permit_root_login         = PERMIT_NO; /* not allowed in mux */

     /* Set vos_params values for entry that's being mux'ed otherwise for
      * other entries set defaults. */
     if (strncmp(vos_params.service_name, sp->service_name, sizeof(vos_params.service_name)) == 0){
          sp->disable_requests          = vos_params.disable_requests;
          sp->disable_x11               = vos_params.disable_x11;
          sp->use_shell                 = vos_params.use_shell;
          sp->permit_sysadmin           = vos_params.permit_sysadmin;
     }else{
          sp->disable_requests          = 0;
          sp->disable_x11               = 0;
          sp->use_shell                 = 0;
          sp->permit_sysadmin           = 1;
     }

     *p_servicepp                  = sp;

     return 0;
}

/*--------- vos_find_login_dev_mux() -----------*/

/* Action:   Get login device based on the socket we're using for
 *           the connection as well as the current service entry
 *           we picked out in vos_ssh_new_service_mux().
 * Output:   0 (success), -1 (failure)
 */

int
vos_find_login_dev_mux(struct svc_device **login_dev, int p_socket)
{
     int            priv_sw        = 0;
     ssh_service    *sp;
     int            i,found        = 0;
     protocol_addrs addrs;
     sockaddr_union remote_addr, local_addr;
     int            remote_addrlen = sizeof(struct sockaddr_in6);
     int            local_addrlen  = sizeof(struct sockaddr_in6);

     for (i=0; i<VOS_MAX_SERVICE_ENTRIES; i++){
          sp = &ssh_this_service_mux[i];
          if (strncmp(vos_params.service_name, sp->service_name, sizeof(vos_params.service_name)) == 0){
               debug_f("service=%s: index=%d: found", vos_params.service_name, vos_params.service_index);
               found++;
               break;
          }
     }

     if(!found){
          error_f("service %s: index %d: not found", vos_params.service_name, vos_params.service_index);
          return -1;
     }

     /* When we initialized the WTM database, we parsed thru sshservices and
      * set up a pointer to the data for this login entry. So this is 
      * a sanity check. */
     if ((!sp->is_login) && (!sp->slave_available)){
          error_f("No devices ready for %.35s service.", sp->service_name);
          return -1;
     }

     if (getpeername(p_socket, (struct sockaddr *) &remote_addr, &remote_addrlen) < 0)
     {
          error_f("getpeername failed. Got: %s", strerror(errno));
          return -1;
     }

     if (getsockname(p_socket, (struct sockaddr *) &local_addr, &local_addrlen) < 0)
     {
          error_f("getsockname failed. Got: %s", strerror(errno));
          return -1;
     }

     if (remote_addr.v4.sin_family == AF_INET)
     {
          _IN6_V4_INTO_V4MAPPED(&addrs.remote_ip, remote_addr.v4.sin_addr.s_addr);
          _IN6_V4_INTO_V4MAPPED(&addrs.local_ip, local_addr.v4.sin_addr.s_addr);
          addrs.remote_port   = remote_addr.v4.sin_port;
     }else
     {
          addrs.remote_ip     = remote_addr.v6.sin6_addr;
          addrs.local_ip      = local_addr.v6.sin6_addr;
          addrs.remote_port   = remote_addr.v6.sin6_port;
     }

     addrs.family        = remote_addr.v4.sin_family;

     *login_dev = s$pt_find_login_device (sp->servicep, &addrs, &priv_sw);
     if (!*login_dev)
     {
          error_f("failed s$pt_find_login_device");
          s$pt_perror("s$pt_find_login_device");
          return -1;
     }

     return 0;
}

/*--------- vos_ssh_service_available_mux() -----------*/

/*             A callback. This is called by the s$pt library 
 *             when at least one 
 *             slave terminal is available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as being available:  We need to 
 *             know whether to accept incoming slave connections.
 */

static int 
vos_ssh_service_available_mux(
     struct protocol_service *p_servicep)
{
#ifdef DEBUG
     error_f("service name=%s, slave_available=%d, uid=%d", p_servicep->service_name, p_servicep->slave_available, getuid());
#endif
     p_servicep->slave_available = 1;
     return 0;
}

/*----------- vos_ssh_service_unavailable_mux() ------------------*/

/*             A callback. This is called by the s$pt library when
 *             no slave terminals are available for the service.
 *   Input:    The service node visible to this code.
 *   Action:   Mark the service as not being available:  We need to 
 *             know whether to accept incoming slave connections.
 *
 ****************************************************************/

static void 
vos_ssh_service_unavailable_mux(
     struct protocol_service *p_servicep)
{
#ifdef DEBUG
     error_f("service name=%s, slave_available=%d, uid=%d", p_servicep->service_name, p_servicep->slave_available, getuid());
#endif
     p_servicep->slave_available = 0;
}

/*--------- vos_ssh_service_modified_mux() -----------*/

/*             A callback. This routine is called whenever the
 *             service database is modified by an external
 *             admin command.
 *   Input:    The service node visible to this code.
 *             Whether it is available.
 *             The protocol options string.
 *             The description.
 *   Output:   Returns -1 for failure, 0 for success.
 *   Action:   Report an error if protocol options were given.
 *             Don't need to do anything else, because all other
 *             attributes are either unused or supported dynamically.
 */

static int  
vos_ssh_service_modified_mux(
     struct protocol_service *p_servicep, 
     int p_available,
     const char * p_proto_optionsp,
     const char * p_descriptionp)
{
     p_servicep->slave_available = p_available;

#ifdef DEBUG
     error_f("service name=%s, slave_available=%d, uid=%d", p_servicep->service_name, p_servicep->slave_available, getuid());
#endif

     if (*p_proto_optionsp)
     {
#ifdef DEBUG
          error_f("service name=%s: failed with e$invalid_arg_format", p_servicep->service_name);
#endif
          return set_errno(e$invalid_arg_format);
     }

     return 0;
}

/*--------------- vos_mux_check_pty() ------------------*/

int vos_mux_check_pty(Session *s, int p_socket){

     /* Determine if we're multiplexing by checking channel ID
      * or gbl_vos_mux_use_flag. gbl_vos_mux_use_flag is incremented in
      * session_open which is called before this function so value
      * needs to be >1 in which case session_open was called twice
      * - the 2nd time for a muxed client.
      * If true call vos_ssh_init_mux(), vos_pty_allocate_mux(),
      * and vos_write_pty_env() to setup master/slave ports for
      * new login device. Multiplexed clients won't go knocking on
      * port 22 instead they will get let in thru an existing TCP/IP port.
      */

      debug3_f("pid=%ld, uid=%ld, channel=%d, gbl_vos_mux_use_flag=%d, root_login=%d", (long)getpid(), (long)getuid(), s->chanid, gbl_vos_mux_use_flag, vos_params.permit_root_login);

      if ((s->chanid > 0) || (gbl_vos_mux_use_flag > 1)){
           int master_fd = -1;
           int slave_fd = -1;
           char device_name_mux[MAX_PTY_NAME];

           /* Pass down the socket tied to our TCP connection so it can
            * get cross-referenced in the wtm database to get a pointer
            * to our login device. */
           if (vos_find_login_dev_mux(&vos_params.login_dev, p_socket) < 0){
                return 0;
           }

           /* Now that we know login device we setup master/slave connections.
            * Need ssh_service_table to be defined so we can reference
            * sp->servicep */
           if (vos_pty_allocate_mux(vos_params.login_dev, device_name_mux, &master_fd, &slave_fd) < 0){
                return 0;
           }

           /* Setup to have vos_read_pty_env configure new session pointer
            * wth values (device_name_mux, master_fd, slave_fd) for a new
            * login.
            */
           if (!vos_write_pty_env(device_name_mux, master_fd, slave_fd, &vos_params)){
                return 0;
           }

           /* Force the next call to vos_read_pty_env() to read from PTY
            * and set the ssh struct. */
           master_fd_ext = -1;
           slave_fd_ext  = -1;

           debug3_f("pid=%ld, uid=%ld, channel=%d, device_name=%s, master_fd=%d, slave_fd=%d", (long)getpid(), (long)getuid(), s->chanid, device_name_mux, master_fd, slave_fd);
     }

     /* vos_read_pty_env() will set [s->tty, s->ptyfd, s->ttyfd] from
      * PTY environment value set by sshd program. Will not read
      * vos_parms.
      */
     if (!vos_read_pty(s)) {
          return 0;
     }

     /* If s->term valid then terminal type via:
      * s$update_channel_info() or
      * s$control(TERM_SET_TERMINAL_TYPE)
      * No return status from vos_set_term() at this time. */
     vos_set_term(s);

     return 1;
}

/*--------------- vos_mux_check_open() ------------------*/

int vos_mux_check_open(int self_id){

	if ((self_id > 0) || (gbl_vos_mux_use_flag >= 1)){

		/* Do not allow another entry vector for root.
		 * To be extra paranoid let's check current uid is
		 * not root (0) but we can only do this on VOS releases
		 * that support privilege downgrade because older
		 * VOS releases will run sshd-session as root. FYI
		 * vos_read_pty_env() will set cli_support (a global).
		 */
		if ((vos_params.permit_root_login != PERMIT_NO) && 
              (check_cli_support() > 0) && 
              (getuid() == 0)){
			return 0;
		}
	}

	/* The next call to this routine will be from a mux client since
	 * the login device setup from sshd before the exec() can only
	 * be used once. Setup to call the mux routines the next time
	 * thru by incrementing gbl_vos_mux_use_flag because session_pty_req()
	 * checks it.
	 * Can't just check session or channel ID because we need to allow
	 * scenario where linux client w/ mux config disconnects
	 * and re-connects without opening up another mux client. The
	 * session ID will be 0 but we'll still need to provide a login
	 * device. The default max clients determined by DEFAULT_SESSIONS_MAX 
	 * is currentlly 10 so we're ok to increment gbl_vos_mux_use_flag without
	 * rolling over the max int value.
	 */

	gbl_vos_mux_use_flag++;

     return 1;
}

/*--------------- get_device_name() ------------------*/

static char *
get_device_name(int local, int check_on_sock, int fd_in, int fd_out)
{
/* automatic */

short int access_mode;
short int code;
int fd;
short int io_type;
short int log_port_id;
short int organization;
short int portid;
char_varying(256) path_name;
char_varying(32) port_name;

/* static */

static char buffer[258];

/* execution */

	strcpy (buffer, "none");

	/*
	 * If the connection is not a socket, return "none".
	 */
	if (!check_on_sock)
		return buffer;

	/* Get socket and return the device name. */
	if (local)
	     fd = fd_in;
	else fd = fd_out;

	portid = s$c_map_fd_to_portid (fd);

	s$get_port_attachment (&portid, &path_name, &port_name,
		&log_port_id, &organization, &io_type, &access_mode,
		&code);
	if (code)
		return buffer;

	strlcpy_nstr_vstr (buffer, &path_name, sizeof (buffer));

	return buffer;
}

/*--------------- get_remote_device_name() ------------------*/

char *
get_remote_device_name(int check_on_sock, int fd_in, int fd_out)
{
	return get_device_name(0, check_on_sock, fd_in, fd_out);
}

/*--------------- get_local_device_name() ------------------*/

char *
get_local_device_name(int check_on_sock, int fd_in, int fd_out)
{
	return get_device_name(1, check_on_sock, fd_in, fd_out);
}

/*--------------- check_for_vos_path() ------------------*/

/* Look for any VOS delimeters and translate them to posix. 
 Follow these rules: 
 1. Substitute any occurances of '>' with '/'
 2. Substitute '<', '#', and '%' with '../','/#','/%' repectively 
    if they are the first char in the string.
 3. Substitute '<' with '/../' if the char before is not a '/'
    otherwise substitue with '../'. VOS allows embedded less-than 
    characters in pathnames. */

char *check_for_vos_path (char *vpath)
{
	int i,j;
	char tmp_path[PATH_MAX]="";
	char *npath;

	npath = NULL;

	for (i = j = 0; i<(int)strlen(vpath); i++){
		if (vpath[i] == '>')
			tmp_path[j] = '/';
		else if ( (i==0) && (vpath[i] == '#')){
			tmp_path[j] = '/';
			j++;
			tmp_path[j] = '#';
		} else if ( (i==0) && (vpath[i] == '%')){
			tmp_path[j] = '/';
			j++;
			tmp_path[j] = '%';
		} else if (vpath[i] == '<'){
			if ( (j>0) && (tmp_path[j-1] != '/')){
				tmp_path[j] = '/';
				j++;
				if (j > (PATH_MAX-1))
					return NULL;
				tmp_path[j] = '.';
				j++;
				if (j > (PATH_MAX-1))
					return NULL;
				tmp_path[j] = '.';
				j++;
				if (j > (PATH_MAX-1))
					return NULL;
				tmp_path[j] = '/';
			} else {
				tmp_path[j] = '.';
				j++;
				if (j > (PATH_MAX-1))
					return NULL;
				tmp_path[j] = '.';
				j++;
				if (j > (PATH_MAX-1))
					return NULL;
				tmp_path[j] = '/';
			}
		} else
			/* Let char thru */
			tmp_path[j] = vpath[i];
		j++;
		if (j > (PATH_MAX-1))
			return NULL;
	}

	tmp_path[j] = '\0';

	/* Erase since we'll be creating a new path */
	free (vpath);
	vpath = NULL;

	if ( (npath = malloc (strlen (tmp_path) + 1)) != NULL)
		strncpy (npath, tmp_path, strlen (tmp_path) + 1);

	return (npath);
}

/*--------------- fixup_stat() ------------------*/

/* Ensure several VOS proprietary file types are
   rejected. */
void
fixup_stat(struct stat *st)
{
     static int sshd$allow_vos_types = 0; /* 0: no, 1: ok */

	/* VOS correctly identifies a pipe_file as fifo, so we
	   do not need to test for the pipe attribute. But it
	   mis-identifies queues as regular files, so fix that
	   up here. (ssl-300)

	   The POSIX runtime is unable to seek to an arbitrary
	   position in a FIXED_FILE and this means that we are
	   unable to work with some sftp clients. Even clients
	   that work may fail on unusual record sizes. (ssl-264) 

	   Only stream and sequential files are ok, everything 
	   else by default is not. (ssl-423). */

	if (S_ISREG (st->st_mode))
	{
		switch (st->st_vos_file_org) {
		case STREAM_FILE:
		case SEQUENTIAL_FILE:
			break;
		default:
			if (!sshd$allow_vos_types) {
				st->st_mode = _IFBLK | (st->st_mode & ~_IFMT);
			}
		}
	}
}

/*--------------- vos_setgroups() ------------------*/

int
vos_setgroups(size_t size, const gid_t *list)
{
	return (0);
}

/*--------------- vos_getpwnam() ------------------*/

struct passwd *vos_getpwnam(const char *user)
{
	/* Allow the SSH user name to include a VOS group name.
	   This function and vos_terminated_user() are the only 
	   place in SSHD that map an SSH user name to a POSIX struct
	   passwd, so we can hide this functionality here */

	char *group;
	int i, j;
	gid_t temp_gid;
	char *temp_group;
	char vos_username[66];
     struct passwd *pw;

	strlcpy (vos_username, user, sizeof (vos_username));

	group = strchr (vos_username, '.');
	if (group != NULL)
	{
		/* Split the "Person.Group" name into its two
		   components */

		*group = '\0';
		group = group+1;
	}

	pw = getpwnam(vos_username);

	/* Implement the permit_sysadmin flag. */
     if (pw != NULL && !get_vparm_sysadmin())
	{
		for (i = 0; i <= pw->pw_n_other_groups; i++) {
			if (i > 0 && pw->pw_other_gids [i-1] < 0)
				continue;

			if (strcmp (pw->pw_groups [i], "SysAdmin"))
				continue;

			/* Remove "SysAdmin" from group list. */
			for (j = i; j < pw->pw_n_other_groups; j++) {
				if (j <= 0) {
					pw->pw_gid = pw->pw_other_gids[0];
				} else {
					pw->pw_other_gids[j-1] =
						pw->pw_other_gids[j];
				}
				pw->pw_groups [j] = pw->pw_groups [j+1];
			}

			/* The array just got one smaller. */
			pw->pw_n_other_groups--;

			/* Just in case, examine the one we just moved. */
			i--;
		}

		/* If there are no groups other than SysAdmin, invalidate. */
		if (pw->pw_n_other_groups < 0)
			pw = NULL;
	}

	if (pw != NULL && group != NULL)
	{
		if (!strcmp (group, pw->pw_groups [0]))
		{
			debug("getpwnamallow: using default group %s, gid %ld",
				group, pw->pw_gid);
			goto group_ok;
		}

		for (i=0; i<pw->pw_n_other_groups; i++)
		{
			/* pw_groups[i+1] aligns with p_other_gids[i] */

			if (pw->pw_other_gids [i] < 0)
			{
				/* ignore group names not accompanied by a valid
				   gid (they are probably compound group names,
				   e.g., "grp2,grp3,grp4").  */

				debug("getpwnamallow: ignoring group %s, gid %ld",
					pw->pw_groups [i+1], pw->pw_other_gids [i]);
			}
			else if (!strcmp (group, pw->pw_groups [i+1]))
			{
				/* Make the requested group the first
				   group */

				temp_gid = pw->pw_gid;
				pw->pw_gid = pw->pw_other_gids [i];
				pw->pw_other_gids [i] = temp_gid;

				temp_group = pw->pw_groups [0];
				pw->pw_groups [0] = pw->pw_groups [i+1];
				pw->pw_groups [i+1] = temp_group;

				debug("getpwnamallow: using other group %s, gid %ld",
					group, pw->pw_gid);
				goto group_ok;
			}
		}
		logit("%s is not a registered group name for %s", 
			group, vos_username);
		pw = NULL;
group_ok:;
	}

     return(pw);
}
