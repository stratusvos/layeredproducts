#	$OpenBSD: reexec.sh,v 1.13 2023/01/19 07:53:45 dtucker Exp $
#	Placed in the Public Domain.

tid="reexec tests"

SSHD_ORIG=$SSHD
SSHD_COPY=$OBJ/sshd${EXEEXT}

# Start a sshd and then delete it
start_sshd_copy ()
{
	# NB. prefer ln to cp here. On some OSX 19.4 configurations,
	# djm has seen failure after fork() when the executable image
	# has been removed from the filesystem.
	# VOS: Do not support hard links so avoid error message in output.
	if [ "$OSTYPE" == "vos" ]
	then
		cp $SSHD_ORIG $SSHD_COPY
	else
		ln $SSHD_ORIG $SSHD_COPY || cp $SSHD_ORIG $SSHD_COPY
	fi
	SSHD=$SSHD_COPY
	start_sshd
	SSHD=$SSHD_ORIG
}

# Do basic copy tests
copy_tests ()
{
	rm -f ${COPY}
	${SSH} -nq -F $OBJ/ssh_config somehost \
	    cat ${DATA} > ${COPY}
	if [ $? -ne 0 ]; then
		fail "ssh cat $DATA failed"
	fi
	cmp ${DATA} ${COPY}		|| fail "corrupted copy"
	rm -f ${COPY}
}

verbose "test config passing"

cp $OBJ/sshd_config $OBJ/sshd_config.orig
start_sshd
echo "InvalidXXX=no" >> $OBJ/sshd_config

copy_tests

stop_sshd

cp $OBJ/sshd_config.orig $OBJ/sshd_config

# cygwin can't fork a deleted binary
if [ "$os" != "cygwin" ]; then

verbose "test reexec fallback"

start_sshd_copy

# VOS: Our version of execv() won't work if it can't see the file.
#      This means if we delete the active copy of sshd.pm then test
#      will fail because process won't be able to execv() into
#      another process when the ssh client comes calling. FYI, on
#      Linux the exec()'s can search for binaries in directories
#      listed by $PATH.
if [ "$OSTYPE" != "vos" ]
then
	$SUDO rm -f $SSHD_COPY
fi

copy_tests

stop_sshd
fi
