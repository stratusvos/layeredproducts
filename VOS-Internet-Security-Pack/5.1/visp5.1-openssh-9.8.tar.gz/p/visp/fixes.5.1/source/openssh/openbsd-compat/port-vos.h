/*
 *
 * Copyright (c) 2005 Paul Green.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* Beginning of modification history */
/* Created 05-07-06 by Paul Green to fix ssl-129. */
/* Modified 05-08-05 by Paul Green to fix ssl-222. */
/* Modified 08-09-04 by Paul Green for Releases 1.1 and 2.1. (ssl-297) */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* End of modification history */

#ifdef __VOS__

#ifdef WITH_VOS_AUTHENTICATION

#include "sshbuf.h"

#include "error_codes.incl.c"
#include "system_io_constants.incl.c"
#include "login_event_constants.incl.c"

/* Enable custom checks for login. */
# define CUSTOM_SYS_AUTH_ALLOWED_USER 1
int sys_auth_allowed_user(struct passwd *pwd, struct sshbuf *loginmsg);

/* Enable VOS password expiration support. */
# define CUSTOM_SYS_AUTH_PASSWD 1

/* Enable logging of successful logins. */
# define CUSTOM_SYS_AUTH_RECORD_LOGIN 1
int sys_auth_record_login(const char *user, const char *host,
     const char *ttyname, struct sshbuf *loginmsg);

/* Enable logging of login failures. */
# define CUSTOM_FAILED_LOGIN 1

#endif /* WITH_VOS_AUTHENTICATION */

int check_do_cli_support();

#endif /* __VOS__ */
