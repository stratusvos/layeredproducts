/*  +++begin copyright+++ *******************************  */
/*                                                         */
/*  STRATUS CONFIDENTIAL INFORMATION                       */
/*  COPYRIGHT (c) 2009, 2012, 2015 Stratus Technologies    */
/*  Bermuda Ltd.                                           */
/*  All Rights Reserved.                                   */
/*                                                         */
/*  This  program  contains  confidential and proprietary  */
/*  information of Stratus Technologies Bermuda Ltd., and  */
/*  any reproduction, disclosure, or use in whole  or  in  */
/*  part  is  expressly  prohibited,  except  as  may  be  */
/*  specifically authorized by prior written agreement or  */
/*  permission of Stratus.                                 */
/*                                                         */
/*  +++end copyright+++ *********************************  */

/*
 *
 * Copyright (c) 2005, 2007, 2008 Paul Green.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Beginning of modification history */
/* Created 05-07-06 by Paul Green to fix ssl-129. */
/* Modified 05-07-22 by Paul Green to implement RADIUS support
     (ssl-212). */
/* Modified 05-10-04 by Paul Green to fix ssl-233. */
/* Modified 07-03-21 by Bill Peach to fix ssl-276 */
/* Modified 07-10-03 by Paul Green to fix ssl-285 and ssl-286. */
/* Modified 08-09-04 by Paul Green for Releases 1.1 and 2.1. (ssl-297) */
/* Modified 2009-03-30 by Dan Swartzendruber to fix ssl-311 */
/* Modified 12-07-24 by Miguel Suarez to fix ssl-409. */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* Modified 15-07-28 by Miguel Suarez to fix ssl-512. */
/* Modified 15-08-14 by Miguel Suarez to fix ssl-513. */
/* Modified 18-09-19 by HsuenJu Ko for LDAP (SED-4165). */
/* Modified 21-03-31 by HsuenJu Ko to fix ssl-662 with 
     uninitialize variable and improve ldap_init so it does not 
     cause fatal error for certain detections.  */
/* End of modification history */

#include <string.h>
#include <shadow.h>

#include "includes.h"

#include "xmalloc.h"
#include "sshbuf.h"
#include "packet.h"
#include "hostfile.h"
#include "auth.h"
#include "ssh.h"
#include "log.h"

#ifdef WITH_VOS_AUTHENTICATION

#include <unistd.h>
#include <dlfcn.h>

#include "port-vos.h"
#include "error_codes.h"
#include "ext_auth_message.h"
#include "ldap_auth_message.h"

extern struct sshbuf loginmsg;

#include "registration_info.h"


#define USE_EXTERNAL_NAME REGISTRATION_INFO_VERSION_6
#define MAX_PASSWORD_LEN 1024

typedef struct $longmap lka_type
{
     void *code_ptr;
     void *static_ptr;
} lka_type;

/* Allow sites to adjust these values */

short int sshd_use_external_name$ = (REGISTRATION_INFO_VERSION_6 + 0);
short int sshd_auth_priority$ = 5;
      int sshd_auth_timeout_ms$ = 61440;        /* ssl-276 */

typedef void (*LDAP_MODE_FUNC) (
          const char_varying       *module_name,
          short                    *mode,
          short                    *code);

typedef void (*LDAP_AUTH_FUNC)  (
     const int                *p_msg_type,      /* (in) msg type */
     const short int          *p_msg_priority,  /* (in) msg priority */
     const int                *p_auth_type,     /* (in) auth type */
     const char_varying      *p_server_module, /* (in) module name */
     const char_varying       *p_person_name,   /* (in) person name */
     const char_varying       *p_old_password,  /* (in) password */
     const char_varying       *p_new_password,  /* (in) password */
     const int                *p_timeout,       /* (in) timeout (1024ths) */
     int                      *p_response,      /* (out) accept/deny/chal */
     char_varying             *p_text,          /* (out) additional text */
     short int                *p_code);         /* (out) status code */

/*
 * LDAP authentication support
 */
LDAP_AUTH_FUNC      ldap_auth_func = NULL;
LDAP_MODE_FUNC      get_ldap_mode_func = NULL;

typedef char_varying(32) * cv32p, cv32;
extern void s$lookup_kernel_address(
               short int * module_id,
               cv32p name,
               short int * flags,
               void * link,
               short int * error_code);
extern void s$perform_ext_authentication (
     const int               *p_msg_type,       /* (in) msg type */
     const short int         *p_msg_priority,   /* (in) msg priority */
     const char_varying      *p_client_handle,  /* (in) client handle */
     const char_varying      *p_person_name,    /* (in) person name */
     const char_varying      *p_password,       /* (in) password */
     const int               *p_chal_type,      /* (in) challenge type */
     const int               *p_auth_type,      /* (in) auth type */
     const int               *p_timeout,        /* (in) timeout (1/1024ths) */
           int               *p_response,       /* (out) accept/deny/chal */
           char_varying      *p_chal_cookie,    /* (in/out) challenge cookie */
           char_varying      *p_challenge,      /* (out) challenge string */
           short int         *p_code);          /* (out) status code */
extern void s$security_log_write (
               const char_varying       *user_name,
               const char_varying       *message,
               const short int          *msg_code,
               const char_varying       *comment,
               short int                *code);
extern void s$set_login_violations (
               const char_varying       *module_name,
               const char_varying       *person,
               const short int          *violation,
               const short int          *num,
               short int                *code);
extern void s$sleep (
               long int                 *time_period, 
               short int                *error_code);

/* program */

# ifdef CUSTOM_SYS_AUTH_ALLOWED_USER

/*
 * Check if specified account is permitted to log in.
 * Returns 1 if login is allowed, 0 if not allowed.
 */
int
sys_auth_allowed_user(struct passwd *pw, struct sshbuf *loginmsg)
{
     return 1;
}
# endif /* CUSTOM_SYS_AUTH_ALLOWED_USER */

# ifdef CUSTOM_SYS_AUTH_PASSWD

/* Update the VOS counter that records the number of consequtive
   bad passwords, and terminate the account of the limit is
   exceeded.  If there is no limit for this user, don't track
   the changes.  This code is similar to login_violation in
   login.pl1.  */

static void
vos_login_violation (Authctxt *p_authctxt, const short int p_violation)
{
/* automatic */

char_varying(66) module_name;
char_varying(32) person;
struct passwd *pw = p_authctxt -> pw;
struct spwd *spw;
short int num;
short int code;
short int open_attempts;
long int sleep_time;
short int violation;
short int ldap_mode = 0;

/* program */

/* Note:  In a multi-module VOS system, a copy of the VOS
   password database is maintained on each module, and one copy
   is the master copy.  The getspnam function reads the values
   from the copy of the database on the current module, but the
   s$set_login_violations subroutine updates the master copy and
   then broadcasts it to the other modules.  Therefore, the
   shadow password values returned by getspnam will lag behind
   the values in the master copy.  A user may actually get more
   attempts to login than VOS allows if a single SSH
   authentication session does not hit the VOS limit.  */

     strcpy_vstr_nstr (&module_name, "");

     if (get_ldap_mode_func != NULL) {
          (*get_ldap_mode_func)(&module_name, &ldap_mode, &code);
          if (ldap_mode)
               return;
     }

     violation = p_violation;
     num = 0;
     switch (violation)
     {
case (LOGIN_RESET_VIOLATIONS):

          // begin ssl-311
          num = -1;
          spw = getspnam (pw->pw_name);
          if (spw != NULL)
               if (spw->sp_num_login_violations > 0)
                    num = 0;
          // end ssl-311

          break;

case (LOGIN_ADD_VIOLATIONS):
          num = -1;
          spw = getspnam (pw->pw_name);
          if (spw != NULL)
          {
               if (spw->sp_max_bad_logins > 0)
               {
                    num = spw->sp_num_login_violations + 1;
                    if (num >= spw->sp_max_bad_logins)
                         violation = LOGIN_TERMINATE_ACCOUNT;
               }
          }
          break;

case (LOGIN_TERMINATE_ACCOUNT):
default:;
          num = 1;
          break;
     }

     if (num >= 0)
     {
          strcpy_vstr_nstr (&module_name, "");
          strcpy_vstr_nstr (&person, pw->pw_name);
          open_attempts = 0;
          sleep_time = 2 * 1024;
          s$set_login_violations (&module_name, &person, &violation,
               &num, &code);
          while (code == e$file_in_use && open_attempts < 30)
          {
               ++open_attempts;
               s$sleep (&sleep_time, &code);
               s$set_login_violations (&module_name, &person, &violation,
                    &num, &code);
          }
          if (code)
               logit("Unable to set bad password count for account %.100s to %d",
                    pw->pw_name, num);
     }
}

/*
 * Do VOS authentication.
 *
 */
int
sys_auth_passwd(struct ssh *mssh, const char *password)
{

/* automatic */

	int authenticated;
	Authctxt *authctxt = mssh->authctxt;
	struct passwd *pw = authctxt->pw;
	char *encrypted_password;
	char_varying(128) client_handle;
	int msg_type;
	short int msg_priority;
	int chal_type;
	int auth_type;
	int timeout;
	int response;
	char_varying(128) cookie;
	char_varying(128) challenge;
	short int error_code;
	short int ignore_code;
	char_varying(128) password_vs;
	char_varying(32) person_name;
	char_varying(66) module_name;
	registration_info_v6_type ri;
	char_varying(256) text;
	short ldap_mode = 0;

/* entries */

extern void s$get_registration_info (char_varying *,
		char_varying *, registration_info_v6_type *, short *, char_varying *);

/* program */

	/* Just use the supplied fake password if authctxt is invalid */
	char *pw_password = authctxt->valid ? shadow_pw(pw) :
		pw->pw_passwd;

	strcpy_vstr_nstr (&module_name, "");
	strcpy_vstr_nstr (&person_name, pw->pw_name);

	if (get_ldap_mode_func)
		(*get_ldap_mode_func)(&module_name, &ldap_mode, &ignore_code);

	/*
	 * ldap_init guarantees both get_ldap_mode_func and ldap_auth_func
	 * are present if one is found.
	 */

	if (ldap_mode && (pw->pw_vos_flags & _PASSWD_VOS_LDAP_AUTHENTICATION))
	{
		char_varying(128) new_password_vs;
		char_varying(256) text;

		msg_type = LDAP_AUTH_MSG;
		msg_priority = sshd_auth_priority$;
		auth_type = LDAP_AUTH_SSH;

		strcpy_vstr_nstr (&password_vs, password);
		strcpy_vstr_nstr (&new_password_vs, "");
		timeout = sshd_auth_timeout_ms$;

		(*ldap_auth_func) (&msg_type, &msg_priority,
			&auth_type, &module_name, &person_name,
			&password_vs, &new_password_vs, &timeout,
			&response, &text, &error_code);

		if (response == LDAP_AUTH_RESPONSE_ACCEPTED)
		{
			if ((error_code == e$password_expire_warning) ||
			    (error_code == e$during_grace_period) ||
			    (error_code == m$login_last_password_warning))
			{
				logit ("ldap authentication: Time to change password");
				authctxt->force_pwchange = 1;
			}
			authenticated = 1;
		}
		else
		{
			logit ("ldap authentication server denied login. %.32s, error %d",
				pw->pw_name, error_code);

			if (error_code == e$password_reset)
			{    
				authctxt->force_pwchange = 1;
				authenticated = 1;
			}
			else authenticated = 0;

			if ((error_code == e$account_locked) ||
			    (error_code == e$password_expired))
				authctxt->vos_terminated = 1;
		}
		return (authenticated);
	}

	if (ldap_mode == 0 && (pw->pw_vos_flags & _PASSWD_VOS_EXT_AUTHENTICATION))
	{

		/* The following macro expression evaluates to TRUE
		   when this code is built on a version of VOS that
		   supports external names, and evaluates to FALSE
		   otherwise.  */

#  if ((USE_EXTERNAL_NAME+0) == REGISTRATION_INFO_VERSION_6)
		if (sshd_use_external_name$ > 0)
		{
			strcpy_vstr_nstr (&text, "");
			ri.v4_data.version = REGISTRATION_INFO_VERSION_6;
			s$get_registration_info (&module_name, &person_name, &ri,
				&error_code, &text);
			if (error_code == 0)
			{
				if (strcmp_vstr_nstr (&ri.external_person, ""))
				{
					logit ("Using external name %.32v to authenticate %.32s.",
						&ri.external_person, pw->pw_name);
					strcpy_vstr_vstr (&person_name, &ri.external_person);
				}
			}
		}
#  endif /* REGISTRATION_INFO_VERSION_6 */

		msg_type = EAM_MSG_INITIAL;
		msg_priority = sshd_auth_priority$;
		strcpy_vstr_nstr (&client_handle, "sshd");
		strcpy_vstr_nstr (&password_vs, password);
		chal_type = EAM_CHAL_FORBID;
		auth_type = EAM_AUTH_OTHER;
		timeout = sshd_auth_timeout_ms$;

		s$perform_ext_authentication (&msg_type, &msg_priority,
			&client_handle, &person_name, &password_vs,
			&chal_type, &auth_type, &timeout, &response,
			&cookie, &challenge, &error_code);
		if (error_code != 0)
		{
			logit ("External authentication server unavailable. %.32s",
				pw->pw_name);
			authenticated = 0;
		}
		else if (response != EAR_RESPONSE_ACCEPTED)
		{
			logit ("External authentication server denied login. %.32s",
				pw->pw_name);
			authenticated = 0;
		}
		else authenticated = 1;
	}
	else
	{
		/* Check for users with no password. */
		if (strncmp(pw_password, "", 1) == 0 && strncmp(password, "", 1) == 0)
			return (1);

		/* Encrypt the candidate password using the proper salt. */
		encrypted_password = xcrypt(password,
		    (pw_password[0] && pw_password[1]) ? pw_password : "xx");

		/*
		 * Authentication is accepted if the encrypted passwords
		 * are identical.
           * [04/14/202] - Use MAX_PASSWORD_LEN with same value defined
           * in auth-passwd.c Might be too much as s$encipher_password2
           * encrypts up to 128 bytes but this could change some day
           * (ssl-683).
		 */
		if (encrypted_password)
			authenticated = 
				(strncmp(encrypted_password, pw_password, MAX_PASSWORD_LEN) == 0);
		else
			authenticated = 0;

		if (ldap_mode == 0)
		{
			if (authenticated)
			     vos_login_violation (authctxt, LOGIN_RESET_VIOLATIONS);
			else vos_login_violation (authctxt, LOGIN_ADD_VIOLATIONS);
		}
	}

	return authenticated;
}
# endif /* CUSTOM_SYS_AUTH_PASSWD */

# ifdef CUSTOM_SYS_AUTH_RECORD_LOGIN

/* This function is called by login_write when a user logs in.
 * Returns 1 if successful, 0 if not successful.
 */

int
sys_auth_record_login(const char *user, const char *host,
     const char *ttyname, struct sshbuf *loginmsg)
{
/* program */

     return 1;
}
# endif /* CUSTOM_SYS_AUTH_RECORD_LOGIN */

# ifdef CUSTOM_FAILED_LOGIN

/* This function is called when a password-based authentication
   fails.  */

void
record_failed_login(struct ssh *ssh, const char *user, const char *hostname, const char *ttyname)
{
short int code;
short int msg_code;
char_varying (256) comments_vs;
char_varying (256) temp_vs;
char_varying (32) user_vs;

/* program */

     strcpy_vstr_nstr (&user_vs, user);
     strcpy_vstr_nstr (&temp_vs, "login ");
     strcat_vstr_nstr (&temp_vs, user);
     strcat_vstr_nstr (&temp_vs, " (from host ");
     strcat_vstr_nstr (&temp_vs, hostname);
     strcat_vstr_nstr (&temp_vs, ") (via ");
     strcat_vstr_nstr (&temp_vs, ttyname);
     strcat_vstr_nstr (&temp_vs, ")");
     msg_code = e$login_access_denied;
     strcpy_vstr_nstr (&comments_vs, "");
     s$security_log_write (&user_vs, &temp_vs, &msg_code,
          &comments_vs, &code);
}
# endif /* CUSTOM_FAILED_LOGIN */
/* Check if a user's account is valid or terminated. 
 * This routine has to be called by a privileged process.
 * We check sp_vos_flags_account_terminated which 
 * gets toggled by registration_admin and then call
 * auth_shadow_acctexpired() for additional checks. */
int vos_terminated_user(Authctxt *authctxt)
{
     int terminated=0;
     struct spwd *spw = NULL;
	
     debug("%s: entering", __func__);

     if ((spw = getspnam(authctxt->user)) == NULL) {
          error("Could not get shadow information for %.100s", authctxt->user);
          return (terminated);
     }

     /* Check if VOS registration has already terminated account. */
     if ((spw->sp_vos_flags & sp_vos_flags_account_terminated))
     {
          terminated=1;
     }else if((terminated=auth_shadow_acctexpired(spw)))
     {
          /* If we haven't terminated the user do so now. */
          vos_login_violation (authctxt, LOGIN_TERMINATE_ACCOUNT);
     }

     debug("%s: user %s account %s",
          __func__, spw->sp_namp, terminated ? "terminated" : "valid");

     return (terminated);
}

void ldap_init()
{
     void *handle;
     short code = 0;
     cv32 entry_name;
     short flags = 0;
     lka_type lka;
     short module_id = 0;

     handle=dlopen("libvos.1.so", RTLD_LAZY);

     if (handle == NULL)
          fatal("%s: Cannot find libvos.1.so", __func__);

     get_ldap_mode_func = (LDAP_MODE_FUNC)dlsym(handle, "s$get_ldap_mode");
     ldap_auth_func = (LDAP_AUTH_FUNC)dlsym(handle, "s$perform_ldap_auth");

     if ((get_ldap_mode_func != NULL) && (ldap_auth_func == NULL)) {
          error("%s: Cannot find s$perform_ldap_auth", __func__);
          get_ldap_mode_func = NULL;
     }
     else if ((get_ldap_mode_func == NULL) && (ldap_auth_func != NULL)) {
          error("%s: Cannot find s$get_ldap_mode", __func__);
          ldap_auth_func = NULL;
     }
     strlcpy_vstr_nstr(&entry_name, "s$get_ldap_ppolicy", 32);
     s$lookup_kernel_address (&module_id, &entry_name,
               &flags, &lka, &code);

     if (code == 0) {
          /*
           * If the kernel supports VOS unified registration we make
           * sure this daemon is loaded with proper shared library
           * which supports LDAP authentication.
           */

          if ((get_ldap_mode_func == NULL) && (ldap_auth_func == NULL))
               fatal("%s: Cannot find s$get_ldap_mode and s$perform_ldap_auth",
                    __func__);
     }
     else {
          /*
           * If the kernel does not support VOS unified registration but
           * we found ldap routines, assume it does not support unified
           * registration by clearing the pointer.
           */
          if ((get_ldap_mode_func != NULL) || (ldap_auth_func != NULL)) {
               get_ldap_mode_func = NULL;
               ldap_auth_func = NULL;
          }
     }
     dlclose(handle);

     return;
}

int check_do_cli_support()
{
     short code = 0;
     cv32 entry_name;
     short flags = 0;
     lka_type lka;
     short module_id = 0;

     strlcpy_vstr_nstr(&entry_name, "s$stop_program_do_cli", 32);
     s$lookup_kernel_address (&module_id, &entry_name, &flags, &lka, &code);
     if (code) {
          return 0;  /* not found */
     }
     return 1; /* not found */
}
#endif /* WITH_VOS_AUTHENTICATION */
