DROP TABLE persons;
DROP TABLE institutes;
DROP TABLE documents;
DROP TABLE authors_docs;
DROP TABLE phones;
