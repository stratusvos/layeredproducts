/* $OpenBSD: canohost.h,v 1.12 2016/03/07 19:02:43 djm Exp $ */

/*
 * Author: Tatu Ylonen <ylo@cs.hut.fi>
 * Copyright (c) 1995 Tatu Ylonen <ylo@cs.hut.fi>, Espoo, Finland
 *                    All rights reserved
 *
 * As far as I am concerned, the code I have written for this software
 * can be used freely for any purpose.  Any derived versions of this
 * software must be clearly marked as such, and if the derived work is
 * incompatible with the protocol description in the RFC file, it must be
 * called by a name other than "ssh" or "Secure Shell".
 */

/* Beginning of modification history */
/* Modified 11-07-26 by Paul Green to provide a function to return
     the device name. (ssl-274) */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* End of modification history */

#ifndef _CANOHOST_H
#define _CANOHOST_H

char		*get_peer_ipaddr(int);
int		 get_peer_port(int);
char		*get_local_ipaddr(int);
char		*get_local_name(int);
int		get_local_port(int);

#endif /* _CANOHOST_H */

void		 ipv64_normalise_mapped(struct sockaddr_storage *, socklen_t *);

#ifdef __VOS__
char		*get_local_device_name(struct ssh *ssh);
char		*get_remote_device_name(struct ssh *ssh);
#endif
