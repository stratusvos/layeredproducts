
This sample application is a GUI application used to
demonstrate Berkeley DB running on Windows CE.

If you are not developing for Windows CE, this is probably not where you
want to be looking.
