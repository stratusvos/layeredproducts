#include "config.h"

const char *version_string = "GNU Awk 4.0.0";
