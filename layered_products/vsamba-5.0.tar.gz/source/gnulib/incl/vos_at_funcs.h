
/* This header holds declarations for all new *at* functions.
 * However this is not quite kosher. We're really supposed
 * to put the declarations in one of the standarad headers
 * like fcntl.h or string.h. Since this is just for vsamba
 * we'll lump them all here but that means we need do things
 * like include dirent.h for fdopendir() to define DIR because
 * this is not a common header.
 */

/* ------------------- fcntl.h ------------------------- */

int openat (int fd, char const *file, int flags, ...);

/* ------------------- fcntl.h (req: unistd.h) --------- */

int fchownat (int fd, char const *file, uid_t owner, gid_t group, int flag);

ssize_t readlinkat (int fd, char const *file, char *buf, size_t len);

int symlinkat (char const *contents, int fd, char const *file);

int unlinkat (int fd, char const *file, int flag);

/* ------------------- fcntl.h (req: sys/stat.h) --------- */

int fchmodat (int fd, char const *file, mode_t mode, int flag);

int fstatat (int fd, char const *name, struct stat *st, int flags);

int mkdirat (int fd, char const *file, mode_t mode);

/* ------------------- string.h ------------------------- */

void * memrchr (void const *s, int, size_t);

/* ------------------- dirent.h ------------------------- */

#include <dirent.h>

DIR *fdopendir (int fd);

#ifndef AT_FDCWD
# define AT_FDCWD (-3041965)
#endif

#ifndef AT_SYMLINK_NOFOLLOW
# define AT_SYMLINK_NOFOLLOW 4096
#endif

#ifndef AT_REMOVEDIR
# define AT_REMOVEDIR 1
#endif

#ifndef AT_SYMLINK_FOLLOW
# define AT_SYMLINK_FOLLOW 2
#endif

#ifndef AT_EACCESS
# define AT_EACCESS 4
#endif

#ifndef O_CLOEXEC
# define O_CLOEXEC 0x40000000 /* Try to not collide with system O_* flags.  */
#endif
