#include <config.h>
#include "system.h"
#include "scan-gram.c"
