delimiter //
create table t2 (a int) //
delimiter ;
\d //
create table t3 (a int) //
\d ;
show tables;
drop table t2, t3;
