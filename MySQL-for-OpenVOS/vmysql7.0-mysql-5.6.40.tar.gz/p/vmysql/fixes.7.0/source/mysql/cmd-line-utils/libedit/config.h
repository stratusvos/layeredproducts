#include "my_config.h"
#include "sys.h"
#ifdef __VOS__
#ifndef NARROW_WRAPPER
#define NARROW_WRAPPER
#endif
#ifndef SIGWINCH
#define SIGWINCH SIGUSR1
#endif
#endif /* __VOS__ */
#ifndef NARROW_WRAPPER
#define WIDECHAR
#endif
