$self->{LIBS} = [''];
