
/*
 * Hello comment.
 */
static void hello(void)	// Begin of hello
{
	/*
	 * Classic.
	 */
	putchar('H');
	putchar('e');
	putchar('l');
	putchar('l');
	putchar('o');
	putchar(' ');
	/* delete me from hello */
	putchar('w');
	putchar('o');
	putchar('r');
	putchar('l');
	putchar('d');
	putchar('.');
	putchar('\n');
}	// End of hello
