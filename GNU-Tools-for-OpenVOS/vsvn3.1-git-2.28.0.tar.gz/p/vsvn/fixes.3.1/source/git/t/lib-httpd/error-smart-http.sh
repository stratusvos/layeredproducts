echo "Content-Type: application/x-git-upload-pack-advertisement"
echo
printf "%s" "0019ERR server-side error"
