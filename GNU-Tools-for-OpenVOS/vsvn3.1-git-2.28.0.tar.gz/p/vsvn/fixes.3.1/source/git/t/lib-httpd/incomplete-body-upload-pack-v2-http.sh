printf "Content-Type: text/%s\n" "application/x-git-upload-pack-result"
echo
printf "%s%s" "0079" "45"
