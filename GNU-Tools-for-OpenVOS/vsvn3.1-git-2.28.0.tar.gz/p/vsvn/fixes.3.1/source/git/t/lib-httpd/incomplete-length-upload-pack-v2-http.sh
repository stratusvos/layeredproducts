printf "Content-Type: text/%s\n" "application/x-git-upload-pack-result"
echo
printf "%s" "00"
