
# This file just supplies labeled ending points for the .stab*
# special sections.  It is linked in last after other modules.
 
     .file     "crtn.s"
     .ident    "GNU C crtn.s"

; The end of the .ctor and .dtor sections.

     .section  .ctors,"aw"
     .align    4
     .export   __CTOR_END__,data
__CTOR_END__:
     .word     0

     .section  .dtors,"aw"
     .align    4
     .export   __DTOR_END__,data
__DTOR_END__:
     .word     0

; Switch to the .stab section and create a symbol at the end of it.

     .section  .stab
     .export   __STAB_END__,data
__STAB_END__:

; Do the same for the .stabstr section.

     .section  .stabstr
     .export   __STABSTR_END__,data
__STABSTR_END__:

; Create one dummy stab entry to make the assembler happy.

     .stabs    "crtn.s",100,0,0,0

     .end
