
# This file just supplies labeled starting points for the .stab*
# special sections.  It is linked in first before other modules.
 
     .file     "crti.s"
     .ident    "GNU C crti.s"

; The beginning of the .ctor and .dtor sections.

     .section  .ctors,"aw"
     .align    4
     .export   __CTOR_LIST__,data
__CTOR_LIST__:
     .word     -1

     .section  .dtors,"aw"
     .align    4
     .export   __DTOR_LIST__,data
__DTOR_LIST__:
     .word     -1

; Create one dummy stab entry to make the assembler happy.

     .stabs    "crti.s",100,0,0,0

; Switch to the .stab section and create a symbol at the beginning of it.

     .section  .stab
     .export   __STAB_BEGIN__,data
__STAB_BEGIN__:

; Do the same for the .stabstr section.

     .section  .stabstr
     .export   __STABSTR_BEGIN__,data
__STABSTR_BEGIN__:

     .end
