struct a
{
  a();
  ~a();
};
