include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/compat/abi

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	bitfield1.pm bitfield1.out \
	bitfield2.pm bitfield2.out \
	vbase8-4.pm  vbase8-4.out \
	vbase8-10.pm vbase8-10.out \
	vbase8-21.pm vbase8-21.out \
	vbase8-22.pm vbase8-22.out

all: $(ALL_TESTS)

clean:
	$(RM) $(ALL_TESTS)




bitfield1.pm: bitfield1_main.C bitfield1_x.C bitfield1_y.C
	$(CXX) -funsigned-bitfields -o $@ $^ $(EXTRALIBS)

bitfield2.pm: bitfield2_main.C bitfield2_x.C bitfield2_y.C
	$(CXX) -fsigned-bitfields -o $@ $^ $(EXTRALIBS)

vbase8-4.pm: vbase8-4_main.C vbase8-4_x.C vbase8-4_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

vbase8-10.pm: vbase8-10_main.C vbase8-10_x.C vbase8-10_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

vbase8-21.pm: vbase8-21_main.C vbase8-21_x.C vbase8-21_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

vbase8-22.pm: vbase8-22_main.C vbase8-22_x.C vbase8-22_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)




include $(TESTSRCDIR)/lib/quickndirtyrules.mk
