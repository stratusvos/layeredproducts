include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/compat/break

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	bitfield5.pm bitfield5.out \
	bitfield7.pm bitfield7.out \
	empty6.pm  empty6.out \
	vbase10.pm vbase10.out \
	vbase11.pm vbase11.out

all: $(ALL_TESTS)

clean:
	$(RM) $(ALL_TESTS)




bitfield5.pm: bitfield5_main.C bitfield5_x.C bitfield5_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

bitfield7.pm: bitfield7_main.C bitfield7_x.C bitfield7_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

empty6.pm: empty6_main.C empty6_x.C empty6_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

vbase10.pm: vbase10_main.C vbase10_x.C vbase10_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

vbase11.pm: vbase11_main.C vbase11_x.C vbase11_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)




include $(TESTSRCDIR)/lib/quickndirtyrules.mk
