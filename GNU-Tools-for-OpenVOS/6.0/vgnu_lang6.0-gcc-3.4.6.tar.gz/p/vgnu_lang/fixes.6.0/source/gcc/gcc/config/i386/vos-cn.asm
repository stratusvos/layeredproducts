
     .include  "unwind_info.incl.x86"

# This file supplies labeled ending points for special sections.
# It is linked in last after other modules.
 
     .file     "crtn.s"
     .ident    "GNU C crtn.s"

# The end of the .ctor and .dtor sections.

     .section  .ctors,"aw"
     .align    4
     .globl    __CTOR_END__
     .hidden   __CTOR_END__
__CTOR_END__:
     .long     0

     .section  .dtors,"aw"
     .align    4
     .globl   __DTOR_END__
     .hidden  __DTOR_END__
__DTOR_END__:
     .long     0

# The .fini_array section contains a pointer to the function that walks the
# .dtor section to call all the static destructors.

     .section  .fini_array
     .pushendian big
     .long     __do_global_dtors_1@FPTR
     .popendian

# Since we might be called twice (once via the pointer in .fini_array above,
# once from atexit()), we keep a flag so we only run destructors once.

     .data
     .align    4
already_done:
     .long     0

# __do_global_dtors_1 calls the static destructors by scanning the list
# forwards.

     .text
     .align    4
    PROCSTART3 __do_global_dtors_1, 16, FP_IN_REG|EBX_SAVED|EDI_SAVED
     .globl    __do_global_dtors_1
     .hidden   __do_global_dtors_1
     .type     __do_global_dtors_1, @function
__do_global_dtors_1:
     PROCENTER
     testl     $-1,already_done@GOTOFF(%edx)
     jne       .ret
     movl      $1,already_done@GOTOFF(%edx)

     movl      __DTOR_LIST__@GOT(%edx),%ebx
     movl      __DTOR_END__@GOT(%edx),%edi

.loop:
     addl      $4,%ebx
     cmpl      %edi,%ebx
     je        .ret

     movl      (%ebx),%eax
#ifndef __LITTLE_ENDIAN__
     bswap     %eax
#endif
     movl      8(%eax),%edx
     bswap     %edx
     movl      4(%eax),%eax
     bswap     %eax
     call      *%eax
     jmp       .loop

.ret:
     PROCLEAVE
     PROCEND

# The following definitions define the end of various DWARF2 structures.

     .section  .debug_info
     .globl    __DWARF2_INFO_END__
     .type     __DWARF2_INFO_END__,@object
__DWARF2_INFO_END__:

     .section  .debug_abbrev
     .globl    __DWARF2_ABBREV_END__
     .type     __DWARF2_ABBREV_END__,@object
__DWARF2_ABBREV_END__:

     .section  .debug_line
     .globl    __DWARF2_LINE_END__
     .type     __DWARF2_LINE_END__,@object
__DWARF2_LINE_END__:

     .section  .debug_pubnames
     .globl    __DWARF2_PUBNAMES_END__
     .type     __DWARF2_PUBNAMES_END__,@object
__DWARF2_PUBNAMES_END__:

     .section  .debug_aranges
     .globl    __DWARF2_ARANGES_END__
     .type     __DWARF2_ARANGES_END__,@object
__DWARF2_ARANGES_END__:

     .section  .debug_loc
     .globl    __DWARF2_LOC_END__
     .type     __DWARF2_LOC_END__,@object
__DWARF2_LOC_END__:

     .section  .debug_macinfo
     .globl    __DWARF2_MACINFO_END__
     .type     __DWARF2_MACINFO_END__,@object
__DWARF2_MACINFO_END__:

     .section  .debug_str
     .globl    __DWARF2_STR_END__
     .type     __DWARF2_STR_END__,@object
__DWARF2_STR_END__:


     .section  .debug_ranges
     .globl    __DWARF2_RANGES_END__
     .type     __DWARF2_RANGES_END__,@object
__DWARF2_RANGES_END__:

     .section  .debug_frame
     .globl    __DWARF2_FRAME_END__
     .type     __DWARF2_FRAME_END__,@object
__DWARF2_FRAME_END__:

     .end
