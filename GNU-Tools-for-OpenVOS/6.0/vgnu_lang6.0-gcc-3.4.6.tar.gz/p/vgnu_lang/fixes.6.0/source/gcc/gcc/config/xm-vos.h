/* Configuration for GNU C-compiler for PA-RISC.
   Copyright (C) 1988, 1995, 1997 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com).

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


/* Using VOS with POSIX.1 support */
#ifndef VOS
#define VOS
#endif

#ifndef POSIX
#define POSIX
#endif

/* Arguments to use with `exit'.  */
#define SUCCESS_EXIT_CODE 0
#define FATAL_EXIT_CODE 33

#define DIR_SEPARATOR '/'
#define DIR_SEPARATOR_2 '>'

#define HOST_EXECUTABLE_SUFFIX ".pm"

/* Use current include library paths instead of a fixed dir */
#undef STANDARD_INCLUDE_DIR
#define STANDARD_INCLUDE_DIR 0
