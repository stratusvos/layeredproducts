include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/compat/eh

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	ctor1.pm ctor1.out \
	ctor2.pm ctor2.out \
	dtor1.pm dtor1.out \
	filter1.pm  filter1.out \
	filter2.pm filter2.out \
	new1.pm new1.out \
	nrv1.pm nrv1.out \
	spec3.pm spec3.out \
	template1.pm template1.out \
	unexpected1.pm unexpected1.out

all: $(ALL_TESTS)

clean:
	$(RM) $(ALL_TESTS)




ctor1.pm: ctor1_main.C ctor1_x.C ctor1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

ctor2.pm: ctor2_main.C ctor2_x.C ctor2_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

dtor1.pm: dtor1_main.C dtor1_x.C dtor1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

filter1.pm: filter1_main.C filter1_x.C filter1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

filter2.pm: filter2_main.C filter2_x.C filter2_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

new1.pm: new1_main.C new1_x.C new1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

nrv1.pm: nrv1_main.C nrv1_x.C nrv1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

spec3.pm: spec3_main.C spec3_x.C spec3_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

template1.pm: template1_main.C template1_x.C template1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

unexpected1.pm: unexpected1_main.C unexpected1_x.C unexpected1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)




include $(TESTSRCDIR)/lib/quickndirtyrules.mk
