include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/abi

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	bitfield1.out \
	bitfield10.s \
	bitfield11.abiv0.out \
	bitfield12.abiv1.s \
	bitfield2.out \
	bitfield3.$(X86ONLY).out \
	bitfield4.out \
	bitfield5.s \
	bitfield6.abiv0.out \
	bitfield7.s \
	bitfield8.abiv0.$(X86ONLY).out \
	bitfield9.$(X86ONLY).out \
	cookie1.abiv0.$(X86ONLY).s \
	cookie2.abiv1.s \
	covariant1.s \
	covariant2.s \
	covariant3.out \
	dcast1.s \
	dtor1.abiv0.$(X86ONLY).s \
	dtor2.s \
	empty4.out \
	empty5.abiv0.s \
	empty6.s \
	empty7.abiv0.$(X86ONLY).out \
	empty8.abiv0.out \
	empty9.abiv0.$(X86ONLY).out \
	empty10.abiv0.$(X86ONLY).out \
	empty11.abiv0.out \
	enum1.out \
	layout1.out \
	layout2.out \
	layout3.abiv0.$(X86ONLY).out \
	layout4.abiv1.$(X86ONLY).out \
	macro0.abiv0.s \
	macro1.abiv1.s \
	macro2.abiv2.s \
	mangle1.s \
	mangle2.out \
	mangle3.s \
	mangle4.xfail.s \
	mangle5.s \
	mangle6.unsupported.s \
	mangle7.s \
	mangle8.s \
	mangle9.abiv0.s \
	mangle10.abiv0.s \
	mangle11.s \
	mangle12.s \
	mangle13.abiv0.s \
	mangle14.s \
	mangle15.abiv0.s \
	mangle16.abiv0.s \
	mangle17.s \
	mangle18-1.abiv2.s \
	mangle18-2.abiv1.s \
	mangle19-1.abiv2.s \
	mangle19-2.abiv1.s \
	mangle20-1.abiv2.s \
	mangle20-2.abiv1.s \
	mangle21.o \
	offsetof.out \
	param1.out \
	rtti1.s \
	rtti2.out \
	structret1.unsupported.out \
	thunk1.$(X86ONLY).s \
	thunk2.$(X86ONLY).s \
	vague1.s \
	vbase1.s \
	vbase8-10.out \
	vbase8-21.out \
	vbase8-22.out \
	vbase8-4.out \
	vbase9.s \
	vbase10.s \
	vbase11.abiv0.$(X86ONLY).out \
	vbase12.abiv0.out \
	vbase13.abiv0.out \
	vbase14.s \
	vcall1.out \
	vthunk1.pm \
	vthunk2.$(X86ONLY).s \
	vthunk3.abiv0.$(X86ONLY).s \
	vtt1.s

all: $(ALL_TESTS)

clean:
	rm -fr $(ALL_TESTS)



bitfield1.pm: bitfield1.C
	$(CXX) -funsigned-bitfields -o $@ $^ $(EXTRALIBS)

bitfield10.s: bitfield10.C
	$(CXX) -w -S -o $@ $^

bitfield11.abiv0.pm: bitfield11.C
	$(CXX) -fabi-version=0 -w -o $@ $^ $(EXTRALIBS)

bitfield12.abiv1.s: bitfield12.C
	$(CXX) -fabi-version=1 -Wabi -S -o $@ $^

bitfield2.pm: bitfield2.C
	$(CXX) -fsigned-bitfields -o $@ $^ $(EXTRALIBS)

bitfield9.x86only.pm: bitfield9.C
	$(CXX) -w -o $@ $^ $(EXTRALIBS)

covariant1.s: covariant1.C
	$(CXX) -w -S -o $@ $^

mangle18-2.abiv1.s: mangle18-2.C
	$(CXX) -fabi-version=1 -Wabi -S -o $@ $^

mangle19-2.abiv1.s: mangle19-2.C
	$(CXX) -fabi-version=1 -Wabi -S -o $@ $^

mangle20-2.abiv1.s: mangle20-2.C
	$(CXX) -fabi-version=1 -Wabi -S -o $@ $^

include $(TESTSRCDIR)/lib/quickndirtyrules.mk
