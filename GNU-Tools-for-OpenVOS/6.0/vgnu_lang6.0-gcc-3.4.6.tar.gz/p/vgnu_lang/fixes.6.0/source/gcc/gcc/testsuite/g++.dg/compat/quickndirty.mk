include $(TESTSRCDIR)/lib/quickndirtydefs.mk

all clean:
	if [ ! -d abi ] ; then mkdir abi ; fi
	$(MAKE) -C abi $@ 'GCC=$(GCC)' 'GXX=$(GXX)' TESTSRCDIR=$(TESTSRCDIR) \
		-f $(TESTSRCDIR)/g++.dg/compat/abi/quickndirty.mk
	if [ ! -d break ] ; then mkdir break ; fi
	$(MAKE) -C break $@ 'GCC=$(GCC)' 'GXX=$(GXX)' TESTSRCDIR=$(TESTSRCDIR) \
		-f $(TESTSRCDIR)/g++.dg/compat/break/quickndirty.mk
	if [ ! -d eh ] ; then mkdir eh ; fi
	$(MAKE) -C eh $@ 'GCC=$(GCC)' 'GXX=$(GXX)' TESTSRCDIR=$(TESTSRCDIR) \
		-f $(TESTSRCDIR)/g++.dg/compat/eh/quickndirty.mk
	if [ ! -d init ] ; then mkdir init ; fi
	$(MAKE) -C init $@ 'GCC=$(GCC)' 'GXX=$(GXX)' TESTSRCDIR=$(TESTSRCDIR) \
		-f $(TESTSRCDIR)/g++.dg/compat/init/quickndirty.mk

include $(TESTSRCDIR)/lib/quickndirtyrules.mk
