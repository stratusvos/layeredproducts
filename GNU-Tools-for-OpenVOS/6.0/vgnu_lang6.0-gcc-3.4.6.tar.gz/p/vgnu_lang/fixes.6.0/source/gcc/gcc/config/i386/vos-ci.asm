
     .include  "unwind_info.incl.x86"

# This file supplies labeled starting points for special sections.
# It is linked in first before other modules.
 
     .file     "crti.s"
     .ident    "GNU C crti.s"

# The beginning of the .ctor and .dtor sections.

     .section  .ctors,"aw"
     .align    4
     .globl    __CTOR_LIST__
     .hidden   __CTOR_LIST__
__CTOR_LIST__:
     .long     -1

     .section  .dtors,"aw"
     .align    4
     .globl    __DTOR_LIST__
     .hidden   __DTOR_LIST__
__DTOR_LIST__:
     .long     -1

# The .init_array section contains a pointer to the function that walks the 
# .ctor section to call all the static constructors.

     .section  .init_array
     .pushendian big
     .long     __do_global_ctors_1@FPTR
     .popendian

# Since we might be called twice (once via the pointer in .init_array above,
# once from __main), we keep a flag so we only run constructors once.

     .data
     .align    4
already_done:
     .long     0

# __do_global_ctors_1 calls the static constructors by scanning the list 
# backwards.

     .text
     .align    4
    PROCSTART3 __do_global_ctors_1, 16, FP_IN_REG|EBX_SAVED|EDI_SAVED
     .globl    __do_global_ctors_1
     .hidden   __do_global_ctors_1
     .type     __do_global_ctors_1, @function
__do_global_ctors_1:
     PROCENTER
     testl     $-1,already_done@GOTOFF(%edx)
     jne       .ret
     movl      $1,already_done@GOTOFF(%edx)

     movl      __CTOR_END__@GOT(%edx),%ebx
     movl      __CTOR_LIST__@GOT(%edx),%edi

.loop:
     subl      $4,%ebx
     cmpl      %edi,%ebx
     je        .ret

     movl      (%ebx),%eax
#ifndef __LITTLE_ENDIAN__
     bswap     %eax
#endif
     movl      8(%eax),%edx
     bswap     %edx
     movl      4(%eax),%eax
     bswap     %eax
     call      *%eax
     jmp       .loop

.ret:
     PROCLEAVE
     PROCEND

# The following definitions define the beginning of various DWARF2 structures.

     .section  .debug_info
     .globl    __DWARF2_INFO_BEGIN__
     .type     __DWARF2_INFO_BEGIN__,@object
__DWARF2_INFO_BEGIN__:

     .section  .debug_abbrev
     .globl    __DWARF2_ABBREV_BEGIN__
     .type     __DWARF2_ABBREV_BEGIN__,@object
__DWARF2_ABBREV_BEGIN__:

     .section  .debug_line
     .globl    __DWARF2_LINE_BEGIN__
     .type     __DWARF2_LINE_BEGIN__,@object
__DWARF2_LINE_BEGIN__:

     .section  .debug_pubnames
     .globl    __DWARF2_PUBNAMES_BEGIN__
     .type     __DWARF2_PUBNAMES_BEGIN__,@object
__DWARF2_PUBNAMES_BEGIN__:

     .section  .debug_aranges
     .globl    __DWARF2_ARANGES_BEGIN__
     .type     __DWARF2_ARANGES_BEGIN__,@object
__DWARF2_ARANGES_BEGIN__:

     .section  .debug_loc
     .globl    __DWARF2_LOC_BEGIN__
     .type     __DWARF2_LOC_BEGIN__,@object
__DWARF2_LOC_BEGIN__:

     .section  .debug_macinfo
     .globl    __DWARF2_MACINFO_BEGIN__
     .type     __DWARF2_MACINFO_BEGIN__,@object
__DWARF2_MACINFO_BEGIN__:

     .section  .debug_str
     .globl    __DWARF2_STR_BEGIN__
     .type     __DWARF2_STR_BEGIN__,@object
__DWARF2_STR_BEGIN__:

     .section  .debug_ranges
     .globl    __DWARF2_RANGES_BEGIN__
     .type     __DWARF2_RANGES_BEGIN__,@object
__DWARF2_RANGES_BEGIN__:

     .section  .debug_frame
     .align    4
     .globl    __DWARF2_FRAME_BEGIN__
     .type     __DWARF2_FRAME_BEGIN__,@object
__DWARF2_FRAME_BEGIN__:

     .end

