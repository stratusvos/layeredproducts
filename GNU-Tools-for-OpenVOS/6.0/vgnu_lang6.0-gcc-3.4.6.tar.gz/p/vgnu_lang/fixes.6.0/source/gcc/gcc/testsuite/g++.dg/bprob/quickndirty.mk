include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/bprob

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	g++-bprob-1.unsupported.out

all: $(ALL_TESTS)

clean:
	$(RM) $(ALL_TESTS)

include $(TESTSRCDIR)/lib/quickndirtyrules.mk
