include $(TESTSRCDIR)/lib/quickndirtydefs.mk

VPATH = $(TESTSRCDIR)/g++.dg/compat/init

DEFAULT_CFLAGS = -O2

ALL_TESTS = \
	array5.pm array5.out \
	byval1.pm byval1.out \
	dtor1.pm  dtor1.out \
	elide1.pm elide1.out \
	init-ref2.pm init-ref2.out

all: $(ALL_TESTS)

clean:
	$(RM) $(ALL_TESTS)




array5.pm: array5_main.C array5_x.C array5_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

byval1.pm: byval1_main.C byval1_x.C byval1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

dtor1.pm: dtor1_main.C dtor1_x.C dtor1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

elide1.pm: elide1_main.C elide1_x.C elide1_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)

init-ref2.pm: init-ref2_main.C init-ref2_x.C init-ref2_y.C
	$(CXX) -o $@ $^ $(EXTRALIBS)




include $(TESTSRCDIR)/lib/quickndirtyrules.mk
