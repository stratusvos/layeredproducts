char *xgethostname (void);
