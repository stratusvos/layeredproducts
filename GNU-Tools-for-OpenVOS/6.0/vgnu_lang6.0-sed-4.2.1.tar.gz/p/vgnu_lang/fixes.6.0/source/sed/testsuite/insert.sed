/foo/i\
