#!/bin/sh
#
# Test @include facility
#

: ${TESTSUDOERS=testsudoers}

MYUID=`\ls -ln $TESTDIR/test2.inc | awk '{print $3}'`
MYGID=`\ls -ln $TESTDIR/test2.inc | awk '{print $4}'`
exec 2>&1

echo "Testing @include"
echo ""
$TESTSUDOERS -p ../../../../sudo/plugins/sudoers/regress/passwd -P ../../../../sudo/plugins/sudoers/regress/group -U $MYUID -G $MYGID root id <<EOF
@include $TESTDIR/test2.inc
EOF

echo ""
echo "Testing #include"
echo ""
$TESTSUDOERS -p ../../../../sudo/plugins/sudoers/regress/passwd -P ../../../../sudo/plugins/sudoers/regress/group -U $MYUID -G $MYGID root id <<EOF
#include $TESTDIR/test2.inc
EOF

exit 0
