#!/bin/sh
#
# Test for NULL dereference with "sudo -g group" when the sudoers rule
# has no runas user or group listed.
# This is RedHat bug Bug 667103.
#

: ${TESTSUDOERS=testsudoers}

exec 2>&1
$TESTSUDOERS -p ../../../../sudo/plugins/sudoers/regress/passwd -P ../../../../sudo/plugins/sudoers/regress/group -g bin root id <<EOF
root ALL = ALL
EOF

exit 0
