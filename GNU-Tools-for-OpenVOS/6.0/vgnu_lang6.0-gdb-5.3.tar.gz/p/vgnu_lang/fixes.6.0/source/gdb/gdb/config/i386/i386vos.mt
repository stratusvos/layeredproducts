# Target: i386 running VOS

TDEPFILES= i386vos-tdep.o i386-tdep.o i387-tdep.o

TM_FILE= tm-i386vos.h
