# Target: HP PA-RISC running VOS

TDEPFILES= hppav-tdep.o
TM_FILE= tm-hppav.h
