/* nm.c -- Describe symbol table of a rel file.
   Copyright 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000,
   2001, 2002, 2003
   Free Software Foundation, Inc.

   This file is part of GNU Binutils.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA.  */

#include "bfd.h"
#include "progress.h"
#include "bucomm.h"
#include "budemang.h"
#include "getopt.h"
#include "aout/stab_gnu.h"
#include "aout/ranlib.h"
#include "demangle.h"
#include "libiberty.h"
#include "elf-bfd.h"
#include "elf/common.h"

/* When sorting by size, we use this structure to hold the size and a
   pointer to the minisymbol.  */

struct size_sym
{
  const PTR minisym;
  bfd_vma size;
};

/* When fetching relocs, we use this structure to pass information to
   get_relocs.  */

struct get_relocs_info
{
  asection **secs;
  arelent ***relocs;
  long *relcount;
  asymbol **syms;
};

struct extended_symbol_info
{
  symbol_info *sinfo;
  bfd_vma ssize;
  elf_symbol_type *elfinfo;
  /* FIXME: We should add more fields for Type, Line, Section.  */
};
#define SYM_NAME(sym)        (sym->sinfo->name)
#define SYM_VALUE(sym)       (sym->sinfo->value)
#define SYM_TYPE(sym)        (sym->sinfo->type)
#define SYM_STAB_NAME(sym)   (sym->sinfo->stab_name)
#define SYM_STAB_DESC(sym)   (sym->sinfo->stab_desc)
#define SYM_STAB_OTHER(sym)  (sym->sinfo->stab_other)
#define SYM_SIZE(sym) \
  (sym->elfinfo ? sym->elfinfo->internal_elf_sym.st_size: sym->ssize)

static void usage
  PARAMS ((FILE *, int));
static void set_print_radix
  PARAMS ((char *));
static void set_output_format
  PARAMS ((char *));
static void display_archive
  PARAMS ((bfd *));
static bfd_boolean display_file
  PARAMS ((char *));
static void display_rel_file
  PARAMS ((bfd *, bfd *));
static long filter_symbols
  PARAMS ((bfd *, bfd_boolean, PTR, long, unsigned int));
static long sort_symbols_by_size
  PARAMS ((bfd *, bfd_boolean, PTR, long, unsigned int, struct size_sym **));
static void print_symbols
  PARAMS ((bfd *, bfd_boolean, PTR, long, unsigned int, bfd *));
static void print_size_symbols
  PARAMS ((bfd *, bfd_boolean, struct size_sym *, long, bfd *));
static void print_symname
  PARAMS ((const char *, const char *, bfd *));
static void print_symbol
  PARAMS ((bfd *, asymbol *, bfd_vma ssize, bfd *));
static void print_symdef_entry
  PARAMS ((bfd *));

/* The sorting functions.  */
static int numeric_forward
  PARAMS ((const PTR, const PTR));
static int numeric_reverse
  PARAMS ((const PTR, const PTR));
static int non_numeric_forward
  PARAMS ((const PTR, const PTR));
static int non_numeric_reverse
  PARAMS ((const PTR, const PTR));
static int size_forward1
  PARAMS ((const PTR, const PTR));
static int size_forward2
  PARAMS ((const PTR, const PTR));

/* The output formatting functions.  */
static void print_object_filename_bsd
  PARAMS ((char *));
static void print_object_filename_sysv
  PARAMS ((char *));
static void print_object_filename_posix
  PARAMS ((char *));
static void print_archive_filename_bsd
  PARAMS ((char *));
static void print_archive_filename_sysv
  PARAMS ((char *));
static void print_archive_filename_posix
  PARAMS ((char *));
static void print_archive_member_bsd
  PARAMS ((char *, const char *));
static void print_archive_member_sysv
  PARAMS ((char *, const char *));
static void print_archive_member_posix
  PARAMS ((char *, const char *));
static void print_symbol_filename_bsd
  PARAMS ((bfd *, bfd *));
static void print_symbol_filename_sysv
  PARAMS ((bfd *, bfd *));
static void print_symbol_filename_posix
  PARAMS ((bfd *, bfd *));
static void print_value
  PARAMS ((bfd *, bfd_vma));
static void print_symbol_info_bsd
  PARAMS ((struct extended_symbol_info *, bfd *));
static void print_symbol_info_sysv
  PARAMS ((struct extended_symbol_info *, bfd *));
static void print_symbol_info_posix
  PARAMS ((struct extended_symbol_info *, bfd *));
static void get_relocs
  PARAMS ((bfd *, asection *, PTR));
static const char * get_symbol_type
  PARAMS ((unsigned int));

/* Support for different output formats.  */
struct output_fns
  {
    /* Print the name of an object file given on the command line.  */
    void (*print_object_filename) PARAMS ((char *));

    /* Print the name of an archive file given on the command line.  */
    void (*print_archive_filename) PARAMS ((char *));

    /* Print the name of an archive member file.  */
    void (*print_archive_member) PARAMS ((char *, const char *));

    /* Print the name of the file (and archive, if there is one)
       containing a symbol.  */
    void (*print_symbol_filename) PARAMS ((bfd *, bfd *));

    /* Print a line of information about a symbol.  */
    void (*print_symbol_info) PARAMS ((struct extended_symbol_info *, bfd *));
  };

static struct output_fns formats[] =
{
  {print_object_filename_bsd,
   print_archive_filename_bsd,
   print_archive_member_bsd,
   print_symbol_filename_bsd,
   print_symbol_info_bsd},
  {print_object_filename_sysv,
   print_archive_filename_sysv,
   print_archive_member_sysv,
   print_symbol_filename_sysv,
   print_symbol_info_sysv},
  {print_object_filename_posix,
   print_archive_filename_posix,
   print_archive_member_posix,
   print_symbol_filename_posix,
   print_symbol_info_posix}
};

/* Indices in `formats'.  */
#define FORMAT_BSD 0
#define FORMAT_SYSV 1
#define FORMAT_POSIX 2
#define FORMAT_DEFAULT FORMAT_BSD

/* The output format to use.  */
static struct output_fns *format = &formats[FORMAT_DEFAULT];
#ifdef __VOS__
static int format_number = FORMAT_DEFAULT;
#endif

/* Command options.  */

static int do_demangle = 0;	/* Pretty print C++ symbol names.  */
static int external_only = 0;	/* Print external symbols only.  */
static int defined_only = 0;	/* Print defined symbols only.  */
static int no_sort = 0;		/* Don't sort; print syms in order found.  */
static int print_debug_syms = 0;/* Print debugger-only symbols too.  */
static int print_armap = 0;	/* Describe __.SYMDEF data in archive files.  */
static int print_size = 0;	/* Print size of defined symbols.  */
static int reverse_sort = 0;	/* Sort in downward(alpha or numeric) order.  */
static int sort_numerically = 0;/* Sort in numeric rather than alpha order.  */
static int sort_by_size = 0;	/* Sort by size of symbol.  */
static int undefined_only = 0;	/* Print undefined symbols only.  */
static int dynamic = 0;		/* Print dynamic symbols.  */
static int show_version = 0;	/* Show the version number.  */
static int show_stats = 0;	/* Show statistics.  */
static int line_numbers = 0;	/* Print line numbers for symbols.  */

/* When to print the names of files.  Not mutually exclusive in SYSV format.  */
static int filename_per_file = 0;	/* Once per file, on its own line.  */
static int filename_per_symbol = 0;	/* Once per symbol, at start of line.  */

/* Print formats for printing a symbol value.  */
#ifndef BFD64
static char value_format[] = "%08lx";
#else
#if BFD_HOST_64BIT_LONG
static char value_format[] = "%016lx";
#else
/* We don't use value_format for this case.  */
#endif
#endif
#ifdef BFD64
static int print_width = 16;
#else
static int print_width = 8;
#endif
static int print_radix = 16;
/* Print formats for printing stab info.  */
static char other_format[] = "%02x";
static char desc_format[] = "%04x";

static char *target = NULL;

/* Used to cache the line numbers for a BFD.  */
static bfd *lineno_cache_bfd;
static bfd *lineno_cache_rel_bfd;

#define OPTION_TARGET 200

static struct option long_options[] =
{
  {"debug-syms", no_argument, &print_debug_syms, 1},
  {"demangle", optional_argument, 0, 'C'},
  {"dynamic", no_argument, &dynamic, 1},
  {"extern-only", no_argument, &external_only, 1},
  {"format", required_argument, 0, 'f'},
  {"help", no_argument, 0, 'h'},
  {"line-numbers", no_argument, 0, 'l'},
  {"no-cplus", no_argument, &do_demangle, 0},  /* Linux compatibility.  */
  {"no-demangle", no_argument, &do_demangle, 0},
  {"no-sort", no_argument, &no_sort, 1},
  {"numeric-sort", no_argument, &sort_numerically, 1},
  {"portability", no_argument, 0, 'P'},
  {"print-armap", no_argument, &print_armap, 1},
  {"print-file-name", no_argument, 0, 'o'},
  {"print-size", no_argument, 0, 'S'},
  {"radix", required_argument, 0, 't'},
  {"reverse-sort", no_argument, &reverse_sort, 1},
  {"size-sort", no_argument, &sort_by_size, 1},
  {"stats", no_argument, &show_stats, 1},
  {"target", required_argument, 0, OPTION_TARGET},
  {"defined-only", no_argument, &defined_only, 1},
  {"undefined-only", no_argument, &undefined_only, 1},
  {"version", no_argument, &show_version, 1},
  {0, no_argument, 0, 0}
};

#ifdef __VOS__

#define $shortmap
#pragma pack(push,2)
#include "object_constants.h"
#include "program_module.h"
#pragma pack(pop)
#undef $shortmap

static bfd_boolean is_vos_pm (bfd *, char **);
static bfd_boolean vos_check_options (void);
static void vos_compile_maps (program_module *);
static bfd_boolean vos_display_pm (bfd *, char *, char *);
static void *vos_load_map (FILE *, long, long);
static void vos_minimax_map_addr (long, long);
static void vos_print_symbol_info (char *, char_varying *, int, size_t,
              size_t);
static void vos_print_symbol_info_bsd (char_varying *, int, size_t,
              size_t);
static void vos_print_symbol_info_posix (char_varying *, int, size_t,
              size_t);
static void vos_print_value (size_t);
static char_varying *vos_string_pool_name (int);
static char_varying *vos_symbol_name (char_varying *);
#endif /* __VOS__ */

/* Some error-reporting functions.  */

static void
usage (stream, status)
     FILE *stream;
     int status;
{
  fprintf (stream, _("Usage: %s [option(s)] [file(s)]\n"), program_name);
  fprintf (stream, _(" List symbols in [file(s)] (a.out by default).\n"));
  fprintf (stream, _(" The options are:\n\
  -a, --debug-syms       Display debugger-only symbols\n\
  -A, --print-file-name  Print name of the input file before every symbol\n\
  -B                     Same as --format=bsd\n\
  -C, --demangle[=STYLE] Decode low-level symbol names into user-level names\n\
                          The STYLE, if specified, can be `auto' (the default),\n\
                          `gnu', `lucid', `arm', `hp', `edg', `gnu-v3', `java'\n\
                          or `gnat'\n\
      --no-demangle      Do not demangle low-level symbol names\n\
  -D, --dynamic          Display dynamic symbols instead of normal symbols\n\
      --defined-only     Display only defined symbols\n\
  -e                     (ignored)\n\
  -f, --format=FORMAT    Use the output format FORMAT.  FORMAT can be `bsd',\n\
                           `sysv' or `posix'.  The default is `bsd'\n\
  -g, --extern-only      Display only external symbols\n\
  -l, --line-numbers     Use debugging information to find a filename and\n\
                           line number for each symbol\n\
  -n, --numeric-sort     Sort symbols numerically by address\n\
  -o                     Same as -A\n\
  -p, --no-sort          Do not sort the symbols\n\
  -P, --portability      Same as --format=posix\n\
  -r, --reverse-sort     Reverse the sense of the sort\n\
  -S, --print-size       Print size of defined symbols\n\
  -s, --print-armap      Include index for symbols from archive members\n\
      --size-sort        Sort symbols by size\n\
  -t, --radix=RADIX      Use RADIX for printing symbol values\n\
      --target=BFDNAME   Specify the target object format as BFDNAME\n\
  -u, --undefined-only   Display only undefined symbols\n\
  -X 32_64               (ignored)\n\
  -h, --help             Display this information\n\
  -V, --version          Display this program's version number\n\
\n"));
  list_supported_targets (program_name, stream);
  if (status == 0)
    fprintf (stream, _("Report bugs to %s.\n"), REPORT_BUGS_TO);
  exit (status);
}

/* Set the radix for the symbol value and size according to RADIX.  */

static void
set_print_radix (radix)
     char *radix;
{
  switch (*radix)
    {
    case 'x':
      break;
    case 'd':
    case 'o':
      if (*radix == 'd')
	print_radix = 10;
      else
	print_radix = 8;
#ifndef BFD64
      value_format[4] = *radix;
#else
#if BFD_HOST_64BIT_LONG
      value_format[5] = *radix;
#else
      /* This case requires special handling for octal and decimal
         printing.  */
#endif
#endif
      other_format[3] = desc_format[3] = *radix;
      break;
    default:
      fatal (_("%s: invalid radix"), radix);
    }
}

static void
set_output_format (f)
     char *f;
{
  int i;

  switch (*f)
    {
    case 'b':
    case 'B':
      i = FORMAT_BSD;
      break;
    case 'p':
    case 'P':
      i = FORMAT_POSIX;
      break;
    case 's':
    case 'S':
      i = FORMAT_SYSV;
      break;
    default:
      fatal (_("%s: invalid output format"), f);
    }
  format = &formats[i];
#ifdef __VOS__
  format_number = i;
#endif /* __VOS__ */
}

int main PARAMS ((int, char **));

int
main (argc, argv)
     int argc;
     char **argv;
{
  int c;
  int retval;

#if defined (HAVE_SETLOCALE) && defined (HAVE_LC_MESSAGES)
  setlocale (LC_MESSAGES, "");
#endif
#if defined (HAVE_SETLOCALE)
  setlocale (LC_CTYPE, "");
  setlocale (LC_COLLATE, "");
#endif
  bindtextdomain (PACKAGE, LOCALEDIR);
  textdomain (PACKAGE);

  program_name = *argv;
  xmalloc_set_program_name (program_name);

  START_PROGRESS (program_name, 0);

  bfd_init ();
  set_default_bfd_target ();

  while ((c = getopt_long (argc, argv, "aABCDef:gHhlnopPrSst:uvVvX:",
			   long_options, (int *) 0)) != EOF)
    {
      switch (c)
	{
	case 'a':
	  print_debug_syms = 1;
	  break;
	case 'A':
	case 'o':
	  filename_per_symbol = 1;
	  break;
	case 'B':		/* For MIPS compatibility.  */
	  set_output_format ("bsd");
	  break;
	case 'C':
	  do_demangle = 1;
	  if (optarg != NULL)
	    {
	      enum demangling_styles style;

	      style = cplus_demangle_name_to_style (optarg);
	      if (style == unknown_demangling)
		fatal (_("unknown demangling style `%s'"),
		       optarg);

	      cplus_demangle_set_style (style);
	    }
	  break;
	case 'D':
	  dynamic = 1;
	  break;
	case 'e':
	  /* Ignored for HP/UX compatibility.  */
	  break;
	case 'f':
	  set_output_format (optarg);
	  break;
	case 'g':
	  external_only = 1;
	  break;
	case 'H':
	case 'h':
	  usage (stdout, 0);
	case 'l':
	  line_numbers = 1;
	  break;
	case 'n':
	case 'v':
	  sort_numerically = 1;
	  break;
	case 'p':
	  no_sort = 1;
	  break;
	case 'P':
	  set_output_format ("posix");
	  break;
	case 'r':
	  reverse_sort = 1;
	  break;
	case 's':
	  print_armap = 1;
	  break;
	case 'S':
	  print_size = 1;
	  break;
	case 't':
	  set_print_radix (optarg);
	  break;
	case 'u':
	  undefined_only = 1;
	  break;
	case 'V':
	  show_version = 1;
	  break;
	case 'X':
	  /* Ignored for (partial) AIX compatibility.  On AIX, the
	     argument has values 32, 64, or 32_64, and specfies that
	     only 32-bit, only 64-bit, or both kinds of objects should
	     be examined.  The default is 32.  So plain AIX nm on a
	     library archive with both kinds of objects will ignore
	     the 64-bit ones.  For GNU nm, the default is and always
	     has been -X 32_64, and other options are not supported.  */
	  if (strcmp (optarg, "32_64") != 0)
	    fatal (_("Only -X 32_64 is supported"));
	  break;

	case OPTION_TARGET:	/* --target */
#ifdef __VOS__
       /* Ignore vos pseudo-targets */
       if ((strcmp (optarg, "vos-pm") != 0) &&
           (strcmp (optarg, "vos-so") != 0))
#endif
	  target = optarg;
	  break;

	case 0:		/* A long option that just sets a flag.  */
	  break;

	default:
	  usage (stderr, 1);
	}
    }

  if (show_version)
    print_version ("nm");

  if (sort_by_size && undefined_only)
    {
      non_fatal (_("Using the --size-sort and --undefined-only options together"));
      non_fatal (_("will produce no output, since undefined symbols have no size."));
      return 0;
    }

  /* OK, all options now parsed.  If no filename specified, do a.out.  */
  if (optind == argc)
    return !display_file ("a.out");

  retval = 0;

  if (argc - optind > 1)
    filename_per_file = 1;

  /* We were given several filenames to do.  */
  while (optind < argc)
    {
      PROGRESS (1);
      if (!display_file (argv[optind++]))
	retval++;
    }

  END_PROGRESS (program_name);

#ifdef HAVE_SBRK
  if (show_stats)
    {
      char *lim = (char *) sbrk (0);

      non_fatal (_("data size %ld"), (long) (lim - (char *) &environ));
    }
#endif

  exit (retval);
  return retval;
}

static const char *
get_symbol_type (type)
     unsigned int type;
{
  static char buff [32];

  switch (type)
    {
    case STT_NOTYPE:   return "NOTYPE";
    case STT_OBJECT:   return "OBJECT";
    case STT_FUNC:     return "FUNC";
    case STT_SECTION:  return "SECTION";
    case STT_FILE:     return "FILE";
    case STT_COMMON:   return "COMMON";
    case STT_TLS:      return "TLS";
    default:
      if (type >= STT_LOPROC && type <= STT_HIPROC)
	sprintf (buff, _("<processor specific>: %d"), type);
      else if (type >= STT_LOOS && type <= STT_HIOS)
	sprintf (buff, _("<OS specific>: %d"), type);
      else
	sprintf (buff, _("<unknown>: %d"), type);
      return buff;
    }
}

static void
display_archive (file)
     bfd *file;
{
  bfd *arfile = NULL;
  bfd *last_arfile = NULL;
  char **matching;

  (*format->print_archive_filename) (bfd_get_filename (file));

  if (print_armap)
    print_symdef_entry (file);

  for (;;)
    {
      PROGRESS (1);

      arfile = bfd_openr_next_archived_file (file, arfile);

      if (arfile == NULL)
	{
	  if (bfd_get_error () != bfd_error_no_more_archived_files)
	    bfd_fatal (bfd_get_filename (file));
	  break;
	}

      if (bfd_check_format_matches (arfile, bfd_object, &matching))
	{
	  char buf[30];

	  bfd_sprintf_vma (arfile, buf, (bfd_vma) -1);
	  print_width = strlen (buf);
	  (*format->print_archive_member) (bfd_get_filename (file),
					   bfd_get_filename (arfile));
	  display_rel_file (arfile, file);
	}
      else
	{
	  bfd_nonfatal (bfd_get_filename (arfile));
	  if (bfd_get_error () == bfd_error_file_ambiguously_recognized)
	    {
	      list_matching_formats (matching);
	      free (matching);
	    }
	}

      if (last_arfile != NULL)
	{
	  bfd_close (last_arfile);
	  lineno_cache_bfd = NULL;
	  lineno_cache_rel_bfd = NULL;
	}
      last_arfile = arfile;
    }

  if (last_arfile != NULL)
    {
      bfd_close (last_arfile);
      lineno_cache_bfd = NULL;
      lineno_cache_rel_bfd = NULL;
    }
}

static bfd_boolean
display_file (filename)
     char *filename;
{
  bfd_boolean retval = TRUE;
  bfd *file;
  char **matching;

  file = bfd_openr (filename, target);
  if (file == NULL)
    {
      bfd_nonfatal (filename);
      return FALSE;
    }

  if (bfd_check_format (file, bfd_archive))
    {
      display_archive (file);
    }
  else if (bfd_check_format_matches (file, bfd_object, &matching))
    {
      char buf[30];

      bfd_sprintf_vma (file, buf, (bfd_vma) -1);
      print_width = strlen (buf);
      (*format->print_object_filename) (filename);
      display_rel_file (file, NULL);
    }
  else
    {
#ifdef __VOS__
      char *buffer_ptr;

      if (is_vos_pm (file, &buffer_ptr))
        {
          if (vos_check_options ())
            bfd_fatal (filename);

          vos_display_pm (file, buffer_ptr, filename);
          goto CLOSE;
        }
#endif /* __VOS__ */

      bfd_nonfatal (filename);
      if (bfd_get_error () == bfd_error_file_ambiguously_recognized)
	{
	  list_matching_formats (matching);
	  free (matching);
	}
      retval = FALSE;
    }

#ifdef __VOS__
CLOSE:
#endif /* __VOS__ */

  if (!bfd_close (file))
    bfd_fatal (filename);

  lineno_cache_bfd = NULL;
  lineno_cache_rel_bfd = NULL;

  return retval;
}

/* These globals are used to pass information into the sorting
   routines.  */
static bfd *sort_bfd;
static bfd_boolean sort_dynamic;
static asymbol *sort_x;
static asymbol *sort_y;

/* Symbol-sorting predicates */
#define valueof(x) ((x)->section->vma + (x)->value)

/* Numeric sorts.  Undefined symbols are always considered "less than"
   defined symbols with zero values.  Common symbols are not treated
   specially -- i.e., their sizes are used as their "values".  */

static int
numeric_forward (P_x, P_y)
     const PTR P_x;
     const PTR P_y;
{
  asymbol *x, *y;
  asection *xs, *ys;

  x = bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_x, sort_x);
  y =  bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_y, sort_y);
  if (x == NULL || y == NULL)
    bfd_fatal (bfd_get_filename (sort_bfd));

  xs = bfd_get_section (x);
  ys = bfd_get_section (y);

  if (bfd_is_und_section (xs))
    {
      if (! bfd_is_und_section (ys))
	return -1;
    }
  else if (bfd_is_und_section (ys))
    return 1;
  else if (valueof (x) != valueof (y))
    return valueof (x) < valueof (y) ? -1 : 1;

  return non_numeric_forward (P_x, P_y);
}

static int
numeric_reverse (x, y)
     const PTR x;
     const PTR y;
{
  return - numeric_forward (x, y);
}

static int
non_numeric_forward (P_x, P_y)
     const PTR P_x;
     const PTR P_y;
{
  asymbol *x, *y;
  const char *xn, *yn;

  x = bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_x, sort_x);
  y = bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_y, sort_y);
  if (x == NULL || y == NULL)
    bfd_fatal (bfd_get_filename (sort_bfd));

  xn = bfd_asymbol_name (x);
  yn = bfd_asymbol_name (y);

  if (yn == NULL)
    return xn != NULL;
  if (xn == NULL)
    return -1;

#ifdef HAVE_STRCOLL
  /* Solaris 2.5 has a bug in strcoll.
     strcoll returns invalid values when confronted with empty strings.  */
  if (*yn == '\0')
    return *xn != '\0';
  if (*xn == '\0')
    return -1;

  return strcoll (xn, yn);
#else
  return strcmp (xn, yn);
#endif
}

static int
non_numeric_reverse (x, y)
     const PTR x;
     const PTR y;
{
  return - non_numeric_forward (x, y);
}

static int (*(sorters[2][2])) PARAMS ((const PTR, const PTR)) =
{
  { non_numeric_forward, non_numeric_reverse },
  { numeric_forward, numeric_reverse }
};

/* This sort routine is used by sort_symbols_by_size.  It is similar
   to numeric_forward, but when symbols have the same value it sorts
   by section VMA.  This simplifies the sort_symbols_by_size code
   which handles symbols at the end of sections.  Also, this routine
   tries to sort file names before other symbols with the same value.
   That will make the file name have a zero size, which will make
   sort_symbols_by_size choose the non file name symbol, leading to
   more meaningful output.  For similar reasons, this code sorts
   gnu_compiled_* and gcc2_compiled before other symbols with the same
   value.  */

static int
size_forward1 (P_x, P_y)
     const PTR P_x;
     const PTR P_y;
{
  asymbol *x, *y;
  asection *xs, *ys;
  const char *xn, *yn;
  size_t xnl, ynl;
  int xf, yf;

  x = bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_x, sort_x);
  y = bfd_minisymbol_to_symbol (sort_bfd, sort_dynamic, P_y, sort_y);
  if (x == NULL || y == NULL)
    bfd_fatal (bfd_get_filename (sort_bfd));

  xs = bfd_get_section (x);
  ys = bfd_get_section (y);

  if (bfd_is_und_section (xs))
    abort ();
  if (bfd_is_und_section (ys))
    abort ();

  if (valueof (x) != valueof (y))
    return valueof (x) < valueof (y) ? -1 : 1;

  if (xs->vma != ys->vma)
    return xs->vma < ys->vma ? -1 : 1;

  xn = bfd_asymbol_name (x);
  yn = bfd_asymbol_name (y);
  xnl = strlen (xn);
  ynl = strlen (yn);

  /* The symbols gnu_compiled and gcc2_compiled convey even less
     information than the file name, so sort them out first.  */

  xf = (strstr (xn, "gnu_compiled") != NULL
	|| strstr (xn, "gcc2_compiled") != NULL);
  yf = (strstr (yn, "gnu_compiled") != NULL
	|| strstr (yn, "gcc2_compiled") != NULL);

  if (xf && ! yf)
    return -1;
  if (! xf && yf)
    return 1;

  /* We use a heuristic for the file name.  It may not work on non
     Unix systems, but it doesn't really matter; the only difference
     is precisely which symbol names get printed.  */

#define file_symbol(s, sn, snl)			\
  (((s)->flags & BSF_FILE) != 0			\
   || ((sn)[(snl) - 2] == '.'			\
       && ((sn)[(snl) - 1] == 'o'		\
	   || (sn)[(snl) - 1] == 'a')))

  xf = file_symbol (x, xn, xnl);
  yf = file_symbol (y, yn, ynl);

  if (xf && ! yf)
    return -1;
  if (! xf && yf)
    return 1;

  return non_numeric_forward (P_x, P_y);
}

/* This sort routine is used by sort_symbols_by_size.  It is sorting
   an array of size_sym structures into size order.  */

static int
size_forward2 (P_x, P_y)
     const PTR P_x;
     const PTR P_y;
{
  const struct size_sym *x = (const struct size_sym *) P_x;
  const struct size_sym *y = (const struct size_sym *) P_y;

  if (x->size < y->size)
    return reverse_sort ? 1 : -1;
  else if (x->size > y->size)
    return reverse_sort ? -1 : 1;
  else
    return sorters[0][reverse_sort] (x->minisym, y->minisym);
}

/* Sort the symbols by size.  ELF provides a size but for other formats
   we have to make a guess by assuming that the difference between the
   address of a symbol and the address of the next higher symbol is the
   size.  */

static long
sort_symbols_by_size (abfd, dynamic, minisyms, symcount, size, symsizesp)
     bfd *abfd;
     bfd_boolean dynamic;
     PTR minisyms;
     long symcount;
     unsigned int size;
     struct size_sym **symsizesp;
{
  struct size_sym *symsizes;
  bfd_byte *from, *fromend;
  asymbol *sym = NULL;
  asymbol *store_sym, *store_next;

  qsort (minisyms, symcount, size, size_forward1);

  /* We are going to return a special set of symbols and sizes to
     print.  */
  symsizes = (struct size_sym *) xmalloc (symcount * sizeof (struct size_sym));
  *symsizesp = symsizes;

  /* Note that filter_symbols has already removed all absolute and
     undefined symbols.  Here we remove all symbols whose size winds
     up as zero.  */
  from = (bfd_byte *) minisyms;
  fromend = from + symcount * size;

  store_sym = sort_x;
  store_next = sort_y;

  if (from < fromend)
    {
      sym = bfd_minisymbol_to_symbol (abfd, dynamic, (const PTR) from,
				      store_sym);
      if (sym == NULL)
	bfd_fatal (bfd_get_filename (abfd));
    }

  for (; from < fromend; from += size)
    {
      asymbol *next;
      asection *sec;
      bfd_vma sz;
      asymbol *temp;

      if (from + size < fromend)
	{
	  next = bfd_minisymbol_to_symbol (abfd,
					   dynamic,
					   (const PTR) (from + size),
					   store_next);
	  if (next == NULL)
	    bfd_fatal (bfd_get_filename (abfd));
	}
      else
	next = NULL;

      sec = bfd_get_section (sym);

      if (bfd_get_flavour (abfd) == bfd_target_elf_flavour)
	sz = ((elf_symbol_type *) sym)->internal_elf_sym.st_size;
      else if (bfd_is_com_section (sec))
	sz = sym->value;
      else
	{
	  if (from + size < fromend
	      && sec == bfd_get_section (next))
	    sz = valueof (next) - valueof (sym);
	  else
	    sz = (bfd_get_section_vma (abfd, sec)
		  + bfd_section_size (abfd, sec)
		  - valueof (sym));
	}

      if (sz != 0)
	{
	  symsizes->minisym = (const PTR) from;
	  symsizes->size = sz;
	  ++symsizes;
	}

      sym = next;

      temp = store_sym;
      store_sym = store_next;
      store_next = temp;
    }

  symcount = symsizes - *symsizesp;

  /* We must now sort again by size.  */
  qsort ((PTR) *symsizesp, symcount, sizeof (struct size_sym), size_forward2);

  return symcount;
}

/* If ARCHIVE_BFD is non-NULL, it is the archive containing ABFD.  */

static void
display_rel_file (abfd, archive_bfd)
     bfd *abfd;
     bfd *archive_bfd;
{
  long symcount;
  PTR minisyms;
  unsigned int size;
  struct size_sym *symsizes;

  if (! dynamic)
    {
      if (!(bfd_get_file_flags (abfd) & HAS_SYMS))
	{
	  non_fatal (_("%s: no symbols"), bfd_get_filename (abfd));
	  return;
	}
    }

  symcount = bfd_read_minisymbols (abfd, dynamic, &minisyms, &size);
  if (symcount < 0)
    bfd_fatal (bfd_get_filename (abfd));

  if (symcount == 0)
    {
      non_fatal (_("%s: no symbols"), bfd_get_filename (abfd));
      return;
    }

  /* Discard the symbols we don't want to print.
     It's OK to do this in place; we'll free the storage anyway
     (after printing).  */

  symcount = filter_symbols (abfd, dynamic, minisyms, symcount, size);

  symsizes = NULL;
  if (! no_sort)
    {
      sort_bfd = abfd;
      sort_dynamic = dynamic;
      sort_x = bfd_make_empty_symbol (abfd);
      sort_y = bfd_make_empty_symbol (abfd);
      if (sort_x == NULL || sort_y == NULL)
	bfd_fatal (bfd_get_filename (abfd));

      if (! sort_by_size)
	qsort (minisyms, symcount, size,
	       sorters[sort_numerically][reverse_sort]);
      else
	symcount = sort_symbols_by_size (abfd, dynamic, minisyms, symcount,
					 size, &symsizes);
    }

  if (! sort_by_size)
    print_symbols (abfd, dynamic, minisyms, symcount, size, archive_bfd);
  else
    print_size_symbols (abfd, dynamic, symsizes, symcount, archive_bfd);

  free (minisyms);
}

/* Choose which symbol entries to print;
   compact them downward to get rid of the rest.
   Return the number of symbols to be printed.  */

static long
filter_symbols (abfd, dynamic, minisyms, symcount, size)
     bfd *abfd;
     bfd_boolean dynamic;
     PTR minisyms;
     long symcount;
     unsigned int size;
{
  bfd_byte *from, *fromend, *to;
  asymbol *store;

  store = bfd_make_empty_symbol (abfd);
  if (store == NULL)
    bfd_fatal (bfd_get_filename (abfd));

  from = (bfd_byte *) minisyms;
  fromend = from + symcount * size;
  to = (bfd_byte *) minisyms;

  for (; from < fromend; from += size)
    {
      int keep = 0;
      asymbol *sym;

      PROGRESS (1);

      sym = bfd_minisymbol_to_symbol (abfd, dynamic, (const PTR) from, store);
      if (sym == NULL)
	bfd_fatal (bfd_get_filename (abfd));

      if (undefined_only)
	keep = bfd_is_und_section (sym->section);
      else if (external_only)
	keep = ((sym->flags & BSF_GLOBAL) != 0
		|| (sym->flags & BSF_WEAK) != 0
		|| bfd_is_und_section (sym->section)
		|| bfd_is_com_section (sym->section));
      else
	keep = 1;

      if (keep
	  && ! print_debug_syms
	  && (sym->flags & BSF_DEBUGGING) != 0)
	keep = 0;

      if (keep
	  && sort_by_size
	  && (bfd_is_abs_section (sym->section)
	      || bfd_is_und_section (sym->section)))
	keep = 0;

      if (keep
	  && defined_only)
	{
	  if (bfd_is_und_section (sym->section))
	    keep = 0;
	}

      if (keep)
	{
	  memcpy (to, from, size);
	  to += size;
	}
    }

  return (to - (bfd_byte *) minisyms) / size;
}

/* Print symbol name NAME, read from ABFD, with printf format FORMAT,
   demangling it if requested.  */

static void
print_symname (format, name, abfd)
     const char *format;
     const char *name;
     bfd *abfd;
{
  if (do_demangle && *name)
    {
      char *res = demangle (abfd, name);

      printf (format, res);
      free (res);
      return;
    }

  printf (format, name);
}

/* Print the symbols.  If ARCHIVE_BFD is non-NULL, it is the archive
   containing ABFD.  */

static void
print_symbols (abfd, dynamic, minisyms, symcount, size, archive_bfd)
     bfd *abfd;
     bfd_boolean dynamic;
     PTR minisyms;
     long symcount;
     unsigned int size;
     bfd *archive_bfd;
{
  asymbol *store;
  bfd_byte *from, *fromend;

  store = bfd_make_empty_symbol (abfd);
  if (store == NULL)
    bfd_fatal (bfd_get_filename (abfd));

  from = (bfd_byte *) minisyms;
  fromend = from + symcount * size;
  for (; from < fromend; from += size)
    {
      asymbol *sym;

      sym = bfd_minisymbol_to_symbol (abfd, dynamic, from, store);
      if (sym == NULL)
	bfd_fatal (bfd_get_filename (abfd));

      print_symbol (abfd, sym, (bfd_vma) 0, archive_bfd);
    }
}

/* Print the symbols when sorting by size.  */

static void
print_size_symbols (abfd, dynamic, symsizes, symcount, archive_bfd)
     bfd *abfd;
     bfd_boolean dynamic;
     struct size_sym *symsizes;
     long symcount;
     bfd *archive_bfd;
{
  asymbol *store;
  struct size_sym *from, *fromend;

  store = bfd_make_empty_symbol (abfd);
  if (store == NULL)
    bfd_fatal (bfd_get_filename (abfd));

  from = symsizes;
  fromend = from + symcount;
  for (; from < fromend; from++)
    {
      asymbol *sym;
      bfd_vma ssize;

      sym = bfd_minisymbol_to_symbol (abfd, dynamic, from->minisym, store);
      if (sym == NULL)
	bfd_fatal (bfd_get_filename (abfd));

      /* For elf we have already computed the correct symbol size.  */
      if (bfd_get_flavour (abfd) == bfd_target_elf_flavour)
	ssize = from->size;
      else
	ssize = from->size - bfd_section_vma (abfd, bfd_get_section (sym));

      print_symbol (abfd, sym, ssize, archive_bfd);
    }
}

/* Print a single symbol.  */

static void
print_symbol (abfd, sym, ssize, archive_bfd)
     bfd *abfd;
     asymbol *sym;
     bfd_vma ssize;
     bfd *archive_bfd;
{
  symbol_info syminfo;
  struct extended_symbol_info info;
   
  PROGRESS (1);

  (*format->print_symbol_filename) (archive_bfd, abfd);

  bfd_get_symbol_info (abfd, sym, &syminfo);
  info.sinfo = &syminfo;
  info.ssize = ssize;
  if (bfd_get_flavour (abfd) == bfd_target_elf_flavour)
    info.elfinfo = (elf_symbol_type *) sym;
  else
    info.elfinfo = NULL;
  (*format->print_symbol_info) (&info, abfd);

  if (line_numbers)
    {
      static asymbol **syms;
      static long symcount;
      const char *filename, *functionname;
      unsigned int lineno;

      /* We need to get the canonical symbols in order to call
         bfd_find_nearest_line.  This is inefficient, but, then, you
         don't have to use --line-numbers.  */
      if (abfd != lineno_cache_bfd && syms != NULL)
	{
	  free (syms);
	  syms = NULL;
	}
      if (syms == NULL)
	{
	  long symsize;

	  symsize = bfd_get_symtab_upper_bound (abfd);
	  if (symsize < 0)
	    bfd_fatal (bfd_get_filename (abfd));
	  syms = (asymbol **) xmalloc (symsize);
	  symcount = bfd_canonicalize_symtab (abfd, syms);
	  if (symcount < 0)
	    bfd_fatal (bfd_get_filename (abfd));
	  lineno_cache_bfd = abfd;
	}

      if (bfd_is_und_section (bfd_get_section (sym)))
	{
	  static asection **secs;
	  static arelent ***relocs;
	  static long *relcount;
	  static unsigned int seccount;
	  unsigned int i;
	  const char *symname;

	  /* For an undefined symbol, we try to find a reloc for the
             symbol, and print the line number of the reloc.  */
	  if (abfd != lineno_cache_rel_bfd && relocs != NULL)
	    {
	      for (i = 0; i < seccount; i++)
		if (relocs[i] != NULL)
		  free (relocs[i]);
	      free (secs);
	      free (relocs);
	      free (relcount);
	      secs = NULL;
	      relocs = NULL;
	      relcount = NULL;
	    }

	  if (relocs == NULL)
	    {
	      struct get_relocs_info info;

	      seccount = bfd_count_sections (abfd);

	      secs = (asection **) xmalloc (seccount * sizeof *secs);
	      relocs = (arelent ***) xmalloc (seccount * sizeof *relocs);
	      relcount = (long *) xmalloc (seccount * sizeof *relcount);

	      info.secs = secs;
	      info.relocs = relocs;
	      info.relcount = relcount;
	      info.syms = syms;
	      bfd_map_over_sections (abfd, get_relocs, (PTR) &info);
	      lineno_cache_rel_bfd = abfd;
	    }

	  symname = bfd_asymbol_name (sym);
	  for (i = 0; i < seccount; i++)
	    {
	      long j;

	      for (j = 0; j < relcount[i]; j++)
		{
		  arelent *r;

		  r = relocs[i][j];
		  if (r->sym_ptr_ptr != NULL
		      && (*r->sym_ptr_ptr)->section == sym->section
		      && (*r->sym_ptr_ptr)->value == sym->value
		      && strcmp (symname,
				 bfd_asymbol_name (*r->sym_ptr_ptr)) == 0
		      && bfd_find_nearest_line (abfd, secs[i], syms,
						r->address, &filename,
						&functionname, &lineno)
		      && filename != NULL)
		    {
		      /* We only print the first one we find.  */
		      printf ("\t%s:%u", filename, lineno);
		      i = seccount;
		      break;
		    }
		}
	    }
	}
      else if (bfd_get_section (sym)->owner == abfd)
	{
	  if (bfd_find_nearest_line (abfd, bfd_get_section (sym), syms,
				     sym->value, &filename, &functionname,
				     &lineno)
	      && filename != NULL
	      && lineno != 0)
	    {
	      printf ("\t%s:%u", filename, lineno);
	    }
	}
    }

  putchar ('\n');
}

/* The following 3 groups of functions are called unconditionally,
   once at the start of processing each file of the appropriate type.
   They should check `filename_per_file' and `filename_per_symbol',
   as appropriate for their output format, to determine whether to
   print anything.  */

/* Print the name of an object file given on the command line.  */

static void
print_object_filename_bsd (filename)
     char *filename;
{
  if (filename_per_file && !filename_per_symbol)
    printf ("\n%s:\n", filename);
}

static void
print_object_filename_sysv (filename)
     char *filename;
{
  if (undefined_only)
    printf (_("\n\nUndefined symbols from %s:\n\n"), filename);
  else
    printf (_("\n\nSymbols from %s:\n\n"), filename);
  if (print_width == 8)
    printf (_("\
Name                  Value   Class        Type         Size     Line  Section\n\n"));
  else
    printf (_("\
Name                  Value           Class        Type         Size             Line  Section\n\n"));
}

static void
print_object_filename_posix (filename)
     char *filename;
{
  if (filename_per_file && !filename_per_symbol)
    printf ("%s:\n", filename);
}

/* Print the name of an archive file given on the command line.  */

static void
print_archive_filename_bsd (filename)
     char *filename;
{
  if (filename_per_file)
    printf ("\n%s:\n", filename);
}

static void
print_archive_filename_sysv (filename)
     char *filename ATTRIBUTE_UNUSED;
{
}

static void
print_archive_filename_posix (filename)
     char *filename ATTRIBUTE_UNUSED;
{
}

/* Print the name of an archive member file.  */

static void
print_archive_member_bsd (archive, filename)
     char *archive ATTRIBUTE_UNUSED;
     const char *filename;
{
  if (!filename_per_symbol)
    printf ("\n%s:\n", filename);
}

static void
print_archive_member_sysv (archive, filename)
     char *archive;
     const char *filename;
{
  if (undefined_only)
    printf (_("\n\nUndefined symbols from %s[%s]:\n\n"), archive, filename);
  else
    printf (_("\n\nSymbols from %s[%s]:\n\n"), archive, filename);
  if (print_width == 8)
    printf (_("\
Name                  Value   Class        Type         Size     Line  Section\n\n"));
  else
    printf (_("\
Name                  Value           Class        Type         Size             Line  Section\n\n"));
}

static void
print_archive_member_posix (archive, filename)
     char *archive;
     const char *filename;
{
  if (!filename_per_symbol)
    printf ("%s[%s]:\n", archive, filename);
}

/* Print the name of the file (and archive, if there is one)
   containing a symbol.  */

static void
print_symbol_filename_bsd (archive_bfd, abfd)
     bfd *archive_bfd, *abfd;
{
  if (filename_per_symbol)
    {
      if (archive_bfd)
	printf ("%s:", bfd_get_filename (archive_bfd));
      printf ("%s:", bfd_get_filename (abfd));
    }
}

static void
print_symbol_filename_sysv (archive_bfd, abfd)
     bfd *archive_bfd, *abfd;
{
  if (filename_per_symbol)
    {
      if (archive_bfd)
	printf ("%s:", bfd_get_filename (archive_bfd));
      printf ("%s:", bfd_get_filename (abfd));
    }
}

static void
print_symbol_filename_posix (archive_bfd, abfd)
     bfd *archive_bfd, *abfd;
{
  if (filename_per_symbol)
    {
      if (archive_bfd)
	printf ("%s[%s]: ", bfd_get_filename (archive_bfd),
		bfd_get_filename (abfd));
      else
	printf ("%s: ", bfd_get_filename (abfd));
    }
}

/* Print a symbol value.  */

static void
print_value (abfd, val)
     bfd *abfd ATTRIBUTE_UNUSED;
     bfd_vma val;
{
#if ! defined (BFD64) || BFD_HOST_64BIT_LONG
  printf (value_format, val);
#else
  /* We have a 64 bit value to print, but the host is only 32 bit.  */
  if (print_radix == 16)
    bfd_fprintf_vma (abfd, stdout, val);
  else
    {
      char buf[30];
      char *s;

      s = buf + sizeof buf;
      *--s = '\0';
      while (val > 0)
	{
	  *--s = (val % print_radix) + '0';
	  val /= print_radix;
	}
      while ((buf + sizeof buf - 1) - s < 16)
	*--s = '0';
      printf ("%s", s);
    }
#endif
}

/* Print a line of information about a symbol.  */

static void
print_symbol_info_bsd (info, abfd)
     struct extended_symbol_info *info;
     bfd *abfd;
{
  if (bfd_is_undefined_symclass (SYM_TYPE (info)))
    {
      if (print_width == 16)
	printf ("        ");
      printf ("        ");
    }
  else
    {
      /* Normally we print the value of the symbol.  If we are printing the
	 size or sorting by size then we print its size, execpt for the
	 (weird) special case where both flags are defined, in which case we
	 print both values.  This conforms to documented behaviour.  */
      if (sort_by_size && !print_size)
	print_value (abfd, SYM_SIZE (info));
      else
	print_value (abfd, SYM_VALUE (info));

      if (print_size && SYM_SIZE (info))
	{
	  printf (" ");
	  print_value (abfd, SYM_SIZE (info));
	}
    }

  printf (" %c", SYM_TYPE (info));

  if (SYM_TYPE (info) == '-')
    {
      /* A stab.  */
      printf (" ");
      printf (other_format, SYM_STAB_OTHER (info));
      printf (" ");
      printf (desc_format, SYM_STAB_DESC (info));
      printf (" %5s", SYM_STAB_NAME (info));
    }
  print_symname (" %s", SYM_NAME (info), abfd);
}

static void
print_symbol_info_sysv (info, abfd)
     struct extended_symbol_info *info;
     bfd *abfd;
{
  print_symname ("%-20s|", SYM_NAME (info), abfd);

  if (bfd_is_undefined_symclass (SYM_TYPE (info)))
    {
      if (print_width == 8)
	printf ("        ");
      else
	printf ("                ");
    }
  else
    print_value (abfd, SYM_VALUE (info));

  printf ("|   %c  |", SYM_TYPE (info));

  if (SYM_TYPE (info) == '-')
    {
      /* A stab.  */
      printf ("%18s|  ", SYM_STAB_NAME (info));		/* (C) Type.  */
      printf (desc_format, SYM_STAB_DESC (info));	/* Size.  */
      printf ("|     |");				/* Line, Section.  */
    }
  else
    {
      /* Type, Size, Line, Section */
      if (info->elfinfo)
	printf ("%18s|",
		get_symbol_type (ELF_ST_TYPE (info->elfinfo->internal_elf_sym.st_info)));
      else
	printf ("                  |");

      if (SYM_SIZE (info))
	print_value (abfd, SYM_SIZE (info));
      else
	{
	  if (print_width == 8)
	    printf ("        ");
	  else
	    printf ("                ");
	}

      if (info->elfinfo)
	printf("|     |%s", info->elfinfo->symbol.section->name);
      else
	printf("|     |");
    }
}

static void
print_symbol_info_posix (info, abfd)
     struct extended_symbol_info *info;
     bfd *abfd;
{
  print_symname ("%s ", SYM_NAME (info), abfd);
  printf ("%c ", SYM_TYPE (info));

  if (bfd_is_undefined_symclass (SYM_TYPE (info)))
    printf ("        ");
  else
    {
      print_value (abfd, SYM_VALUE (info));
      printf (" ");
      if (SYM_SIZE (info))
	print_value (abfd, SYM_SIZE (info));
    }
}

static void
print_symdef_entry (abfd)
     bfd *abfd;
{
  symindex idx = BFD_NO_MORE_SYMBOLS;
  carsym *thesym;
  bfd_boolean everprinted = FALSE;

  for (idx = bfd_get_next_mapent (abfd, idx, &thesym);
       idx != BFD_NO_MORE_SYMBOLS;
       idx = bfd_get_next_mapent (abfd, idx, &thesym))
    {
      bfd *elt;
      if (!everprinted)
	{
	  printf (_("\nArchive index:\n"));
	  everprinted = TRUE;
	}
      elt = bfd_get_elt_at_index (abfd, idx);
      if (elt == NULL)
	bfd_fatal ("bfd_get_elt_at_index");
      if (thesym->name != (char *) NULL)
	{
	  print_symname ("%s", thesym->name, abfd);
	  printf (" in %s\n", bfd_get_filename (elt));
	}
    }
}

/* This function is used to get the relocs for a particular section.
   It is called via bfd_map_over_sections.  */

static void
get_relocs (abfd, sec, dataarg)
     bfd *abfd;
     asection *sec;
     PTR dataarg;
{
  struct get_relocs_info *data = (struct get_relocs_info *) dataarg;

  *data->secs = sec;

  if ((sec->flags & SEC_RELOC) == 0)
    {
      *data->relocs = NULL;
      *data->relcount = 0;
    }
  else
    {
      long relsize;

      relsize = bfd_get_reloc_upper_bound (abfd, sec);
      if (relsize < 0)
	bfd_fatal (bfd_get_filename (abfd));

      *data->relocs = (arelent **) xmalloc (relsize);
      *data->relcount = bfd_canonicalize_reloc (abfd, sec, *data->relocs,
						data->syms);
      if (*data->relcount < 0)
	bfd_fatal (bfd_get_filename (abfd));
    }

  ++data->secs;
  ++data->relocs;
  ++data->relcount;
}

#ifdef __VOS__

#define PM_RECORD_LENGTH 4096

#define vos_filename(f) f

/* We assume that all maps are contiguous in vm and in the file */

static long unsigned vos_min_map_address;     /* min virtual address */
static long unsigned vos_max_map_address;     /* max virtual address */
static long unsigned vos_virtual_origin;      /* file offset of virt addr 0 */
static long unsigned vos_map_file_address;    /* file offset of map */
static long unsigned vos_map_virtual_address; /* virtual address of 1st map */
static long unsigned vos_map_len;             /* total bytes in all maps */
static char *vos_string_pool_ptr;
static int  vos_string_pool_len;
static char_varying(8) error_string;

#define VOS_STRING_POOL_PREFIX "+pool."
#define VOS_STRING_POOL_PREFIX_LEN 6
#define VOS_MAX_STRING_LEN 256

/* Determine whether the current file appears to be a VOS
   program module or shared library.  Because there is no
   specific identification marker, we rely on a series of
   plausibility checks */

static bfd_boolean
is_vos_pm (bfd *file, char **buffer_ptr)
{
FILE *pm_file;
program_module *pm_ptr;
size_t n_bytes;
size_t n_read;
int r;
char *bufp;

/* execution */

  pm_file = (FILE *) file->iostream;
  n_bytes = sizeof (program_module);

  bufp = malloc (n_bytes);
  if (bufp == NULL)
    return FALSE;

  *buffer_ptr = bufp;

  r = fseek (pm_file, 0L, SEEK_SET);
  if (r < 0)
  {
    fprintf (stderr, "nm: unable to position to offset 0.\n");
    free (bufp);
    return FALSE;
  }

  n_read = fread (bufp, 1, n_bytes, pm_file);
  if (n_read < n_bytes)
  {
    fprintf (stderr, "nm: expected %lu bytes, got %lu\n", n_bytes,
      n_read);
    free (bufp);
    return FALSE;
  }

  if (ferror (pm_file))
  {
    fprintf (stderr, "nm: unable to read pm header.\n");
    return FALSE;
  }

  if (feof (pm_file))
  {
    free (bufp);
    return FALSE;
  }

  pm_ptr = (program_module *) bufp;
    
  if ((n_bytes >= sizeof(program_module)) &&
      (pm_ptr->version >= program_module_version_1) &&
      (pm_ptr->version <= program_module_version_2) &&
      (pm_ptr->binder_version.len >= 0) &&
      (pm_ptr->binder_version.len <= 32) &&
      (pm_ptr->binder_options.len >= 0) &&
      (pm_ptr->binder_options.len <= 32) &&
      (pm_ptr->system_name.len >= 0) &&
      (pm_ptr->system_name.len <= 32) &&
      (pm_ptr->user_name.len >= 0) &&
      (pm_ptr->user_name.len <= 65) &&
      (pm_ptr->n_header_pages == 1) &&
      (pm_ptr->header_len >= 0) &&
      (pm_ptr->header_len <= (long)sizeof(program_module)) &&
      (pm_ptr->release_name.len) >= 0 &&
      (pm_ptr->release_name.len) <= 32 &&
      (pm_ptr->copyright_notice.len >= 0) &&
      (pm_ptr->copyright_notice.len <= 256) &&
      (pm_ptr->program_name.len >= 0) &&
      (pm_ptr->program_name.len <= 32))
  {
    return TRUE;
  }   

  return FALSE;
}

/* Diagnose options that VOS does not support */

static bfd_boolean
vos_check_options (void)
{
int r;

  /* options not listed are either supported or ignored as
     unnecessary */

  r = FALSE;
  if (print_debug_syms)
  {
    fprintf (stderr, "The --debug_syms option is not supported for VOS files\n");
    r = TRUE;
  }
  if (line_numbers)
  {
    fprintf (stderr, "The --line-numbers option is not supported for VOS files\n");
    r = TRUE;
  }
  if (do_demangle)
  {
    fprintf (stderr, "The --demangle option is not supported for VOS files\n");
    r = TRUE;
  }
  if (sort_numerically)
  {
    fprintf (stderr, "The --numeric-sort option is not supported for VOS files\n");
    r = TRUE;
  }
  if (print_armap)
  {
    fprintf (stderr, "The --print-armap option is not supported for VOS files\n");
    r = TRUE;
  }
  if (reverse_sort)
  {
    fprintf (stderr, "The --reverse-sort option is not supported for VOS files\n");
    r = TRUE;
  }
  if (sort_by_size)
  {
    fprintf (stderr, "The --size-sort option is not supported for VOS files\n");
    r = TRUE;
  }
  if (show_stats)
  {
    fprintf (stderr, "The --stats option is not supported for VOS files\n");
    r = TRUE;
  }

  return r;
}

/* Find the minimum and maximum virtual addresses for all symbol
   maps that we care about */

static void
vos_compile_maps (program_module *pmhp)
{
/* execution */

  vos_virtual_origin = pmhp -> n_header_pages * PM_RECORD_LENGTH
                     - pmhp -> user_boundary;

  vos_min_map_address = -1; /* FFFFFFFFx */
  vos_max_map_address =  0;

  vos_minimax_map_addr (pmhp -> module_map_address,
			pmhp -> module_map_len);
  vos_minimax_map_addr (pmhp -> external_vars_map_address,
			pmhp -> external_vars_map_len);
  vos_minimax_map_addr (pmhp -> link_names_map_address,
			pmhp -> link_names_map_len);
/*vos_minimax_map_addr (pmhp -> link_map_address,
			pmhp -> link_map_len);*/
  vos_minimax_map_addr (pmhp -> header_address,
			pmhp -> header_len);
  vos_minimax_map_addr (pmhp -> entry_map_address,
			pmhp -> entry_map_len);
  vos_minimax_map_addr (pmhp -> string_pool_address,
			pmhp -> string_pool_len);
  vos_minimax_map_addr (pmhp -> obj_dir_map_address,
			pmhp -> obj_dir_map_len);
  vos_minimax_map_addr (pmhp -> section_map_address,
			pmhp -> section_map_len);
  vos_minimax_map_addr (pmhp -> dynsym_map_address,
			pmhp -> dynsym_map_len);
  vos_minimax_map_addr (pmhp -> dynref_map_address,
			pmhp -> dynref_map_len);

  vos_map_file_address = vos_min_map_address + vos_virtual_origin;
  vos_map_virtual_address = vos_min_map_address;
  vos_map_len = vos_max_map_address - vos_min_map_address;
}

/* Display selected symbols from the relevant maps in the VOS
   program module or shared library */

static bfd_boolean
vos_display_pm (bfd *file, char *buffer_ptr, char *filename)
{
int i;
int keep;
int n_entrypoints;
int n_variables;
int n_names;
int no_symbols;
FILE *pm_file;
program_module *pm_ptr;
void *dr_map_ptr;
void *ds_map_ptr;
void *entry_map_ptr;
void *ev_map_ptr;
void *ln_map_ptr;
dynref_entry *dre_ptr;
dynsym_entry *dse_ptr;
em_entry *eme_ptr;
evm_entry *eve_ptr;
lnm_entry *lnme_ptr;

/* static */

/* We treat all VOS data as initialized */

static int decode_region[9] = {
  '?', /* 0 - undefined */
  'T', /* 1 - code region */
  'N', /* 2 - symtab region */
  'D', /* 3 - static region */
  'D', /* 4 - ext static region */
  'D', /* 5 - bss region */
  'D', /* 6 - ext bss region */
  'T', /* 7 - pop region */
  'T'  /* 8 - ext name region */};

/* execution */

  pm_file = (FILE *) file->iostream;
  pm_ptr = (program_module *) buffer_ptr;

  /* Calculate virtual region used by the maps, and the file
     offset of the maps */

  vos_compile_maps (pm_ptr);

  /* Load the string pool  */

  vos_string_pool_len = pm_ptr -> string_pool_len;
  vos_string_pool_ptr = vos_load_map (pm_file,
    pm_ptr -> string_pool_address,
    pm_ptr -> string_pool_len);

  /* Display the headers */

  switch (format_number)
  {
case (FORMAT_BSD):
    print_object_filename_bsd (filename);
    break;

case (FORMAT_POSIX):
    print_object_filename_posix (filename);
    break;

case (FORMAT_SYSV):
    bfd_fatal (_("The --format=sysv option is not supported for VOS files"));
    break;
  }

  /* Assume no symbols */

  no_symbols = 1;

  /* Display entrypoints (Code T for Text Section) */

  if (defined_only)
    keep = 1;
  else if (undefined_only)
    keep = 0;
  else
    keep = 1;

  if (!dynamic && keep)
  {
    n_entrypoints = pm_ptr->n_entries;

    entry_map_ptr = vos_load_map (pm_file,
      pm_ptr -> entry_map_address,
      pm_ptr -> entry_map_len);

    if (entry_map_ptr != NULL)
    {
      eme_ptr = (em_entry *) entry_map_ptr;
      for (i=0; i<n_entrypoints; i++)
      {
        no_symbols = 0;
        vos_print_symbol_info (filename,
          vos_symbol_name (&eme_ptr -> name),
          'T', (size_t) eme_ptr -> code_address, 0);
        eme_ptr = eme_ptr + 1;
      }
      free (entry_map_ptr);
    }
  }

  /* Display external variables  */

  if (!dynamic && keep)
  {
    n_variables = pm_ptr->n_external_vars;

    ev_map_ptr = vos_load_map (pm_file,
      pm_ptr -> external_vars_map_address,
      pm_ptr -> external_vars_map_len);

    if (ev_map_ptr != NULL)
    {
      eve_ptr = (evm_entry *) ev_map_ptr;
      for (i=0; i<n_variables; i++)
      {
        no_symbols = 0;
        vos_print_symbol_info (filename,
          vos_symbol_name (&eve_ptr -> name),
          decode_region [+eve_ptr -> regionx],
          (size_t) eve_ptr -> address,
          (size_t) eve_ptr -> len);
        eve_ptr = eve_ptr + 1;
      }
      free (ev_map_ptr);
    }
  }

  /* Display unresolved links (Code U for Undefined) */

  if (defined_only)
    keep = 0;
  else if (undefined_only)
    keep = 1;
  else
    keep = 1;

  if (!dynamic && keep)
  {
    n_names = pm_ptr->n_link_names;

    ln_map_ptr = vos_load_map (pm_file,
      pm_ptr -> link_names_map_address,
      pm_ptr -> link_names_map_len);

    if (ln_map_ptr != NULL)
    {
      lnme_ptr = (lnm_entry *) ln_map_ptr;
      for (i=0; i<n_names; i++)
      {
        no_symbols = 0;
        vos_print_symbol_info (filename,
          vos_symbol_name (lnme_ptr), 'U',
          0, 0);
        lnme_ptr = lnme_ptr + 1;
      }
      free (ln_map_ptr);
    }
  }

  /* Display dynamic references (Code U for Undefined) */

  if (dynamic && keep)
  {
    n_names = pm_ptr->n_dynrefs;

    dr_map_ptr = vos_load_map (pm_file,
      pm_ptr -> dynref_map_address,
      pm_ptr -> dynref_map_len);

    if (dr_map_ptr != NULL)
    {
      dre_ptr = (dynref_entry *) dr_map_ptr;
      for (i=0; i<n_names; i++)
      {
        no_symbols = 0;
        vos_print_symbol_info (filename,
          vos_string_pool_name (dre_ptr -> name),
          'U', 0, 0);
        dre_ptr = dre_ptr + 1;
      }
      free (dr_map_ptr);
    }
  }

  /* Display dynamic symbols */

  if (defined_only)
    keep = 1;
  else if (undefined_only)
    keep = 0;
  else
    keep = 1;

  if (dynamic && keep)
  {
    n_names = pm_ptr->n_dynsyms;

    ds_map_ptr = vos_load_map (pm_file,
      pm_ptr -> dynsym_map_address,
      pm_ptr -> dynsym_map_len);

    if (ds_map_ptr != NULL)
    {
      dse_ptr = (dynsym_entry *) ds_map_ptr;
      for (i=0; i<n_names; i++)
      {
        no_symbols = 0;
        vos_print_symbol_info (filename,
          vos_string_pool_name (dse_ptr -> name),
          decode_region [+dse_ptr -> regionx],
          dse_ptr -> address,
          dse_ptr -> static_address_or_len);
        dse_ptr = dse_ptr + 1;
      }
      free (ds_map_ptr);
    }
  }

  if (no_symbols)
    non_fatal (_("%s: no symbols"), filename);

  /* Release the PMH */

  free (buffer_ptr);

  /* Release the string pool */

  free (vos_string_pool_ptr);

  return TRUE;
}

/* Load a VOS symbol map */

static void *
vos_load_map (FILE *pm_file, long map_address, long map_bytes)
{
char *buffer_ptr;
size_t n_read;
size_t n_bytes;
int r;
size_t uns_map_address;
long file_address;

/* execution */

  if (map_address == 0 || map_bytes == 0)
    return (NULL);

  n_bytes = (size_t) map_bytes;
  uns_map_address = (size_t)map_address;

  if ((uns_map_address >= vos_map_virtual_address) &&
      (uns_map_address <  vos_map_virtual_address + vos_map_len))
  {
    file_address = (long) (uns_map_address - vos_map_virtual_address +
      vos_map_file_address);
  }
  else return (NULL);

  buffer_ptr = malloc (n_bytes);
  if (buffer_ptr == NULL)
    return NULL;

  r = fseek (pm_file, file_address, SEEK_SET);
  if (r < 0)
  {
    fprintf (stderr, "nm: unable to position to offset %08lX.\n",
      file_address);
    free (buffer_ptr);
    return NULL;
  }

  n_read = fread (buffer_ptr, 1, n_bytes, pm_file);
  if (n_read < n_bytes)
  {
    fprintf (stderr, "nm: unable to read map of %lu bytes.\n",
      n_bytes);
    free (buffer_ptr);
    return NULL;
  }

  return buffer_ptr;
}

/* Update the minimum and maximum map address values */

static void
vos_minimax_map_addr (long map_address, long map_len)
{
size_t uns_map_address;
size_t uns_map_len;

/* execution */

  if ((map_address ^= 0) && (map_len ^= 0))
  {
    uns_map_address = (size_t) map_address;
    uns_map_len = (size_t) map_len;

    if (vos_min_map_address > uns_map_address)
      vos_min_map_address = uns_map_address;

    if (vos_max_map_address < uns_map_address + uns_map_len)
      vos_max_map_address = uns_map_address + uns_map_len;
  }
}

/* Print symbol information BSD-style */

static void
vos_print_symbol_info_bsd (char_varying *p_name, int p_type,
  size_t p_value, size_t p_size)
{
  if (bfd_is_undefined_symclass (p_type))
    {
      printf ("        ");
    }
  else
    {
      vos_print_value (p_value);

      if (print_size && (p_size != 0))
        {
          printf (" ");
          vos_print_value (p_size);
        }
    }

  printf (" %c %v\n", p_type, p_name);
}

/* Print symbol information POSIX-style */

static void
vos_print_symbol_info_posix (char_varying *p_name, int p_type,
  size_t p_value, size_t p_size)
{
  printf ("%v %c ", p_name, p_type);

  if (bfd_is_undefined_symclass (p_type))
    printf ("        ");
  else
    {
      vos_print_value (p_value);
      printf (" ");
      if (p_size != 0)
        vos_print_value (p_size);
    }
  putchar ('\n');
}

static void
vos_print_symbol_info (char *filename, char_varying *p_name,
  int p_type, size_t p_value, size_t p_size)
{
  if (filename_per_symbol)
    printf ("%s:", vos_filename (filename));

  switch (format_number)
  {
case (FORMAT_BSD):
    vos_print_symbol_info_bsd (p_name, p_type, p_value, p_size);
    break;

case (FORMAT_POSIX):
    vos_print_symbol_info_posix (p_name, p_type, p_value, p_size);
    break;

default:
    /* can't get here */
    break;
  }
  return;
}

static void
vos_print_value (size_t p_value)
{
  printf (value_format, p_value);
}

/* The object directory map, dynamic table, dynref map, and dynsym map
   directly reference the string pool.  For compatibility,
   long-established maps contain the actual name unless the length
   exceeds 32 characters, in which case a special prefix is used to
   denote that the full name is in the string pool */

static char_varying *
vos_string_pool_name (int p_pool_id)
{
/* automatic */

char_varying *namep;

/* execution */

  if ((vos_string_pool_ptr == NULL) ||
      (p_pool_id + 2 > vos_string_pool_len))
  {
    strcpy_vstr_nstr (&error_string, "*ERROR*");
    return &error_string;
  }

  namep = (char_varying *)(vos_string_pool_ptr + p_pool_id);

  if (strlen_vstr (namep) > VOS_MAX_STRING_LEN)
  {
    strcpy_vstr_nstr (&error_string, "*ERROR*");
    return &error_string;
  }

  return namep;
}

/* Retrieve a name that may reference the string pool */

static char_varying *
vos_symbol_name (char_varying *p_name)
{
/* automatic */

int ch;
char *charp;
int i;
int len;
int offset;

/* execution */

  if (vos_string_pool_ptr == NULL)
    return p_name;

  len = strlen_vstr (p_name);

  if (len <= VOS_STRING_POOL_PREFIX_LEN)
    return p_name;

  if (strncmp_vstr_nstr (p_name, VOS_STRING_POOL_PREFIX,
      VOS_STRING_POOL_PREFIX_LEN) != 0)
    return p_name;

  offset = 0;
  charp = strchr_vstr (p_name, '.');

  for (i=VOS_STRING_POOL_PREFIX_LEN+1; i<=len; i++)
  {
    ch = *(++charp);
    if ((ch < '0') || (ch > '9'))
      return (p_name);
    offset = offset * 10 + ch - (int)'0';
  }

  return vos_string_pool_name (offset);
}
#endif /* __VOS__ */
