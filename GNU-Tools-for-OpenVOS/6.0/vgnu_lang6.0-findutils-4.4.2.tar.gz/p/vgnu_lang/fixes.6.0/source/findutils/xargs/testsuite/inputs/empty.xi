foo '' bar
baz ''
'' fnord
