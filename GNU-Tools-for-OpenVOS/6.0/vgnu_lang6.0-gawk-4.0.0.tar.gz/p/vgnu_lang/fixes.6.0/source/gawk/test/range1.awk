/foo/,/bar/ { print }
