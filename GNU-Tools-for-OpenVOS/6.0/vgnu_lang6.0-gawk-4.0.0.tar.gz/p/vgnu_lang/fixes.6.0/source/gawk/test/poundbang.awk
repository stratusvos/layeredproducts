#! /tmp/gawk -f 
{ print }
