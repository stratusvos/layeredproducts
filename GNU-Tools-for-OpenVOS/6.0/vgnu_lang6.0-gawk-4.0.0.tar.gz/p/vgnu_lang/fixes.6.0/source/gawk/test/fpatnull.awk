BEGIN { FPAT = "" }
{ print NF }
