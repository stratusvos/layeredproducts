{print match(""," *")}
