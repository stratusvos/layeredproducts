BEGIN { RS = "" }
{ print }
