/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#include <time.h>
int gl_futimens (int, char const *, struct timespec const [2]);
int utimens (char const *, struct timespec const [2]);
