/* For blead, this file needs to do nothing other than pull in the regular
   regcomp.h. For the 5.8.x re module it has to do more.
   But doing it this way keeps regcomp.c and regexec.c clean.
*/

#include "regcomp.h"

