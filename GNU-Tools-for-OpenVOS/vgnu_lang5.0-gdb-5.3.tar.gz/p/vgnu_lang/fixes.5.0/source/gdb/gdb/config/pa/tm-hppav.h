/*  HP PA-RISC machine native support for VOS              */

/* Mostly it's common to all HPPA's.  */
#include "pa/tm-hppa.h"

#define GDB_TARGET_IS_PA_ELF

#define VOS_TARGET

/* Never in SIGTRAMP */
#define IN_SIGTRAMP(pc, name) (0)

#undef BREAKPOINT
#define BREAKPOINT  { 0x00, 0x09, 0x00, 0x03}

/* Bug gnu_gdb-36.  VOS target dependent code has the pc pointing
   to the pc of the instruction making the call and not to the
   instruction following it.
   */
#define DECR_PC_AFTER_CALL_IN_TRACEBACK(pc)  

/* VOS-specific definitions. Override those which are in tm-hppa.h */

/* VOS automatic variables are addressed off of the fap */
#undef FRAME_LOCALS_ADDRESS
#define FRAME_LOCALS_ADDRESS(fi) vos_frame_locals_address(fi);
extern CORE_ADDR vos_frame_locals_address PARAMS((struct frame_info *fi));

#undef  DO_REGISTERS_INFO
#define DO_REGISTERS_INFO(_regnum, fp) vos_pa_do_registers_info (_regnum, fp)
extern void vos_pa_do_registers_info PARAMS ((int, int));

/* Wide register support, taken from wdb */

/* Say how long (ordinary) registers are.  This is used in
   push_word and a few other places, but REGISTER_RAW_SIZE is
   the real way to know how big a register is.  */

#undef REGISTER_SIZE
#define REGISTER_SIZE 8

/* Number of bytes of storage in the actual machine representation
   for register N.  On the PA-RISC 2.0, all regs are 8 bytes, including
   the FP registers (they're accessed as two 4 byte halves).  */

#undef REGISTER_RAW_SIZE
#define REGISTER_RAW_SIZE(N) 8

/* Largest value REGISTER_RAW_SIZE can have.  */

#undef MAX_REGISTER_RAW_SIZE
#define MAX_REGISTER_RAW_SIZE 8

/* Total amount of space needed to store our copies of the machine's
   register state, the array `registers'.  */

#undef REGISTER_BYTES
#define REGISTER_BYTES (NUM_REGS * 8)

/* Index within `registers' of the first byte of the space for
   register N.  */

#undef REGISTER_BYTE
#define REGISTER_BYTE(N) ((N) * 8)

#undef REGISTER_VIRTUAL_TYPE
#define REGISTER_VIRTUAL_TYPE(N) \
 ((N) < FP0_REGNUM ? builtin_type_unsigned_long_long : builtin_type_double)


#undef STORE_STRUCT_RETURN
#define STORE_STRUCT_RETURN(struct_addr, sp) \
 {  LONGEST val  = struct_addr; \
    write_register(RET0_REGNUM, val); \
 }

#undef DEPRECATED_EXTRACT_STRUCT_VALUE_ADDRESS
#define DEPRECATED_EXTRACT_STRUCT_VALUE_ADDRESS(regbuf) \
     (*(int *)((regbuf) + REGISTER_BYTE(RET0_REGNUM) + 4))


#undef DEPRECATED_EXTRACT_RETURN_VALUE
#define DEPRECATED_EXTRACT_RETURN_VALUE(TYPE,REGBUF,VALBUF) \
     vos_hppa_extract_return_value(TYPE, REGBUF, VALBUF);


#undef DEPRECATED_STORE_RETURN_VALUE
#define DEPRECATED_STORE_RETURN_VALUE(TYPE,VALBUF) \
     vos_hppa_store_return_value(TYPE, VALBUF);
void vos_hppa_extract_return_value PARAMS((struct type *, char regbuf[REGISTER_BYTES], char * ));
void vos_hppa_store_return_value PARAMS((struct type *, char * ));

/* Number of machine registers */
#undef NUM_REGS
#define NUM_REGS 96

#undef DEPRECATED_CLEAN_UP_REGISTER_VALUE
#define     DEPRECATED_CLEAN_UP_REGISTER_VALUE(regno, buf) \
  do {     \
    if ((regno) == PCOQ_HEAD_REGNUM || (regno) == PCOQ_TAIL_REGNUM) \
      (buf)[7] &= ~0x3; \
  } while (0)

/* Initializer for an array of names of registers.
   There should be NUM_REGS strings in this initializer.
   They are in rows of eight entries  */
#undef REGISTER_NAMES
#define REGISTER_NAMES \
 {"r0",     "r1",      "rp",      "r3",    "r4",     "r5",      "r6",     "r7",    \
  "r8",     "r9",      "r10",     "r11",   "r12",    "r13",     "r14",    "r15",   \
  "r16",    "r17",     "r18",     "r19",   "r20",    "r21",     "r22",    "r23",   \
  "r24",    "r25",     "r26",     "dp",    "ret0",   "ret1",    "sp",     "r31",   \
  "sar",    "pcoqh",   "pcsqh",   "pcoqt", "pcsqt",  "eiem",    "iir",    "isr",   \
  "ior",    "ipsw",    "",        "sr4",   "sr0",    "sr1",     "sr2",    "sr3",   \
  "sr5",    "sr6",     "sr7",     "cr0",   "cr8",    "cr9",     "ccr",    "cr12",  \
  "cr13",   "cr24",    "cr25",    "cr26",  "",        "",        "",      "",\
  "fr0",    "fr1",     "fr2",    "fr3",    "fr4",    "fr5",     "fr6",    "fr7", \
  "fr8",    "fr9",    "fr10",    "fr11",  "fr12",   "fr13",    "fr14",   "fr15", \
  "fr16",    "fr17",   "fr18",    "fr19",  "fr20",   "fr21",    "fr22",   "fr23", \
  "fr24",    "fr25",   "fr26",    "fr27",   "fr28",  "fr29",    "fr30",   "fr31"}

#undef FP0_REGNUM
#undef FP4_REGNUM
#define FP0_REGNUM 64          /* floating point reg. 0 (fspr)*/
#define FP4_REGNUM 68

/* Argument Pointer Register */
#define AP_REGNUM 29

#define DP_REGNUM 27

#define FP5_REGNUM 69

#define R3_REGNUM  3
#define R4_REGNUM  4

#define R26_REGNUM 26
#define ARG0_REGNUM 26
#define ARG1_REGNUM 25
#define ARG2_REGNUM 24
#define ARG3_REGNUM 23

#define RET0_REGNUM 28
#define RET1_REGNUM 29

#define R31_REGNUM 31

#define FIRST_SAVED_FR FP4_REGNUM
#define FIRST_SAVED_GR R3_REGNUM

/* Where space registers are in register array. */
#define FIRST_SR_REGNUM SR4_REGNUM
#define SR0_REGNUM  44 /* SR4_REGNUM + 1 */
#define SR1_REGNUM  45
#define SR2_REGNUM  46
#define SR3_REGNUM  47
#define SR5_REGNUM  48
#define SR6_REGNUM  49
#define SR7_REGNUM  50
#define LAST_SR_REGNUM SR7_REGNUM


/* Defines for  control registers in register array. These are additions 
   to definitions in tm-hppa.h */

#define FIRST_CR_REGNUM SAR_REGNUM
#define CR0_REGNUM   51 
#define PIDR1_REGNUM 52 /* CR8 */
#define PIDR2_REGNUM 53 /* CR9 */
#define CCR_REGNUM   54
#define PIDR3_REGNUM 55 /* CR12 */
#define PIDR4_REGNUM 56 /* CR13 */
#define ISR_REGNUM   39
#define TR1_REGNUM   58
#define TR2_REGNUM   59
#define LAST_CR_REGNUM 63

/* The following five numbers are unused .. we never want to read them.
   gnu_gdb-78 */
#define GOTO_REGNUM  42
#define FIRST_INVALID_REGNUM 60
#define LAST_INVALID_REGNUM  63
#define IS_INVALID_REGNUM(regno) (((regno) == GOTO_REGNUM)||(((regno) >= FIRST_INVALID_REGNUM) && ((regno) <= LAST_INVALID_REGNUM)))

#define FIRST_INT_REGNUM 0
#define LAST_INT_REGNUM 31
#define IS_FLOAT_REG(regno) ((regno) >= FP0_REGNUM)
#define IS_INT_REG(regno)   ((regno) <=  LAST_INT_REGNUM)
#define IS_SR_REG(regno)   (((regno)>=FIRST_SR_REGNUM) && ((regno)<=LAST_SR_REGNUM))
#define IS_CR_REG(regno)    (((regno) >= FIRST_CR_REGNUM) && ((regno) <= LAST_CR_REGNUM) && !IS_SR_REG(regno))

#define DEADVAL 0xdeaddead

/* Redefine some target bit sizes from the default.  */

/* Number of bits in a long or unsigned long for the target machine. */

#define TARGET_LONG_BIT 64

/* Number of bits in a long long or unsigned long long for the 
   target machine.  */

#define TARGET_LONG_LONG_BIT 64

/* Start of definition of VOS target-specific functions.
   */

#undef TARGET_READ_PC
#define TARGET_READ_PC(pid) vos_hppa_target_read_pc (pid)
extern CORE_ADDR vos_hppa_target_read_pc PARAMS ((ptid_t));

#undef TARGET_WRITE_PC
#define TARGET_WRITE_PC(v,pid) vos_hppa_target_write_pc (v,pid)
extern void vos_hppa_target_write_pc PARAMS ((CORE_ADDR, ptid_t));

#undef FRAME_CHAIN
#define FRAME_CHAIN(thisframe) vos_hppa_frame_chain (thisframe)
extern CORE_ADDR vos_hppa_frame_chain PARAMS((struct frame_info *));

/* Extra info needed by VOS.  This includes a pointer to "saved info"
   that is the values calculated by frame_chain and stashed here until
   init_extra_frame_info put it into the frame_info struct for the
   frame it is rolling back to. This is necessary because frame_chain
   doesn't have a pointer to the "prev" structure to put it into.
   */
#define EXTRA_FRAME_INFO \
struct frame_info *saved_info; \
void *regional_block_map_ptr; \
void *entry_block_ptr; \
CORE_ADDR sp; \
CORE_ADDR r2; \
CORE_ADDR r3; \
CORE_ADDR r31; \
unsigned long fap; \
unsigned long region_pc; \
unsigned short region_type; \
char r3_saved; \
char r3_in_r4_upper; \
CORE_ADDR arg0;

/* From stack_frame_constants -- this value is only used in vos-read 
   gnu_gdb-95*/
#define BACKUP_SP_HPPA  -32
#define PARAMETER_LIST_VIRTUAL_ORIGIN BACKUP_SP_HPPA
#define PARAMETER_LIST_GROWS_DOWNWARD

#define PRINT_EXTRA_FRAME_INFO(fi) \
 vos_hppa_print_extra_frame_info(fi);

void vos_hppa_print_extra_frame_info(struct frame_info *fi);

#undef FRAMELESS_FUNCTION_INVOCATION

#undef INIT_FRAME_PC
#define INIT_FRAME_PC(fromleaf, frame) init_frame_pc_noop(fromleaf, frame)

#undef INIT_FRAME_PC_FIRST
#define INIT_FRAME_PC_FIRST(fromleaf, frame) \
                                   init_frame_pc_default(fromleaf, frame)

#undef INIT_EXTRA_FRAME_INFO
#define INIT_EXTRA_FRAME_INFO(fromleaf, frame)  \
   vos_hppa_init_extra_frame_info (fromleaf, frame)
extern void vos_hppa_init_extra_frame_info PARAMS ((int, struct frame_info *));

#undef FRAME_SAVED_PC
#define FRAME_SAVED_PC(frame) vos_hppa_get_return_pc(frame)
extern unsigned long vos_hppa_get_return_pc PARAMS((struct frame_info *frame));

#undef FRAME_FIND_SAVED_REGS
#define FRAME_FIND_SAVED_REGS(frame_info, frame_saved_regs) \
     vos_hppa_frame_find_saved_regs(frame_info, &frame_saved_regs)
extern void vos_hppa_frame_find_saved_regs PARAMS ((struct frame_info *,
     struct frame_saved_regs *));

/* We don't need this: we'll return a pc of 0 from vos_hppa_frame_chain
   when we reach the bottom of the stack or we can't unwind */
#undef FRAME_CHAIN_VALID
#define FRAME_CHAIN_VALID(chain, thisframe)   (chain != 0)

/* Inferior calls aren't supported yet. */
#define gdb_target_is_hppa
#undef PUSH_DUMMY_FRAME
#undef POP_DUMMY_FRAME
#undef FIX_CALL_DUMMY
#undef CALL_DUMMY_P
#undef CALL_DUMMY
#undef CALL_DUMMY_LENGTH
#undef PUSH_ARGUMENTS
#undef POP_FRAME
#undef CALL_DUMMY_LOCATION
#undef CALL_DUMMY_ADDRESS
#undef PUSH_RETURN_ADDRESS
/* Believe the debugging information ... */
#undef COERCE_FLOAT_TO_DOUBLE 

#define CALL_DUMMY_P 0
#define CALL_DUMMY_ADDRESS()         entry_point_address ()

#define CALL_DUMMY {}
#define PC_IN_CALL_DUMMY(pc, sp, fp) vos_pc_in_call_dummy (pc, sp)
extern int vos_pc_in_call_dummy  PARAMS ((CORE_ADDR pc,  CORE_ADDR fp));

#define PUSH_DUMMY_FRAME vos_hppa_push_dummy_frame()
extern void vos_hppa_push_dummy_frame PARAMS ((void));

#define CALL_DUMMY_LOCATION AT_ENTRY_POINT

#define CALL_DUMMY_LENGTH 0

#define POP_FRAME  vos_hppa_pop_frame ()
extern void vos_hppa_pop_frame PARAMS ((void));

#define FIX_CALL_DUMMY vos_hppa_fix_call_dummy
extern CORE_ADDR vos_hppa_fix_call_dummy PARAMS((char *, CORE_ADDR, CORE_ADDR, int, struct value **, struct type *, int));

#define PUSH_ARGUMENTS(nargs, args, sp, struct_return, struct_addr) \
    sp = vos_hppa_push_arguments((nargs), (args), (sp), (struct_return), (struct_addr))
extern CORE_ADDR
vos_hppa_push_arguments 
     PARAMS ((int, struct value **, CORE_ADDR, int, CORE_ADDR));

#undef     SAVED_PC_AFTER_CALL
#define SAVED_PC_AFTER_CALL(frame) vos_hppa_saved_pc_after_call (frame)
extern CORE_ADDR vos_hppa_saved_pc_after_call PARAMS ((struct frame_info *));

#undef SKIP_PROLOGUE
#define SKIP_PROLOGUE(pc) vos_hppa_skip_prologue (pc)
extern CORE_ADDR vos_hppa_skip_prologue PARAMS ((CORE_ADDR));

#undef SKIP_TRAMPOLINE_CODE
#define SKIP_TRAMPOLINE_CODE(pc) vos_hppa_skip_trampoline(pc)
extern CORE_ADDR vos_hppa_skip_trampoline PARAMS((CORE_ADDR));


#undef IN_SOLIB_CALL_TRAMPOLINE
#define IN_SOLIB_CALL_TRAMPOLINE(pc, name)  (0)

#undef IN_SOLIB_RETURN_TRAMPOLINE
#define IN_SOLIB_RETURN_TRAMPOLINE(pc, name) (0)

#define GET_LONGJMP_TARGET(ADDR) get_longjmp_target(ADDR)
extern int get_longjmp_target PARAMS((CORE_ADDR *));

/* MLF: added this new macro (used in breakpoint.c) as we have
     "extra" longjmp entry points due to second implementation
     created for POSIX/gcc. Use only one of _ux_longjmp, _ux_siglongjmp,
     as they are at the same address .. 
    */
#define MORE_LONGJMP_BREAKPOINTS create_longjmp_breakpoint("_ux_longjmp"); 


