/*  HP PA-RISC machine native support for VOS              */



/* VOS cc won't let you use an incomplete structure tag ... */

#include "floatformat.h"

#include "target.h"

#define PTRACE_ARG3_TYPE char*

#include <ptrace.h>

/* Nonsense for VOS, but it makes the rest of gdb happy */

#define U_REGS_OFFSET 0

#define KERNEL_U_ADDR 0

/* VOS has no user area in the kernel ... */
#define REGISTER_U_ADDR

/* We need to figure out where the text region is 
   for PTRACE     */     
#define NEED_TEXT_START_END	1

/* fetch_inferior_registers is in hppav-nat.c.    
   */

#define FETCH_INFERIOR_REGISTERS

/* child_xfer_memory is in hppav-nat.c.  */
#define CHILD_XFER_MEMORY

/* For infptrace.c */

#define PT_KILL PTRACE_KILL
#define PT_STEP PTRACE_SINGLESTEP
#define PT_CONTINUE PTRACE_CONT
#define PT_READ_U PTRACE_PEEKDATA
#define PT_WRITE_U PTRACE_POKEDATA
#define PT_READ_I PTRACE_PEEKTEXT
#define PT_WRITE_I PTRACE_POKETEXT

/* gnu_gdb-104: conditionally define PTRACE_CLEANUP. */
#ifndef PTRACE_CLEANUP
#define PTRACE_CLEANUP   (11)
#endif

#undef target_pid_to_str

extern char *vos_ptid_to_str(ptid_t pid);

#define target_pid_to_str(pid) vos_ptid_to_str(pid)

extern int vos_prepare_to_proceed(int select_it);

#define PREPARE_TO_PROCEED(select_it) vos_prepare_to_proceed(select_it)

extern struct thread_info * find_thread_pid_lwp (int pid, int lwp);

#define FIND_THREAD_PID_LWP_BODY					\
struct thread_info *							\
find_thread_pid_lwp (int pid, int lwp)					\
{									\
  struct thread_info *tp;						\
									\
  for (tp = thread_list; tp; tp = tp->next)				\
    if (pid == ptid_get_pid (tp->ptid) && 				\
        lwp == ptid_get_lwp (tp->ptid))					\
      return tp;							\
									\
  return NULL;								\
}

#define PRINT_INFO_THREADS_COMMAND				\
  do								\
    {								\
      printf_filtered(" Thread   Process ID Unique ID Task Port StckBase StckLeng StatAddr StatLeng State           "); \
      printf_filtered("Faults CpuTime name\n");			\
    }								\
  while (0)

extern void vos_switch_threads(ptid_t ptid);
#define SWITCH_TO_THREAD_HOOK(ptid)  vos_switch_threads(ptid)

/* Even though VOS POSIX.1 does not completely implement job control,
   it implements enough for gdb's purposes.  This fixes gnu_gdb-138.  */

#include <unistd.h>

#ifndef _POSIX_JOB_CONTROL
#define _POSIX_JOB_CONTROL 1
#endif
