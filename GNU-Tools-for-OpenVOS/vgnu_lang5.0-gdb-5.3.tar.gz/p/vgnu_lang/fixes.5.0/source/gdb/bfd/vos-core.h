typedef union regs_union
  {
     char filler[MC_MAX_SIZE];
#if defined (HOST_X86VOS)
     mc_x86_full x86_regs;
#endif /* defined (HOST_X86VOS) */
   } mc_regs;

struct vos_core_struct
{
  km_template *km_header;
  vaddrfile_fcb_type *pm_fcb_ptr;
  char command[257];
  mc_regs regs;
  short machine_type;
  int sig;
};

#define core_data(bfd)          ((bfd)->tdata.vos_core_data)
#define core_signal(bfd)        (core_data(bfd)->sig)
#define core_km_header(bfd)     (core_data(bfd)->km_header)
#define core_fcb_ptr(bfd)       (core_data(bfd)->pm_fcb_ptr)
#define core_command(bfd)       (core_data(bfd)->command)
#define core_regs(bfd)          (core_data(bfd)->regs)
#define core_machine_type(bfd) (core_data(bfd))->machine_type

#if defined (HOST_X86VOS)
#define x86_regs(bfd)           (core_data(bfd)->regs.x86_regs)
#define x86_reg_size               sizeof(mc_x86_full)
#endif /* defined (HOST_X86VOS) */
