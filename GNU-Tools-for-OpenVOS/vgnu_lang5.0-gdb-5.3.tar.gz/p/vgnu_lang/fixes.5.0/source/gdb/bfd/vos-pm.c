/* Include files */

#include "bfd.h"
#include "sysdep.h"
#include "libbfd.h"
#include "elf-bfd.h"

#if defined(HOST_HPPAVOS) || defined(HOST_X86VOS)
#include "vos-defs.h"
#include <voslib.incl.c>

/* Necessary because gcc doesn't support shortmap */
#ifdef __GNUC__
#define $shortmap
#pragma pack(2)
#endif
#include <program_module.incl.c>
#ifdef __GNUC__
#undef $shortmap
#pragma pack()
#endif

#include <string.incl.c>
#include <object_constants.incl.c>
#include <system_io_constants.incl.c>
#include <cpu_version.incl.c>
#include <vaddrfile_dcls.incl.c>
#include "vos-pm.h"

/* Constants */

const char *vos_symtab_sec_names[3] = {vos_wired_symtab_sec_name,
                                   vos_init_symtab_sec_name,
                                   vos_paged_symtab_sec_name};
/* Type definitions */

/* Entries */

/* Externally visible entry points defined in this module.
   These entries are called through function pointers */
boolean       vos_close_and_cleanup PARAMS((bfd *abfd));
boolean       vos_bfd_copy_private_bfd_data PARAMS((bfd *ibfd, bfd *obfd));
boolean       vos_bfd_free_cached_info PARAMS((bfd *abfd));
boolean       vos_bfd_print_private_bfd_data PARAMS((bfd *abfd, PTR filep));
boolean       vos_get_section_contents 
 PARAMS((bfd *abfd, sec_ptr sec, PTR loc, file_ptr offset, bfd_size_type cnt));
long          vos_get_symtab PARAMS((bfd *abfd, asymbol **location));
long          vos_get_symtab_upper_bound PARAMS((bfd *abfd));
boolean       vos_mkobject PARAMS((bfd *abfd));
const bfd_target    *vos_object_p PARAMS((bfd *abfd));
static void          vos_pm_read
PARAMS((char_varying *progpath, vaddrfile_fcb_type *pmfcb,  short *port, \
 short *code));
/* Called from vosread to make stab and stabstr sections as well as called
   internally from this module */
asection*       vos_make_section 
PARAMS((bfd *abfd, unsigned long sec_vaddr, long sec_len, const char *sec_name));

/* Static Entries */

/* These entries are internal to this module */
static boolean        vos_setup_sections PARAMS((bfd *abfd));
static boolean        vos_slurp_stringtab  PARAMS((bfd *abfd));
static boolean        vos_slurp_symtab  PARAMS((bfd *abfd));

/* External Entries */

extern void s$attach_port 
PARAMS((char_varying *port, char_varying *queue, short *switches, \
short *port_id, short *code));
void s$error 
 PARAMS((short *err, char_varying *callr, char_varying  *msg));
void s$open PARAMS((short *port, short *org, short *maxlen, short *io_type, \
 short *lock_mode, short *acc_mode, char_varying *index_name, short *code));
void s$rel_read PARAMS((short *port, long *recnum, short *buflen, \
short *reclen, char *buffer, short *code));
extern void s$c_expand_path (const char ** pathp,
               char_varying * cv_pathp,
               short * code);

/* Code starts here */



asection *
vos_make_section(abfd, sec_vaddr, sec_len, sec_name)
bfd *abfd;
unsigned long sec_vaddr;
long sec_len;
const char *sec_name;
{
 asection *newsect;
 char *newname;
 short code;
 vaddrfile_fcb_type *pm_fcb_ptr;

 PRINT_ENTER("vos_make_section");

 pm_fcb_ptr = obj_vos_pm_fcb_ptr(abfd);

 newname  = bfd_alloc(abfd, strlen(sec_name) + 1);
 if (newname == 0)
   return false;
 strcpy(newname, sec_name);

 newsect = bfd_make_section_anyway (abfd, newname);
 if (newsect == NULL)
   return NULL;

 newsect->alignment_power = 16; /* 4096 */
 if (! bfd_set_section_vma(abfd, newsect, sec_vaddr)
     || ! bfd_set_section_size(abfd, newsect, sec_len)
     || !  bfd_set_section_alignment (abfd, newsect, bfd_log2(4096) ))
   return NULL;

 newsect->flags = SEC_NO_FLAGS;
 newsect->filepos = convert_vaddr_to_fileaddr(pm_fcb_ptr, &sec_vaddr,
                        &code);
 return newsect;


}
/* Open PM file and init vaddrfile package, returning
   port id  and code  and with the vaddr_fcb written into the
   fcb whose address the caller has passed in.
*/
static void 
vos_pm_read(program_path_ptr, pm_fcb_ptr, port_id_ptr, code_ptr)
char_varying *program_path_ptr;
vaddrfile_fcb_type *pm_fcb_ptr;
short *port_id_ptr;
short *code_ptr;
{
 short io_type = INPUT_TYPE;  
 static char_varying_32 caller = {11, "vos_pm_read"};

/* Attach port, open in random mode for input, read PM header */
 
 PRINT_ENTER("vos_pm_read");

 *port_id_ptr = 0;

 vaddrfile_open_pm(program_path_ptr, &io_type, port_id_ptr, code_ptr);

 if (*code_ptr != 0) goto return_to_caller;

 vaddrfile_init_pm(port_id_ptr, pm_fcb_ptr, code_ptr);

return_to_caller:
 if (*code_ptr)
   s$error(code_ptr, &caller, program_path_ptr);
 return;   
}

boolean 
vos_mkobject(abfd)
bfd *abfd;
{
  PRINT_ENTER("vos_mkobject");
  abfd->tdata.vos_data = (struct vos_data_struct *)
    bfd_zalloc (abfd, sizeof (struct vos_data_struct));
  if (abfd->tdata.vos_data == NULL)
     return false;
  return true;
}   

     
/* This routine is the check_format routine for VOS "objects".
   In the VOS case, this routine handles PM's only.
   It uses the vaddrfile package to access the PM
   header and the external variable and external name maps.
   This requires using VOS IO routines.
*/
const bfd_target *
vos_object_p(abfd)
bfd *abfd;
{

 program_module *pm_header;
 vaddrfile_fcb_type *pm_fcb_ptr;
 short code = 0;
 short port_id;
 char_varying_256 filename;
 const bfd_target *retval = abfd->xvec;

 PRINT_ENTER("vos_object_p");

 /* Convert to VOS_style pathname */

 pm_fcb_ptr = bfd_alloc(abfd, sizeof(vaddrfile_fcb_type));
 if (pm_fcb_ptr == NULL)
   goto error_return;
 s$c_expand_path(&abfd->filename, &filename, &code);

 vos_pm_read(&filename, pm_fcb_ptr, &port_id, &code);
 if (code != 0)
   goto error_return;
 
 pm_header = pm_fcb_ptr->program_module_ptr;
 
 if ((code != 0) || (pm_header == NULL))   
  goto error_return;
 
 if (vos_mkobject (abfd) != true)
   goto error_return;

 /* Only support debugging of PA8000, PA7100, and Pentium 4 PM's */
 obj_vos_pm_header(abfd) =  pm_fcb_ptr->program_module_ptr;
 switch (obj_vos_processor (abfd))
   {
   case PA7100:
     bfd_default_set_arch_mach (abfd, bfd_arch_hppa, 11);
     break;
   case PA8000:
     bfd_default_set_arch_mach (abfd, bfd_arch_hppa, 20);
     break;
   case PENTIUM4:
     bfd_default_set_arch_mach (abfd, bfd_arch_i386, 0);
     break;
   default:
     goto error_return; 
   }
 
 obj_vos_pm_fcb_ptr(abfd) = pm_fcb_ptr; 
 
 abfd->flags = BFD_NO_FLAGS;
 abfd->flags |= EXEC_P;

 bfd_get_start_address (abfd) = obj_vos_main_code_address (abfd);

 /* Check for symbols and set flag.  We will have line nos, debug info
    and locals when ELF/DWARF in PM is implemented. */

 if ((obj_vos_n_external_vars(abfd) != 0) ||
     (obj_vos_n_entries(abfd) != 0))
   abfd->flags |= HAS_SYMS;

  if (! vos_setup_sections(abfd))
      goto error_return;
  
  return retval;

error_return:
 vaddrfile_done(pm_fcb_ptr);
 retval =  (bfd_target *) NULL;
 bfd_set_error(bfd_error_wrong_format);

 return retval;

}

long 
vos_get_symtab_upper_bound (abfd)
bfd *abfd;
{

 PRINT_ENTER("vos_get_symtab_upper_bound");

 if (!vos_slurp_symtab (abfd))
   return -1;

  return ((bfd_get_symcount(abfd) + 1) * (sizeof (PTR)));

}

long 
vos_get_dynamic_symtab_upper_bound (abfd)
bfd *abfd;
{

 PRINT_ENTER("vos_get_dynamic_symtab_upper_bound");

  return ((obj_vos_n_dynsyms(abfd) + 1) * (sizeof (PTR)));

}

boolean 
vos_get_section_contents (abfd, section, location, offset, count)
bfd *abfd;
sec_ptr section;
PTR location;
file_ptr offset;
 bfd_size_type count;
{
  vaddrfile_fcb_type *pm_fcb_ptr;
  unsigned long sec_vaddr;
  short code; 

  PRINT_ENTER("vos_get_section_contents");
  
  if (count == 0 || ((section->flags & SEC_HAS_CONTENTS) == 0))
    return true;
  if ((bfd_size_type)(offset+count) > section->_raw_size)
    return false;

  pm_fcb_ptr = obj_vos_pm_fcb_ptr (abfd);
  sec_vaddr = section->vma + offset;
  vaddrfile_read(pm_fcb_ptr, &sec_vaddr, (char **) &location, &count, &code);
  if (code != 0)
    {
      bfd_perror("Unable to get section contents\n");
      return false;
    }
  
  return true;
}

/* FIXME. 
   Need to make SYMTAB and MAP sections, object dir map.
   This needs to be added for VOS symtab support.
   Doesn't handle multi-section programs (yet).
*/
static boolean 
vos_setup_sections(abfd)
bfd *abfd;     
{
  unsigned long code_addr;
  long code_len;
  unsigned long static_addr;
  long static_len;
  unsigned long ext_static_addr;
  long ext_static_len;
  unsigned long symtab_addr;
  long symtab_sec_len;
  asection *ext_vars_map_sec_ptr;
  asection *entry_map_sec_ptr;
  asection *module_map_sec_ptr;
  asection *symtab_sec_ptr;
  asection *code_sec_ptr;
  asection *static_sec_ptr;
  asection *ext_static_sec_ptr;
  asection *string_pool_sec_ptr;
  asection *dynamic_sec_ptr;
  asection *dynsym_sec_ptr;
  vaddrfile_fcb_type *pm_fcb_ptr;
  int i;

  PRINT_ENTER("vos_setup_sections");

 /* Make map sections */

  pm_fcb_ptr = obj_vos_pm_fcb_ptr(abfd);
  ext_vars_map_sec_ptr =  vos_make_section(abfd,
                         obj_vos_external_vars_map_address(abfd),
                         obj_vos_external_vars_map_len(abfd), 
                         vos_external_vars_map_sec_name);

  entry_map_sec_ptr = vos_make_section(abfd,
                          obj_vos_entry_map_address(abfd),
                          obj_vos_entry_map_len(abfd), 
                          vos_entry_map_sec_name);
  module_map_sec_ptr = vos_make_section(abfd, 
                          obj_vos_module_map_address(abfd),
                          obj_vos_module_map_len(abfd),
                          vos_module_map_sec_name);
  string_pool_sec_ptr = vos_make_section(abfd,
                          obj_vos_string_pool_address(abfd),
                          obj_vos_string_pool_len(abfd),
                          vos_string_pool_sec_name);
  dynamic_sec_ptr = vos_make_section(abfd,
                          obj_vos_dynamic_table_address(abfd),
			  obj_vos_dynamic_table_len(abfd),
                          vos_dynamic_section_name);
  dynsym_sec_ptr = vos_make_section(abfd,
                          obj_vos_dynsym_map_address(abfd),
			  obj_vos_dynsym_map_len(abfd),
			  vos_dynsym_section_name);

   obj_vos_symcount(abfd) = 
     obj_vos_n_entries(abfd) + obj_vos_n_external_vars(abfd);

   if (entry_map_sec_ptr)
        entry_map_sec_ptr->flags |= 
          (SEC_DEBUGGING | SEC_HAS_CONTENTS);
   if (ext_vars_map_sec_ptr)
        ext_vars_map_sec_ptr->flags |= 
          (SEC_DEBUGGING | SEC_HAS_CONTENTS);
   if (string_pool_sec_ptr)
        string_pool_sec_ptr->flags |= 
          (SEC_DEBUGGING | SEC_HAS_CONTENTS);
   if (dynamic_sec_ptr)
	dynamic_sec_ptr->flags |=
	  (SEC_DEBUGGING | SEC_HAS_CONTENTS);
   if (dynsym_sec_ptr)
	dynsym_sec_ptr->flags |=
	  (SEC_DEBUGGING | SEC_HAS_CONTENTS);

   if (module_map_sec_ptr)
     module_map_sec_ptr->flags |=
     (SEC_DEBUGGING | SEC_HAS_CONTENTS);

  /* get code and static data and make sections of them */
  if ( (obj_vos_section_map_file_address(abfd) != 0) &&
      (obj_vos_section_map_len(abfd) != 0) &&
      (obj_vos_n_sections(abfd) != 0))
   {
     bfd_set_error(bfd_error_file_not_recognized);
     bfd_perror("gdb does not support debugging of kernel programs\n");
   }
  else 
   {
     for (i = wired_section; i <= paged_section; i++)
     {
          code_addr = 
             obj_vos_pm_info(abfd)[i-1][code_region-1].address;
          code_len = 
             obj_vos_pm_info(abfd)[i-1][code_region-1].len;
          static_addr = 
              obj_vos_pm_info(abfd)[i-1][static_region-1].address;
          static_len = 
              obj_vos_pm_info(abfd)[i-1][static_region-1].len;
          ext_static_addr = 
               obj_vos_pm_info(abfd)[i-1][ext_static_region-1].address;
          ext_static_len = 
               obj_vos_pm_info(abfd)[i-1][ext_static_region-1].len;
          symtab_addr = 
               obj_vos_pm_info(abfd)[i-1][symtab_region-1].address; 
          symtab_sec_len = 
               obj_vos_pm_info(abfd)[i-1][symtab_region-1].len;
       if (code_len != 0)
         {
           code_sec_ptr = vos_make_section(abfd, code_addr, code_len,
                vos_text_section_name); 
           if (code_sec_ptr == NULL)
             return false;
           code_sec_ptr->flags  |= (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_CODE);
         }

       if (static_len != 0)
         {
           static_sec_ptr = vos_make_section(abfd, static_addr, static_len,
                vos_static_data_section_name);
           if (static_sec_ptr == NULL)
             return false;
           static_sec_ptr->flags |= (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_DATA);
          }

       if (ext_static_len != 0)
         {
           ext_static_sec_ptr = vos_make_section(abfd, ext_static_addr, 
                 ext_static_len, vos_external_static_data_section_name);
           if (ext_static_sec_ptr == NULL)
             return false;
           ext_static_sec_ptr->flags |= 
                 (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_DATA);
         }
       if (symtab_sec_len != 0)
         {
           symtab_sec_ptr = vos_make_section(abfd, symtab_addr, symtab_sec_len,
                VOS_SYMTAB_SEC_NAMES(i));
           if (symtab_sec_ptr == NULL)
              return false;
           symtab_sec_ptr->flags |=
             (SEC_DEBUGGING | SEC_HAS_CONTENTS);
         }
    } /* for i = wired_section... */
   } /* else */

  return true;
}

static boolean 
vos_slurp_stringtab (abfd)
bfd *abfd;
{
 /* We may need this when we have ELF symtab and stabs */ 
 PRINT_ENTER("vos_slurp_stringtab"); 
 
 return false;
}

static boolean 
vos_slurp_symtab (bfd *abfd)
{
 /*We may need this when we have ELF symtab and stabs */ 
 PRINT_ENTER("vos_slurp_symtab");

 bfd_get_symcount(abfd) = obj_vos_symcount(abfd);

 return true;

}

/* Read symbols from BFD abfd and fill in vector location with 
   pointers to the symbols and a trailing NULL *.  Return actual
   number of symbol pointers, not including the NULL.
   This routine shouldn't be called either; however,
   this code would work if vos_slurp_symtab did */
long 
vos_get_symtab (abfd, location)
bfd *abfd;
asymbol **location;
{
 PRINT_ENTER("vos_get_symtab");
 
 if (!vos_slurp_symtab(abfd))
   return -1;

 return (bfd_get_symcount (abfd) + 1) * (sizeof (PTR));
}

/* Read dynamic symbols from BFD abfd and fill in vector location with 
   pointers to the symbols and a trailing NULL *.  Return actual
   number of dynamic symbol pointers, not including the NULL.
   This routine shouldn't be called either; however,
   this code would work if vos_slurp_symtab did */
long 
vos_canonicalize_dynamic_symtab (abfd, location)
bfd *abfd;
asymbol **location;
{
 PRINT_ENTER("vos_canonicalize_dynamic_symtab");
 
 return (obj_vos_n_dynsyms (abfd) + 1) * (sizeof (PTR));
}

#define FREE(x) if (x != NULL) { free (x); x = NULL; }
 
boolean 
vos_bfd_free_cached_info(abfd)
bfd *abfd;
{
   PRINT_ENTER("vos_bfd_free_cached_info");
  
  if (bfd_get_format (abfd) != bfd_object)
    return true;

   if (abfd->tdata.vos_data != (struct vos_data_struct *) NULL) 
       FREE(obj_vos_pm_header(abfd));

   return true;	/* gnu_gdb-135 */
}
#undef FREE

boolean 
vos_close_and_cleanup(abfd)
bfd *abfd;
{
  vaddrfile_fcb_type *pm_fcb_ptr;

  PRINT_ENTER("vos_close_and_cleanup");
  
  if (bfd_get_format (abfd) != bfd_object)
     return true;

  if ( (abfd->tdata.vos_data != (struct vos_data_struct *) NULL) 
      && (obj_vos_pm_fcb_ptr(abfd) != NULL) )
     {
       pm_fcb_ptr = obj_vos_pm_fcb_ptr(abfd);
       vaddrfile_done(pm_fcb_ptr);
     }

  vos_bfd_free_cached_info(abfd);

  return true;
}


boolean 
vos_bfd_copy_private_bfd_data (ibfd, obfd)
bfd *ibfd;
bfd *obfd;
{
  /* Does nothing  -- */
   PRINT_ENTER("vos_bfd_copy_private_bfd_data");

  return true;
}

boolean 
vos_bfd_print_private_bfd_data(abfd, filep)
bfd *abfd;
PTR filep;
{
 /* Does nothing */
 PRINT_ENTER("vos_bfd_print_private_bfd_data");

 return true;

}



/* Jump table defines.  Not all functions need VOS-specific implementations */

/* Defines for generic jump table entries */
#define vos_new_section_hook _bfd_generic_new_section_hook
#define vos_get_section_contents_in_window \
   _bfd_generic_get_section_contents_in_window

/* Defines for copy jump table entries */
#define vos_bfd_merge_private_bfd_data _bfd_generic_bfd_merge_private_bfd_data
#define vos_bfd_set_private_flags _bfd_generic_bfd_set_private_flags
#define vos_bfd_set_section_data  _bfd_generic_bfd_set_private_section_data
#define vos_bfd_set_private_symtab_data \
  _bfd_generic_bfd_set_private_symtab_data 
#define vos_bfd_copy_private_section_data \
 _bfd_generic_bfd_copy_private_section_data
#define vos_bfd_copy_private_symbol_data \
 _bfd_generic_bfd_copy_private_symbol_data

/* Defines for symbols jump table entries */
#define vos_get_lineno             _bfd_nosymbols_get_lineno
#define vos_find_nearest_line      _bfd_elf_find_nearest_line
#define vos_bfd_make_debug_symbol  _bfd_nosymbols_bfd_make_debug_symbol
#define vos_read_minisymbols       _bfd_generic_read_minisymbols
#define vos_minisymbol_to_symbol   _bfd_generic_minisymbol_to_symbol
#define vos_make_empty_symbol          _bfd_elf_make_empty_symbol
#define vos_print_symbol               bfd_elf_print_symbol
#define vos_get_symbol_info        _bfd_elf_get_symbol_info
#define vos_bfd_is_local_label_name _bfd_elf_is_local_label_name 

/* Defines for dynamic jump table entries */
#define vos_get_dynamic_reloc_upper_bound _bfd_nodynamic_get_dynamic_reloc_upper_bound
#define vos_canonicalize_dynamic_reloc _bfd_nodynamic_canonicalize_dynamic_reloc

const bfd_target bfd_elf32_hppa_vos_vec = 
{
   "vos",          /* name */
   bfd_target_vos_flavour,
   BFD_ENDIAN_BIG,          /* target byte order */
   BFD_ENDIAN_BIG,          /* target headers byte order */
  (HAS_RELOC | EXEC_P |          /* object flags */
   HAS_LINENO | HAS_DEBUG |
   HAS_SYMS | HAS_LOCALS),
  (SEC_CODE | SEC_DATA | SEC_ROM | SEC_HAS_CONTENTS
   | SEC_ALLOC | SEC_LOAD | SEC_RELOC),          /* section flags */
/* leading_symbol_char: is the first char of a user symbol
   predictable, and if so what is it */
  0,
  '/',                    /* ar_pad_char */
  14,                    /* ar_max_namelen */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,     /* data */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,     /* hdrs */
/* Check format routines */
  {_bfd_dummy_target,
   vos_object_p,          /* bfd_check_format */
   _bfd_dummy_target,
   _bfd_dummy_target
  },
/* Set format routines when a file is written */
  {
     bfd_false,       
     vos_mkobject,
     bfd_false,       
     bfd_false,       
  },
/* Write cached information into a file being written, at bfd_close */
  {
     bfd_false,       
     bfd_false,       
     bfd_false,       
     bfd_false,       
  },
 BFD_JUMP_TABLE_GENERIC(vos),
 BFD_JUMP_TABLE_COPY(vos),
 BFD_JUMP_TABLE_CORE(_bfd_nocore),
 BFD_JUMP_TABLE_ARCHIVE(_bfd_noarchive),
 BFD_JUMP_TABLE_SYMBOLS(vos),
 BFD_JUMP_TABLE_RELOCS(_bfd_norelocs),
 BFD_JUMP_TABLE_WRITE(_bfd_nowrite),
 BFD_JUMP_TABLE_LINK(_bfd_nolink),
 BFD_JUMP_TABLE_DYNAMIC(_bfd_nodynamic),

 (PTR) 0
};

const bfd_target bfd_elf32_i386_vos_vec = 
{
   "vos",          /* name */
   bfd_target_vos_flavour,
   BFD_ENDIAN_LITTLE,          /* target byte order */
   BFD_ENDIAN_LITTLE,          /* target headers byte order */
  (HAS_RELOC | EXEC_P |          /* object flags */
   HAS_LINENO | HAS_DEBUG |
   HAS_SYMS | HAS_LOCALS),
  (SEC_CODE | SEC_DATA | SEC_ROM | SEC_HAS_CONTENTS
   | SEC_ALLOC | SEC_LOAD | SEC_RELOC),          /* section flags */
/* leading_symbol_char: is the first char of a user symbol
   predictable, and if so what is it */
  0,
  '/',                    /* ar_pad_char */
  14,                    /* ar_max_namelen */
  bfd_getl64, bfd_getl_signed_64, bfd_putl64,
  bfd_getl32, bfd_getl_signed_32, bfd_putl32,
  bfd_getl16, bfd_getl_signed_16, bfd_putl16,     /* data */
  bfd_getl64, bfd_getl_signed_64, bfd_putl64,
  bfd_getl32, bfd_getl_signed_32, bfd_putl32,
  bfd_getl16, bfd_getl_signed_16, bfd_putl16,     /* hdrs */
/* Check format routines */
  {_bfd_dummy_target,
   vos_object_p,          /* bfd_check_format */
   _bfd_dummy_target,
   _bfd_dummy_target
  },
/* Set format routines when a file is written */
  {
     bfd_false,       
     vos_mkobject,
     bfd_false,       
     bfd_false,       
  },
/* Write cached information into a file being written, at bfd_close */
  {
     bfd_false,       
     bfd_false,       
     bfd_false,       
     bfd_false,       
  },
 BFD_JUMP_TABLE_GENERIC(vos),
 BFD_JUMP_TABLE_COPY(vos),
 BFD_JUMP_TABLE_CORE(_bfd_nocore),
 BFD_JUMP_TABLE_ARCHIVE(_bfd_noarchive),
 BFD_JUMP_TABLE_SYMBOLS(vos),
 BFD_JUMP_TABLE_RELOCS(_bfd_norelocs),
 BFD_JUMP_TABLE_WRITE(_bfd_nowrite),
 BFD_JUMP_TABLE_LINK(_bfd_nolink),
 BFD_JUMP_TABLE_DYNAMIC(vos),

 (PTR) 0
};



#else
#error CPU type not supported.
#endif /* defined (HOST_HPPAVOS) || defined (HOST_X86VOS) */

