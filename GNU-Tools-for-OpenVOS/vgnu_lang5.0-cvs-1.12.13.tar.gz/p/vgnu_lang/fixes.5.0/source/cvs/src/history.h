/*
 * Copyright (C) 2003-2005 The Free Software Foundation, Inc.
 *
 * Portions Copyright (C) 2003-2005 Derek Price, Ximbiot <http://ximbiot.com>,
 *                                  and others.
 *
 *    You may distribute under the terms of the GNU General Public License
 *    as specified in the README file that comes with the CVS source
 *    distribution.
 *
 * This is the header file for definitions and functions shared by history.c
 * with other portions of CVS.
 */

#ifndef HISTORY_H
# define HISTORY_H
#define ALL_HISTORY_REC_TYPES "TOEFWUPCGMAR"
#endif /* HISTORY_H */
