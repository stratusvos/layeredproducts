// { dg-do compile }

void foo()
{
  int i=1, x[i];
}

