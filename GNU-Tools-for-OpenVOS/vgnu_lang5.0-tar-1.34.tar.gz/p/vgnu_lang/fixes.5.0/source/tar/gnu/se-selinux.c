#include <config.h>
#define SE_SELINUX_INLINE _GL_EXTERN_INLINE
#include <selinux/selinux.h>
