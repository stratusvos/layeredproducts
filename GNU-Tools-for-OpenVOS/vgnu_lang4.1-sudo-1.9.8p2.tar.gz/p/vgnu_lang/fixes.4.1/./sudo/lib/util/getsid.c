/*  +++begin copyright+++ *******************************  */
/*                                                         */
/*  STRATUS CONFIDENTIAL INFORMATION                       */
/*  COPYRIGHT (c) 2015, 2017 Stratus Technologies          */
/*  Bermuda Ltd.                                           */
/*  All Rights Reserved.                                   */
/*                                                         */
/*  This  program  contains  confidential and proprietary  */
/*  information of Stratus Technologies Bermuda Ltd., and  */
/*  any reproduction, disclosure, or use in whole  or  in  */
/*  part  is  expressly  prohibited,  except  as  may  be  */
/*  specifically authorized by prior written agreement or  */
/*  permission of Stratus.                                 */
/*                                                         */
/*  +++end copyright+++ *********************************  */

/* Beginning of modification history */
/* Created 18-07-12 by Paul Green from s_c_getsid.c. */
/* End of modification history */

#define _POSIX_C_SOURCE 200809L
#pragma longmap_check, no_default_mapping, system_programming

#include "config.h"

#include <errno.h>
#include <unistd.h>

#ifndef HAVE_GETSID

/* getsid () returns the session id of the specified process,
   which must be the current process or a member of the same
   process group as the current process.  */

pid_t sudo_getsid (pid_t p_pid)
{
#include <voslib.h>

/* entries */

extern pid_t s$c_cv_vpid_to_ppid (const vos_pid_t pid);
extern int s$c_set_errno (const short int);
extern void s$get_session_id (vos_pid_t *);

/* automatic */

vos_pid_t vos_sid;

/* execution */

     if (p_pid == 0)
          s$get_session_id (&vos_sid);
     else if (p_pid == getpid ())
          s$get_session_id (&vos_sid);
     else return s$c_set_errno (ENOTSUP);

     return s$c_cv_vpid_to_ppid (vos_sid);
}
#endif /* HAVE_GETSID */
