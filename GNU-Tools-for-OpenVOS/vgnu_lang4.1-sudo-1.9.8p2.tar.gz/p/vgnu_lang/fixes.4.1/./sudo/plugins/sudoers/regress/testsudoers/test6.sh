#!/bin/sh
#
# Verify sudoers matching by uid.
#

: ${TESTSUDOERS=testsudoers}

exec 2>&1
$TESTSUDOERS -p ../../../../sudo/plugins/sudoers/regress/passwd -P ../../../../sudo/plugins/sudoers/regress/group root id <<EOF
#0 ALL = ALL
EOF

exit 0
