.. cmake-module:: ../../Modules/FindXercesC.cmake
