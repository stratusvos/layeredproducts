#!/bin/sh
#
# Test sudoers owner check
#

: ${TESTSUDOERS=testsudoers}

exec 2>&1
$TESTSUDOER -p ../../../../sudo/plugins/sudoers/regress/passwd -P ../../../../sudo/plugins/sudoers/regress/group -U 1 root id <<EOF
@include $TESTDIR/test2.inc
EOF

exit 0
