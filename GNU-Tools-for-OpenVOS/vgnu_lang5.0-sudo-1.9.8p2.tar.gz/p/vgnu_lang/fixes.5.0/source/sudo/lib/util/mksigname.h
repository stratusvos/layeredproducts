static char *sudo_sys_signame[(20 +1)];


    if (sudo_sys_signame[10] == ((void *)0))
 sudo_sys_signame[10] = "HUP";


    if (sudo_sys_signame[4] == ((void *)0))
 sudo_sys_signame[4] = "INT";


    if (sudo_sys_signame[18] == ((void *)0))
 sudo_sys_signame[18] = "QUIT";


    if (sudo_sys_signame[3] == ((void *)0))
 sudo_sys_signame[3] = "ILL";


    if (sudo_sys_signame[20] == ((void *)0))
 sudo_sys_signame[20] = "TRAP";


    if (sudo_sys_signame[1] == ((void *)0))
 sudo_sys_signame[1] = "ABRT";


    if (sudo_sys_signame[1] == ((void *)0))
 sudo_sys_signame[1] = "IOT";






    if (sudo_sys_signame[2] == ((void *)0))
 sudo_sys_signame[2] = "FPE";


    if (sudo_sys_signame[15] == ((void *)0))
 sudo_sys_signame[15] = "KILL";


    if (sudo_sys_signame[19] == ((void *)0))
 sudo_sys_signame[19] = "BUS";


    if (sudo_sys_signame[5] == ((void *)0))
 sudo_sys_signame[5] = "SEGV";
    if (sudo_sys_signame[17] == ((void *)0))
 sudo_sys_signame[17] = "PIPE";


    if (sudo_sys_signame[12] == ((void *)0))
 sudo_sys_signame[12] = "ALRM";


    if (sudo_sys_signame[6] == ((void *)0))
 sudo_sys_signame[6] = "TERM";






    if (sudo_sys_signame[9] == ((void *)0))
 sudo_sys_signame[9] = "IO";
    if (sudo_sys_signame[7] == ((void *)0))
 sudo_sys_signame[7] = "USR1";


    if (sudo_sys_signame[8] == ((void *)0))
 sudo_sys_signame[8] = "USR2";






    if (sudo_sys_signame[9] == ((void *)0))
 sudo_sys_signame[9] = "POLL";


    if (sudo_sys_signame[16] == ((void *)0))
 sudo_sys_signame[16] = "STOP";


    if (sudo_sys_signame[21] == ((void *)0))
 sudo_sys_signame[21] = "TSTP";


    if (sudo_sys_signame[14] == ((void *)0))
 sudo_sys_signame[14] = "CONT";


    if (sudo_sys_signame[13] == ((void *)0))
 sudo_sys_signame[13] = "CHLD";


    if (sudo_sys_signame[13] == ((void *)0))
 sudo_sys_signame[13] = "CLD";


    if (sudo_sys_signame[22] == ((void *)0))
 sudo_sys_signame[22] = "TTIN";


    if (sudo_sys_signame[23] == ((void *)0))
 sudo_sys_signame[23] = "TTOU";






    if (sudo_sys_signame[11] == ((void *)0))
 sudo_sys_signame[11] = "URG";
