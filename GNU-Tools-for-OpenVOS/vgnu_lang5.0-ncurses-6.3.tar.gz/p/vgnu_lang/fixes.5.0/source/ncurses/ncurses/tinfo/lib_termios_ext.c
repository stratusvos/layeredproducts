/* 
 * This file contains OS dependent routines for handling the vendor specific 
 * OPOST and IXTEN flags in the termios structure.
 *
 * Default versions of the encapsulation routines are at the back of this file.
 * Vendor specific routines should be included earlier in the file and should
 * define the appropriate feature macro to keep the default version from
 * compiling.
 */

#ifdef __VOS__

/* Vendor specific routines for the VOS operating system from Stratus
 * Technologies (stratus.com).
 */

/* -------------------------------------------------------------------
   Beginning of modification history - (most recent first)

      Date    Programmer          Description of change
    --------  ----------          ---------------------
    05-11-19  Herbie Robinson     Completed.
    01-02-13  Dan Pearl           Partially Written.

   End of modification history
-------------------------------------------------------------------*/

/* include */
#include <system_io_constants.incl.c>
#include <ttp_subrs_info.incl.c>
#include <ttp_subrs_entries.incl.c>
#include <window_term_opcodes.incl.c>
#include <window_term_info.incl.c>
#include <termios.h>
#include <output_sequence_codes.incl.c>
#include <function_key_codes.incl.c>
#include <video_request_defs.incl.c>
#include <os_error_codes.incl.c>
#include <os_return_codes.incl.c>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <curses.priv.h>
#include <tic.h>
#include <term.h>
#include <term_entry.h>

#define	FALSE		0
#define	TRUE		1
#define NOT_NULL(p)	(((void *) (p)) > ((void *) 1))
#define IS_NULL(p)	(((void *) (p)) <= ((void *) 1))
#define XCI		0x92

/* extern */

extern int s$c_get_portid_from_fildes(int fildes);

extern void s$control (short *port_id, short *opcode, short *control_info, 
		short *error_code);
		
extern void s$error (short *error_code, char_varying *caller, 
		char_varying *message_text);

extern int s$c_set_errno(int);

/* forward */

static void initialize_tables(TERMINAL *);
static int _nc_vos_get_window_size( short port_id, short *width, short *height );


/* local static used by all subroutines  */

static int tables_initialized = FALSE;

/* The following table indicates whether string capabilities are
   output, input keys or key labels.  */

#define	OUTPUT_CAPTYPE		0
#define INPUT_CAPTYPE		1
#define LABEL_CAPTYPE		2

static char strcap_type[STRCOUNT];

/* Subroutines.  */

/*
 * _nc_vendor_can_do_caps:
 *
 * This routine should return 1 if a call to _nc_opost_setup followed by
 * a call to _nc_iexten_setup will completely initialize the TERMINAL
 * structure if the TERMINAL structure has been passed in as all zeros.
 */

#define VENDOR_CAN_DO_CAPS_DEFINED

int
_nc_vendor_can_do_caps(void)
{
	return 1;
}

/*
 * _nc_opost_setup:
 *
 * This routine defines the output capabilities in the term structure.
 * It is possible for the user to split the input and output functionality 
 * (for instance, use a termcap entry for input, and window term generic
 * output.  Unreferenced output capabilities are cleared out.
 *
 * The expected sequence of events is that if some part of a terminfo file
 * is needed, it will have pre-initialized the term structure with the
 * appropriate value.  Then this routine is called to provide a fixup.
 *
 * If both _nc_opost_setup and _nc_iexten_setup are going to be called, 
 * _nc_opost_setup is called first.
 */

#define OPOST_SETUP_DEFINED


/* The generic output sequence that corresponds to an ncurses output sequence
   is always the same; therefore, we can statically allocate a complete set
   of output sequences the first time we are called and use them for
   all term structures over the entire program execution.
   The following table keeps track of the sequence strings and the 
   index into the ncurses string table for them.  */

typedef struct output_mapping_table
{
	int		curses_table_index;
	char *		curses_cap;
}
output_mapping_table;

static output_mapping_table 
output_caps[MAX_OUTPUT_SEQUENCES+1];


int
_nc_opost_setup(TERMINAL *cur_term, int p_fd, struct termios *tios)
{
	struct ttp_attribute_info attr_info;
	long		attribute_db = 0;
	short		code;
	short		cols;
	struct ttp_config_info config_info;
	long		configuration_db = 0;
	FLOW_CONTROL_INFO_V1 flow_info;
	int		j;
	short		opcode;
	long		output_db = 0;
	short		port_id;
	int		ret = 1;
	short		rows;
	int		standout_off = 0;
	int		standout_on = 0;
	short		supported[513];

/* program */

	if (!tables_initialized)
		initialize_tables(cur_term);

	/* Get the port */
	port_id = s$c_get_portid_from_fildes(p_fd);
	if (port_id <= 0)
	{
		s$c_set_errno (EBADF);
		goto failure;
	}

	if (_nc_vos_get_window_size(port_id, &cols, &rows) < 0)
		goto failure;

	/* Get capability information from TTY db for this file */

	/* Get the configuration db id */
	s$ttp_get_configuration_db( &port_id, &configuration_db, &code);
	if (code)
	{
		s$c_set_errno (code);
		goto failure;
	}

	config_info.version = TTP_CONFIG_INFO_VERSION_1;

	s$ttp_get_configuration_info( &configuration_db, &config_info, &code);
	if (code)
	{
		s$c_set_errno (code);
		goto failure;
	}

	/* Get the output db.  */
	s$ttp_get_output_db( &port_id, &output_db, &code);
	if (code)
	{
		s$c_set_errno (code);
		goto failure;
	}

	s$ttp_get_supported_output_seqs(&output_db, supported+1);

	if ( supported[ENTER_GRAPHICS_MODE_SEQ] 
	  && supported[LEAVE_GRAPHICS_MODE_SEQ] )
	{
		supported[0] = TRUE;
	}
	else
	{
		supported[0] = FALSE;
		supported[ENTER_GRAPHICS_MODE_SEQ] = FALSE;
		supported[LEAVE_GRAPHICS_MODE_SEQ] = FALSE;
	}

	/* Get the attribute db id */
	s$ttp_get_generic_attr_db( &port_id, &attribute_db, &code);
	if (code)
	{
		s$c_set_errno (code);
		goto failure;
	}

	attr_info.version = TTP_ATTRIBUTE_INFO_VERSION_1;

	s$ttp_get_attribute_info( &attribute_db, &attr_info, &code);
	if (code)
	{
		s$c_set_errno (code);
		goto failure;
	}

	if (!(attr_info.v1_ai.supported_directly & BLANKED))
	{
		supported[BLANK_ON_SEQ] = FALSE;
		supported[BLANK_OFF_SEQ] = FALSE;
	}

	if (!(attr_info.v1_ai.supported_directly & LOW_INTENSITY))
	{
		supported[HALF_INTENSITY_ON_SEQ] = FALSE;
		supported[HALF_INTENSITY_OFF_SEQ] = FALSE;
	}

	if (!(attr_info.v1_ai.supported_directly & STRIKEOUT))
	{
		supported[STRIKEOUT_ON_SEQ] = FALSE;
		supported[STRIKEOUT_OFF_SEQ] = FALSE;
	}

	if (!(attr_info.v1_ai.supported_directly & BLINKING))
	{
		supported[BLINK_ON_SEQ] = FALSE;
		supported[BLINK_OFF_SEQ] = FALSE;
	}
	else
	{
		standout_on = BLINK_ON_SEQ;
		standout_off = BLINK_OFF_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & UNDERLINED))
	{
		supported[UNDERSCORE_ON_SEQ] = FALSE;
		supported[UNDERSCORE_OFF_SEQ] = FALSE;
	}
	else
	{
		standout_on = UNDERSCORE_ON_SEQ;
		standout_off = UNDERSCORE_OFF_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & RIBBON_COLOR))
	{
		supported[ALTERNATE_RIBBON_COLOR_SEQ] = FALSE;
		supported[STANDARD_RIBBON_COLOR_SEQ] = FALSE;
	}
	else
	{
		standout_on = ALTERNATE_RIBBON_COLOR_SEQ;
		standout_off = STANDARD_RIBBON_COLOR_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & BOLDFACE))
	{
		supported[BOLDFACE_ON_SEQ] = FALSE;
		supported[BOLDFACE_OFF_SEQ] = FALSE;
	}
	else
	{
		standout_on = BOLDFACE_ON_SEQ;
		standout_off = BOLDFACE_OFF_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & HIGH_INTENSITY))
	{
		supported[HI_INTENSITY_ON_SEQ] = FALSE;
		supported[HI_INTENSITY_OFF_SEQ] = FALSE;
	}
	else
	{
		standout_on = HI_INTENSITY_ON_SEQ;
		standout_off = HI_INTENSITY_OFF_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & INVERSE))
	{
		supported[INVERSE_VIDEO_ON_SEQ] = FALSE;
		supported[INVERSE_VIDEO_OFF_SEQ] = FALSE;
	}
	else
	{
		standout_on = INVERSE_VIDEO_ON_SEQ;
		standout_off = INVERSE_VIDEO_OFF_SEQ;
	}

	if (!(attr_info.v1_ai.supported_directly & STANDOUT))
	{
		supported[STANDOUT_ON_SEQ] = FALSE;
		supported[STANDOUT_OFF_SEQ] = FALSE;
	}

	/* Initialize the term structure if it's not already initialized.  */

	if IS_NULL(cur_term->type.Booleans)
	{
		if ((cur_term->type.Booleans = typeCalloc(char, BOOLCOUNT)) == 0)
		{
			s$c_set_errno (e$no_alloc_user_heap);
			goto failure;
		}

		cur_term->type.num_Booleans = BOOLCOUNT;
 	}

	if IS_NULL(cur_term->type.Numbers)
	{
		if ((cur_term->type.Numbers = typeCalloc(short, NUMCOUNT)) == 0)
		{
			s$c_set_errno (e$no_alloc_user_heap);
			goto failure;
		}

		cur_term->type.num_Numbers = NUMCOUNT;
 	}

	if IS_NULL(cur_term->type.Strings)
	{
		if ((cur_term->type.Strings = typeCalloc(char *, STRCOUNT)) == 0)
		{
			s$c_set_errno (e$no_alloc_user_heap);
			goto failure;
		}

		cur_term->type.num_Strings = STRCOUNT;

		for_each_string(j, &cur_term->type) 
		{
			if (strcap_type[j] == OUTPUT_CAPTYPE)
			{
				cur_term->type.Strings[j] = ABSENT_STRING;
			}
		}
 	}


	/************* Boolean capabilities **************************/

	for_each_boolean(j, &cur_term->type)
	{
		cur_term->type.Booleans[j] = FALSE;
	}

	/* auto_left_margin:  cub1 wraps from column 0 to last column */
	auto_left_margin = 	FALSE;

	/* auto_right_margin:  terminal has automatic margins */
	auto_right_margin = FALSE;

	/* hard_copy:  hardcopy terminal */
	if (config_info.v1_ci.tte_device_type ==  TTP_PRINTER_TYPE)
		hard_copy = TRUE;

	/* has_status_line:  has extra status line */
	has_status_line = ( supported[RESET_25TH_LINE_SEQ] 
					 && supported[START_25TH_LINE_SEQ] 
					 && supported[END_25TH_LINE_SEQ]);

	/* safe to move while in standout mode */
	move_standout_mode = TRUE;

	/* xon_xoff:  terminal uses xon/xoff handshaking this is mostly for
	   use by the application.  Ncurses does use it to determine
           whether to do padding, but we don't put padding operations 
	   in the capabilities we generate; so, that doesn't matter.  */

	flow_info.version = 1;
	opcode = TERM_GET_OUTPUT_FLOW_INFO_OPCODE;
	s$control(&port_id, &opcode, &flow_info.version, &code);
	xon_xoff = (code == 0 && flow_info.flow_type == XON_XOFF);

	/* no_pad_char:  pad character does not exist */
	no_pad_char = TRUE;

	/* non_dest_scroll_region:  scrolling region is non-destructive */
	non_dest_scroll_region = FALSE;


	/* Numeric capabilities */

	for_each_number(j, &cur_term->type)
	{
		cur_term->type.Numbers[j] = ABSENT_NUMERIC;
	}

	/* columns: number of columns in a line */
	/* lines: number of lines on screen or page */
	columns = cols;
	lines = rows;

	/* width_status_line: number of columns in status line */
	width_status_line = cols;

	/* lines_of_memory: lines of memory if > line. 0 means varies */
	lines_of_memory = ABSENT_NUMERIC;

	/* magic_cookie_glitch: number of blank characters left by smso or 
	   rmso.  The actual ncurses code checks for this being > zero,
	   but some applications check for > ABSENT_NUMERIC. */
	magic_cookie_glitch = ABSENT_NUMERIC;

	/* String capabilities */

	for_each_string(j, &cur_term->type) 
	{
		if (strcap_type[j] == OUTPUT_CAPTYPE)
		{
			cur_term->type.Strings[j] = ABSENT_STRING;
		}
	}

	for(j = 0; j <= MAX_OUTPUT_SEQUENCES; j++)
	{
		int ix = output_caps[j].curses_table_index;

		if (ix >= 0 && supported[j])
		{
			cur_term->type.Strings[ix] = 
				output_caps[j].curses_cap;
		}
	}

	if (!(attr_info.v1_ai.supported_directly & STANDOUT))
	{
		int ix_on = output_caps[STANDOUT_ON_SEQ].curses_table_index;
		int ix_off = output_caps[STANDOUT_OFF_SEQ].curses_table_index;

		if (ix_on && ix_off && standout_on && standout_off)
		{
			cur_term->type.Strings[ix_on] = 
				output_caps[standout_on].curses_cap;
			cur_term->type.Strings[ix_off] = 
				output_caps[standout_off].curses_cap;
		}
	}

cleanup:
	if (attribute_db)
		s$ttp_free_db (&attribute_db);		/* Free some memory */

	if (output_db)
		s$ttp_free_db (&output_db);		/* Free some memory */

	if (configuration_db)
		s$ttp_free_db (&configuration_db);	/* Free some memory */

	return ret;

failure:
	ret = 0;
	goto cleanup;
}

/* _nc_iexten_setup:
 *
 * This routine defines the input capabilities in the term structure
 * (those denoted by key_ and lab_ names),
 * It is possible for the user to split the VOS ttp functionality (for
 * instance, use a termcap entry for input, and window term generic 
 * output.
 *
 * The expected sequence of events is that if some part of a terminfo file
 * is needed, it will have pre-initialized the term structure with the
 * appropriate value.  Then this routine is called to provide a fixup.
 *
 * If both _nc_opost_setup and _nc_iexten_setup are going to be called, 
 * _nc_opost_setup is called first.
 */

#define IEXTEN_SETUP_DEFINED

/* local static variables to ixten_setup:  */

/* vos to ncurses table:
 *
 * This table drives the translations from VOS input constructs to 
 * ncurses key definitions.  The unshifted version of the ncurses
 * key must be given for each entry.  The other entries are optional.  */

typedef struct MAP_ENTRY
{
	short	req;	/* vos generic request number.  */
	short	key;	/* vos function key number.  */
	short	to[2];	/* to[0] == unshifted, to[1] == shifted */
} MAP_ENTRY;

static MAP_ENTRY    vos_to_ncurses_map[] = {
	/* The function keys must come first.  */
    { F0_REQ,                   F0_KEY,              { KEY_F0,        0 } },
    { F1_REQ,                   F1_KEY,              { KEY_F(1),      0 } },
    { F2_REQ,                   F2_KEY,              { KEY_F(2),      0 } },
    { F3_REQ,                   F3_KEY,              { KEY_F(3),      0 } },
    { F4_REQ,                   F4_KEY,              { KEY_F(4),      0 } },
    { F5_REQ,                   F5_KEY,              { KEY_F(5),      0 } },
    { F6_REQ,                   F6_KEY,              { KEY_F(6),      0 } },
    { F7_REQ,                   F7_KEY,              { KEY_F(7),      0 } },
    { F8_REQ,                   F8_KEY,              { KEY_F(8),      0 } },
    { F9_REQ,                   F9_KEY,              { KEY_F(9),      0 } },
    { F10_REQ,                  F10_KEY,             { KEY_F(10),     0 } },
    { F11_REQ,                  F11_KEY,             { KEY_F(11),     0 } },
    { F12_REQ,                  F12_KEY,             { KEY_F(12),     0 } },
    { F13_REQ,                  F13_KEY,             { KEY_F(13),     0 } },
    { F14_REQ,                  F14_KEY,             { KEY_F(14),     0 } },
    { F15_REQ,                  F15_KEY,             { KEY_F(15),     0 } },
    { F16_REQ,                  F16_KEY,             { KEY_F(16),     0 } },
    { F17_REQ,                  F17_KEY,             { KEY_F(17),     0 } },
    { F18_REQ,                  F18_KEY,             { KEY_F(18),     0 } },
    { F19_REQ,                  F19_KEY,             { KEY_F(19),     0 } },
    { F20_REQ,                  F20_KEY,             { KEY_F(20),     0 } },
    { F21_REQ,                  F21_KEY,             { KEY_F(21),     0 } },
    { F22_REQ,                  F22_KEY,             { KEY_F(22),     0 } },
    { F23_REQ,                  F23_KEY,             { KEY_F(23),     0 } },
    { F24_REQ,                  F24_KEY,             { KEY_F(24),     0 } },
    { F25_REQ,                  F25_KEY,             { KEY_F(25),     0 } },
    { F26_REQ,                  F26_KEY,             { KEY_F(26),     0 } },
    { F27_REQ,                  F27_KEY,             { KEY_F(27),     0 } },
    { F28_REQ,                  F28_KEY,             { KEY_F(28),     0 } },
    { F29_REQ,                  F29_KEY,             { KEY_F(29),     0 } },
    { F30_REQ,                  F30_KEY,             { KEY_F(30),     0 } },
    { F31_REQ,                  F31_KEY,             { KEY_F(31),     0 } },
    { F32_REQ,                  -1,                  { KEY_F(32),     0 } },
    { BREAK_CHAR_REQ,           BREAK_KEY,           { KEY_BREAK,     0 } },
    { -1,                       -1,                  { KEY_SRESET,    0 } },
    { -1,                       -1,                  { KEY_RESET,     0 } },
    { -1,                       -1,                  { KEY_SRESET,    0 } },
    { DOWN_REQ,                 CURSOR_DOWN_KEY,     { KEY_DOWN,      0 } },
    { UP_REQ,                   CURSOR_UP_KEY,       { KEY_UP,        0 } },
    { LEFT_REQ,                 CURSOR_LEFT_KEY,     { KEY_LEFT,      KEY_SLEFT } },
    { RIGHT_REQ,                CURSOR_RIGHT_KEY,    { KEY_RIGHT,     KEY_SRIGHT } },
    { GOTO_UP_REQ,              HOME_KEY,            { KEY_HOME,      KEY_SHOME } },
    { ERASE_CHAR_REQ,           BACKSPACE_KEY,       { KEY_BACKSPACE, 0 } },
    { -1,                       DELETE_LINE_KEY,     { KEY_DL,        KEY_SDL } },
    { -1,                       INSERT_LINE_KEY,     { KEY_IL,        0 } },
    { DELETE_CHAR_REQ,          DEL_KEY,             { KEY_DC,        KEY_SDC } },
    { -1,                       INSERT_KEY,          { KEY_IC,        KEY_SIC } },
    { ERASE_FIELD_REQ,          CLEAR_SCREEN_KEY,    { KEY_CLEAR,     0 } },
    { -1,                       CLEAR_TO_EOS_KEY,    { KEY_EOS,       0 } },
    { DELETE_RIGHT_REQ,         CLEAR_TO_EOL_KEY,    { KEY_EOL,       KEY_SEOL } },
    { SCROLL_MULTIPLE_DOWN_REQ, SCROLL_FORWARD_KEY,  { KEY_SF,        0 } },
    { SCROLL_MULTIPLE_UP_REQ,   SCROLL_BACKWARD_KEY, { KEY_SR,        0 } },
    { NEXT_SCREEN_REQ,          NEXT_PAGE_KEY,       { KEY_NPAGE,     0 } },
    { PREVIOUS_SCREEN_REQ,      PREV_PAGE_KEY,       { KEY_PPAGE,     0 } },
    { -1,                       SET_TAB_KEY,         { KEY_STAB,      0 } },
    { -1,                       CLEAR_TAB_KEY,       { KEY_CTAB,      0 } },
    { -1,                       CLEAR_ALL_TABS_KEY,  { KEY_CATAB,     0 } },
    { ENTER_REQ,                ENTER_KEY,           { KEY_ENTER,     0 } },
    { PRINT_REQ,                PRINT_KEY,           { KEY_PRINT,     KEY_SPRINT } },
    { -1,                       LOWER_LEFT_KEY,      { KEY_LL,        0 } },
    { -1,                       KEYPAD_7_KEY,        { KEY_A1,        0 } },
    { -1,                       KEYPAD_9_KEY,        { KEY_A3,        0 } },
    { -1,                       KEYPAD_5_KEY,        { KEY_B2,        0 } },
    { -1,                       KEYPAD_1_KEY,        { KEY_C1,        0 } },
    { -1,                       KEYPAD_3_KEY,        { KEY_C3,        0 } },
    { BACK_TAB_REQ,             BACK_TAB_KEY,        { KEY_BTAB,      0 } },
    { -1,                       BEGIN_KEY,           { KEY_BEG,       KEY_SBEG } },
    { CANCEL_REQ,               CANCEL_KEY,          { KEY_CANCEL,    KEY_SCANCEL } },
    { -1,                       CLOSE_KEY,           { KEY_CLOSE,     0 } },
    { -1,                       COMMAND_KEY,         { KEY_COMMAND,   KEY_SCOMMAND } },
    { -1,                       COPY_KEY,            { KEY_COPY,      KEY_SCOPY } },
    { -1,                       CREATE_KEY,          { KEY_CREATE,    KEY_SCREATE } },
    { GOTO_DOWN_REQ,            END_KEY,             { KEY_END,       KEY_SEND } },
    { EXIT_FORM_REQ,            EXIT_KEY,            { KEY_EXIT,      KEY_SEXIT } },
    { QUIT_REQ,                 EXIT_KEY,            { KEY_EXIT,      KEY_SEXIT } },
    { SEARCH_DOWN_REQ,          FIND_KEY,            { KEY_FIND,      KEY_SFIND } },
    { HELP_REQ,                 HELP_KEY,            { KEY_HELP,      KEY_SHELP } },
    { -1,                       MARK_KEY,            { KEY_MARK,      0 } },
    { -1,                       MESSAGE_KEY,         { KEY_MESSAGE,   KEY_SMESSAGE } },
    { -1,                       MOVE_KEY,            { KEY_MOVE,      KEY_SMOVE } },
    { -1,                       NEXT_KEY,            { KEY_NEXT,      KEY_SNEXT } },
    { -1,                       OPEN_KEY,            { KEY_OPEN,      0 } },
    { -1,                       OPTIONS_KEY,         { KEY_OPTIONS,   KEY_SOPTIONS } },
    { -1,                       PREVIOUS_KEY,        { KEY_PREVIOUS,  KEY_SPREVIOUS } },
    { -1,                       REDO_KEY,            { KEY_REDO,      KEY_SREDO } },
    { -1,                       REFERENCE_KEY,       { KEY_REFERENCE, 0 } },
    { REDISPLAY_REQ,            REFRESH_KEY,         { KEY_REFRESH,   0 } },
    { -1,                       REPLACE_KEY,         { KEY_REPLACE,   KEY_SREPLACE } },
    { -1,                       RESTART_KEY,         { KEY_RESTART,   0 } },
    { -1,                       RESUME_KEY,          { KEY_RESUME,    KEY_SRSUME } },
    { SAVE_REQ,                 SAVE_KEY,            { KEY_SAVE,      KEY_SSAVE } },
    { -1,                       SELECT_KEY,          { KEY_SELECT,    0 } },
    { SUSPEND_PROCESS_REQ,      SUSPEND_KEY,         { KEY_SUSPEND,   KEY_SSUSPEND } },
    { -1,                       UNDO_KEY,            { KEY_UNDO,      KEY_SUNDO } },
    { -1,                       -1,                  { KEY_MOUSE,     0 } },
    { WINDOW_RESIZED_REQ,       -1,                  { KEY_RESIZE,    0 } },
    { -1,                       -1,                  { KEY_RESET,     0 } },
    { IGNORE_REQ,               IGNORE_KEY,          { KEY_IGNORE,    0 } },
    { -1,                       -1,                  { KEY_EIC,       0 } } 
};

#define	VOS_TO_NCURSES_MAP_COUNT  	\
		((int) (sizeof(vos_to_ncurses_map)/sizeof(MAP_ENTRY)))

#define   FKEY_OFFSET         16384

/* The input strings for particular VOS generic requests and function keys 
   are always the same; therefore, we can statically allocate a complete set
   of strings the first time we are called and use them for
   all term structures over the entire program execution.
   The following tables keeps track of the sequence strings for vos function
   keys and generic input sequences.  */

static char *
input_key_cap[2][HB_FUNCTION_KEYS+1];

static char *
input_req_cap[HB_REQS+1];


/* The following table provides the ncurses Strings index for 
   an ncurses key number.  */

static short
key_str_index[KEY_MAX];

/* The following table privides the ncurses Strings index for 
   the labels for F0-F10.  */

static int 
label_index[11];

/* The following table retains information for generating legend
   strings for F0-F10.  */

typedef struct $longmap
{
     short     keycode;
     short     legend_instance;
}
LABEL_TABLE_ENTRY;

/* The following structure contains the global variables shared by 
   _nc_iexten_setup and the subroutines it calls.  */

typedef struct $longmap
{
    long		keyboard_db;
    long		input_db;
    TERMINAL		*termp;
    char_varying(32)	section_name;
    char		ncurses_key_defined[KEY_MAX];
    LABEL_TABLE_ENTRY	label_table[11];
    short		defined_keys[512];
    short		used_keys[512];
} 
iexten_setup_globals;

/* Forward declarations to the subroutines that use the globals.  */

static void get_generic_req_components(iexten_setup_globals *, short p_req_no, 
		short p_def_no, short p_max, short *p_nump, 
		short * p_components, short *p_codep);
static void insert_keys (iexten_setup_globals *, int p_keycode, int p_ix);
static int insert_req (iexten_setup_globals *, int p_req_no, int p_ncurses_key, 
		int legend_inst);
static void get_legend (iexten_setup_globals *gp,
		short p_label_index, short p_max, short *p_nump, 
		char *p_string, short *p_codep);
static int set_cap_table (iexten_setup_globals *, char *cap_string, 
		int p_keycode, int p_ncurses_key, int generate_legend);

int
_nc_iexten_setup(TERMINAL *termp, int p_fd, struct termios *tios)
{
    short	code;
    short	defined_reqs[2048];
    iexten_setup_globals g;
    int		j;
    unsigned int labeltextlen = 0;
    char *	labeltextp = NULL;
    short	opcode;
    short	port = s$c_get_portid_from_fildes(p_fd);
    int		ret = 1;

    g.input_db = 0;
    g.keyboard_db = 0;
    g.termp = termp;

    /* Get the port */
    if (port <= 0)
    {
	s$c_set_errno (EBADF);
	return 0;
    }

    if (!tables_initialized)
	initialize_tables(termp);

    /* Reset the string capabilities for keys and legends */

    for_each_string(j, &termp->type) 
    {
	if (strcap_type[j] != OUTPUT_CAPTYPE)
	{
	    termp->type.Strings[j] = ABSENT_STRING;
	}
    }

    for (j = 0; j < KEY_MAX; j++)
	g.ncurses_key_defined[j] = 0;

    for (j = 0; j < 11; j++)
    {
	g.label_table[j].keycode = -1;
	g.label_table[j].legend_instance = 0;
    }

    /* Get the ttp input database.  */

    s$ttp_get_input_db (&port, &g.input_db, &code);
    if (code)
	goto failure;

    /*  Always need keyboard db for legends, may need it
	for function keys.  */

    s$ttp_get_keyboard_db (&port, &g.keyboard_db, &code);
    if (code)
	goto failure;

    /* Find out which generic requests are implemented.
       Use the current input section obtained from the driver.  */

    opcode = TERM_GET_INPUT_SECTION_OPCODE;
    s$control(&port, &opcode, &g.section_name.len, &code);
    if (code)
	goto failure;

    s$ttp_get_defined_input_reqs (&g.input_db, &g.section_name, 
			    defined_reqs, &code);
    if (code)
	goto failure;

    /* If we are using function keys, the first thing we want
       to do is see if we have a binding to the VOS function
       key description.  */

    if (tios->c_lflag & _VOS_IFKEY)
    {
	int key;
	int pass;
	int shift;

	s$ttp_get_defined_keys(&g.keyboard_db, g.defined_keys);

	/* Zero the map of keys we are using.  */
	for (j = 0; j < 512; j++)
	    g.used_keys[j] = 0;


	for (j = 0; j < VOS_TO_NCURSES_MAP_COUNT; j++)
	{
	    key = vos_to_ncurses_map[j].key;

	    if (key >= 0 && (g.defined_keys[key] & 0x3))
	    {
		insert_keys(&g, key + FKEY_OFFSET, j);
	    }
	}

	/* Expand the generic requests for any keys we don't already have.  */

	for (j = 0; j < VOS_TO_NCURSES_MAP_COUNT; j++)
	{
	    int req = vos_to_ncurses_map[j].req;

	    if ( req >= 0 && defined_reqs[req] )
	    {
		insert_keys(&g, req, j);
	    }
	}

	/* We can pick arbitrary keys for f0 through f10, because
	   we can have any label we want for them.  */

	for (pass = 0; pass < 2; pass++)
	{
	    shift = 0;
	    key = 0;

	    for (j = 0; j < 11; j++)
	    {
		int to = vos_to_ncurses_map[j].to[0];

		if ( !g.ncurses_key_defined[to] )
		{
		    /* Find an unused key. */

		    for ( ; shift < 7; shift++ )
		    {
			short mask = (0x1 << shift);

			for ( ; key < 512; key++ )
			{
			    if ( g.defined_keys[key] 
			       & ~g.used_keys[key] 
			       & mask )
			    {
				/* The misc keys are often wierd
				   and or on the numeric keypad and
				   awkward to use.  Don't use 'em 
				   if we don't have to.  */

				if ( pass == 0 
					 && key >= MISC_0_KEY
					 && key <= MISC_15_KEY )
				    continue;

				if (set_cap_table (&g, 
						input_key_cap[shift][key],
						shift*SHIFT_MULTIPLIER
                                                   + key
                                                   + FKEY_OFFSET, 
						to, 1) )
				    goto found_key;
			    }
			}
		    }

		    /* If we drop out, we don't have any more keys. */
		    break;

		found_key:;
		}
	    }
	}
    }
    else
    {
	short     cur_prio[33];
	short     definition_no[2048];
	short     generic_req[33];
	int       pass;
	int       scanx;
	short     vos_req_to_ncurses_key[2048];

	/* Zero the result.  */
	memset( (char *) vos_req_to_ncurses_key, 0, 
		sizeof(vos_req_to_ncurses_key) );
	memset( (char *) definition_no, 0, sizeof(definition_no) );

	/* Assign all the generic requests that have a functional mapping
           that matches it's function key translation.  */

	for (scanx = 0; scanx < VOS_TO_NCURSES_MAP_COUNT; scanx++)
	{
	    int to = vos_to_ncurses_map[scanx].to[0];
	    int req;

	    if ( (req = vos_to_ncurses_map[scanx].req) >= 0
	      && defined_reqs[req] )
	    {
		short components[127];
		short def_no = 1;
		short max = 127;
		short num = 127;

		for( def_no = 1; ; def_no++ )
		{
		    get_generic_req_components( &g, scanx, def_no, 
				       max, &num, components, 
				       &code);
		    if (code || num <= 0)
			break;

		    if ( num == 1 && components[0] 
					== vos_to_ncurses_map[scanx].key
						 + FKEY_OFFSET )
		    {
			if (insert_req(&g, req, to, 1))
			    vos_req_to_ncurses_key[req] = to;

			break;
		    }
		}
	    }
	}


	/* Figure out how many components are in the generic input 
	   sequences that remain unused.  */

	for (j = 0; j < 2048; j++)
	{
	    short components[127];
	    short def_no = 1;
	    short max = 127;
	    short min = 127;
	    short min_def_no = 1;
	    short num = 127;

	    definition_no[j] = 1;

	    if ( !defined_reqs[j]
	      || vos_req_to_ncurses_key[j])
		continue;

	    for( def_no = 1; ; def_no++ )
	    {
		get_generic_req_components( &g, j, def_no, max, &num, 
						components, &code);
		if (code || num <= 0)
		    break;

		if (num >= min)
		    continue;

		min = num;
		min_def_no = def_no;
	    }

	    defined_reqs[j] = min;
	    definition_no[j] = min_def_no;
	}

	/* Now, let's try to find as many function keys as we can.
	   Ncurses function keys 0 through 10 can be assigned to any
           function key.  The other ones can only be assigned to
           themselves.
	   Cur_shift indicates how good this assignment is (lower values
	   are better).  */

	for (j = 0; j < 33; j++)
	{
	    cur_prio[j] = (LAST_SHIFT+1)*3;
	    generic_req[j] = -1;
	}

	for (pass = 0; pass < 3; pass++)
	{
	    short one_more_time = 0;
	    short req_no;

	    for (req_no = 0; req_no < 2048; req_no++)
	    {
		if ( defined_reqs[req_no] == 1     /* Exactly one comp. */
		  && vos_req_to_ncurses_key[req_no] == 0)
		{
		    short component[2];
		    int key;
		    short max = 2;
		    short num;
		    int shift;

		    /* See if this request is defined to be exactly 
		       one key. */

		    get_generic_req_components( &g, req_no, 
					definition_no[req_no], max, &num, 
					component, &code);

		    if (code || num != 1 || component[0] < FKEY_OFFSET )
			continue;

		    component[0] -= FKEY_OFFSET;

		    shift = (component[0] >> 9);
		    key = (component[0] & 0x1FF);

		    switch(pass)
		    {
		    case 0:
			/* We only care about function keys, 
			   on first pass. */

			if ( key < F0_KEY || key >= F31_KEY )
			    continue;

			/* Pick the key that matches this fkey, or it's
			   shifted variant.  */

			key -= F0_KEY;

			if (key >= 11 && shift > 0)
			     continue;
			break;

		    case 1:
			/* We only care about misc keys, on second pass. */
			if (key < MISC_0_KEY || key > MISC_15_KEY)
			    continue;

			key -= MISC_0_KEY;

			if (key >= 11 && shift > 0)
			     continue;

			shift += (LAST_SHIFT+1);
			break;

		    case 2:
		    default:
			shift += (LAST_SHIFT+1)*2;
			for (key = 0; 
			    key < 11 && cur_prio[key] <= shift; 
			    key++);

			if (key >= 11)
			    continue;
		    }

		    if (g.ncurses_key_defined[KEY_F(key)])
			continue;

		    if (cur_prio[key] > shift)
		    {
			/* We have a better key.  */

			if (generic_req[key] >= 0)
			{
			    int old_req = generic_req[key];

			    /* This generic request is no longer
			       assigned.  */

			    vos_req_to_ncurses_key[old_req] = 0;

			    if ( req_no > generic_req[key] 
			      && key < 32 )
				one_more_time = 1;
			}

			cur_prio[key] = shift;
			generic_req[key] = req_no;
			vos_req_to_ncurses_key[req_no] = KEY_F(key);
		    }
		}
	    }

	    /* Keep going if we have unassigned keys after the 3rd 
	       pass.  */

	    if (pass >= 2 && one_more_time)
		pass = 1;
	}

	/* Now that we have found the best function keys, insert them. */

	for( j = 0; j < 33; j++ )
	{
	    int req_no = generic_req[j];

	    if (req_no >= 0)
	    {
		int to = KEY_F(j);

		if (insert_req(&g, req_no, to, definition_no[req_no]))
		    vos_req_to_ncurses_key[req_no] = to;
	    }
	}

	/* Assign all the generic requests that have a functional mapping.  */

	for (scanx = 0; scanx < VOS_TO_NCURSES_MAP_COUNT; scanx++)
	{
	    int to = vos_to_ncurses_map[scanx].to[0];
	    int req;

	    if ( (req = vos_to_ncurses_map[scanx].req) >= 0
	      && defined_reqs[req] )
	    {
		if (insert_req(&g, req, to, 1))
		    vos_req_to_ncurses_key[req] = to;
	    }
	}

    }

    /* Now, we have to build the labels for F0-F10.  This is a two pass
       algorithm:  The first pass figures out how big they are and the 
       second pass fills in the text.  */

    for(j = 0; j < 2; j++)
    {
	int lx;
	unsigned int tx = 0;
	char_varying(32) term_name;

	/* If the terminal type name isn't already there, insert that, too. */

	if IS_NULL(termp->type.term_names)
	{
	    if (labeltextp)
	    {
		size_t nx;

		strcpy_nstr_vstr(labeltextp+tx, &term_name);

		/* Replace '|' with something else ('|' divides
		   multiple terminal type names in ncurses). */

		for(nx = 0; nx < strlen_vstr(&term_name); nx++)
		{
			if (labeltextp[tx+nx] == '|')
				labeltextp[tx+nx] = ' ';
		}

		termp->type.term_names = labeltextp+tx;
	    }
	    else
	    {
		opcode = TERM_GET_TERMINAL_TYPE_OPCODE;
		s$control(&port, &opcode, &term_name.len, &code);
		if (code)
		    strcpy_vstr_nstr(&term_name, "unknown!");
	    }

	    tx += strlen_vstr(&term_name) + 1;
	}

	for(lx = 0; lx < 11; lx++)
	{
	    char textbuf[129];
	    char *bufp = (labeltextp) ? labeltextp+tx : textbuf;
	    short len;
	    unsigned int maxlen = 
			(labeltextp) ? labeltextlen-tx-1 : sizeof(textbuf)-1;

	    get_legend (&g, lx, maxlen, &len, bufp, &code);
	    if (code || len <= 0)
		continue;

	    if (labeltextp)
	    {
		bufp[len] = '\0';
		termp->type.Strings[label_index[lx]] = bufp;
	    }

	    tx += len + 1;
	}

	if (j == 0)
	{
	    /* Allocate storage at the end of the first pass.  */
	    if (tx <= 0)
		break;

	    FreeIfNeeded(termp->type._vos_strings);

	    labeltextlen = tx;
	    labeltextp = typeCalloc(char, labeltextlen);
	    if (!labeltextp)
		break;

	    termp->type._vos_strings = labeltextp;
	}
    }

cleanup:
    if (g.input_db)
	s$ttp_free_db (&g.input_db);

    if (g.keyboard_db)
	s$ttp_free_db (&g.keyboard_db);

    return ret;

failure:
    ret = 0;
    goto cleanup;
}

#define IEXTEN_INIT_KEYTRY_DEFINED

/*
 * _nc_iexten_init_keytry:
 *
 * This routine is provided for implementations to add IEXTEN dependent
 * strings directly to the keytry.  It should be used if the implementation
 * supports more than one mapping to a given KEY_ value.
 * At present, we will use it to add the automatically generated VOS
 * generic requests that happen even if they are not in the ttp and 
 * should not over-ride what is in the ttp.
 */

void
_nc_iexten_init_keytry(void)
{
    _nc_add_to_try(&(SP->_keytry), input_req_cap[REDISPLAY_REQ], KEY_REFRESH);
    _nc_add_to_try(&(SP->_keytry), input_req_cap[WINDOW_RESIZED_REQ], 
			KEY_RESIZE);
    _nc_add_to_try(&(SP->_keytry), input_req_cap[WINDOW_ACTIVATED_REQ], 
			KEY_IGNORE);
    _nc_add_to_try(&(SP->_keytry), input_req_cap[WINDOW_DEACTIVATED_REQ], 
			KEY_IGNORE);
}


/*
 * _nc_iexten_termios_raw:
 *
 * IXTEN and OPOST should be left on for VOS.  The tables will be set up
 * properly no matter which way they are set.
 */

#define IEXTEN_TERMIOS_RAW

void
_nc_iexten_termios_raw(struct termios *tios)
{
}


/* Internal routines (in apphabetical order).  */


/*
 * get_generic_req_components:
 *
 * Wrapper for calling s$ttp_get_generic_reqN_cmponents.
 */

static void
get_generic_req_components(iexten_setup_globals *gp, short p_req_no, 
		short p_def_no, short p_max, short *p_nump, 
		short * p_components, short *p_codep)
{
    s$ttp_get_generic_reqN_cmponents( &gp->input_db, &gp->section_name, 
					&p_req_no, &p_def_no, 
					&p_max, p_nump, p_components, p_codep);
}


/*
 * initialize_tables:
 *
 * Initialize the invariant tables used for input and output sequences.
 * This is called once per program invocation.
 */

typedef struct TABLE_LOCALS
{
	TERMINAL *ct;
	int pass;
	int free_string;
	char *stringsp;
	int strings_size;
}
TABLE_LOCALS;

static void
insert_in_cap_table( TABLE_LOCALS *gp, int seq_no, char **curses_table,
			const char *params );

#define	ADD_CAP(seq,tab,params)	insert_in_cap_table(&g,seq,&(tab),params)

static void 
initialize_tables(TERMINAL *cur_term)
{
	int j = 0;
	int k = 0;
	TABLE_LOCALS g;

	g.ct = cur_term;
	g.pass = 0;
	g.free_string = 0;
	g.stringsp = NULL;
	g.strings_size = (HB_FUNCTION_KEYS+1)*4*2 + (HB_REQS+1)*4;

	for(j = 0; j <= MAX_OUTPUT_SEQUENCES; j++)
	{
		output_caps[j].curses_table_index = -1;
		output_caps[j].curses_cap = NULL;
	}

	for( g.pass = 1; g.pass <= 2; g.pass++)
	{
		if (g.pass == 2)
		{
			/* Allocate our permanent strings table.
			   This has room for every output sequence we could 
			   possibly use, plus every function key and every
			   generic request.  It gets allocated once per
			   program execution and is never freed.  */

			g.stringsp = typeCalloc(char, g.strings_size);
		}

		/* audible signal (bell) (P) */
		ADD_CAP( BEEP_SEQ, bell, "" );

		/* carriage return (P*) (P*) 
		ADD_CAP( CARRIAGE_RETURN_SEQ, carriage_return, "" ); */

		/* clear screen and home cursor (P*).  The 
		   VOS version clears to end of scrolling region, 
		   the curses documentation says it wants end 
		   of screen.  Ncurses works better with clear screen 
		   enabled and set scrolling region disabled.  */
		ADD_CAP( CLEAR_SCREEN_SEQ, clear_screen, "" ); 

		/* clear to end of screen (P*).  The 
		   VOS version clears to end of scrolling region,
		   the curses documentation says it wants end 
		   of screen.  */
		ADD_CAP( CLEAR_TO_EOS_SEQ, clr_eos, "" ); 

		/* change region to line #1 to line #2 (P) 
		ADD_CAP( SET_SCROLLING_REGION_SEQ, change_scroll_region, 
			"%c%c" ); */

		/* clear to end of line (P) */
		ADD_CAP( CLEAR_TO_EOL_SEQ, clr_eol, "" );

		/* move to row #1 columns #2 */
		ADD_CAP( POSITION_CURSOR_SEQ, cursor_address, 
			"%c%c" );

		/* make cursor invisible */
		ADD_CAP( CURSOR_OFF_SEQ, cursor_invisible, "" );

		/* make cursor appear normal (undo civis/cvvis) */
		ADD_CAP( CURSOR_ON_SEQ, cursor_normal, "" );

		/* delete character (P*) */
		ADD_CAP( DELETE_CHARS_SEQ, delete_character, 
			"\xFF\xFF\x01" );

		/* delete line (P*) */
		ADD_CAP( DELETE_LINES_SEQ, delete_line, 
			"\xFF%{1}%c" );

		/* disable status line */
		ADD_CAP( RESET_25TH_LINE_SEQ, dis_status_line, "" );

		/* start alternate character set (P) */
		ADD_CAP( ENTER_GRAPHICS_MODE_SEQ, enter_alt_charset_mode, "" );

		/* turn on blinking */
		ADD_CAP( BLINK_ON_SEQ, enter_blink_mode, "" );

		/* turn on bold (extra bright) mode */
		ADD_CAP( HI_INTENSITY_ON_SEQ, enter_bold_mode, "" );

		/* enter_ca_mode: string to start programs using cup */
		/* enter_delete_mode: enter delete mode */

		/* turn on half-bright mode */
		ADD_CAP( HALF_INTENSITY_ON_SEQ, enter_dim_mode, "" );

		/* turn on blank mode (characters invisible) */
		ADD_CAP( BLANK_ON_SEQ, enter_secure_mode, "" );

		/* turn on reverse video mode */
		ADD_CAP( INVERSE_VIDEO_ON_SEQ, enter_reverse_mode, "" );

		/* begin standout mode */
		ADD_CAP( STANDOUT_ON_SEQ, enter_standout_mode, "" );

		/* end alternate character set (P) */
		ADD_CAP( LEAVE_GRAPHICS_MODE_SEQ, exit_alt_charset_mode, "" );

		/* turn off all attributes and turn off alt charset mode. */
		ADD_CAP( SET_MODE_ATTRIBUTES_SEQ, exit_attribute_mode, 
			"\200\200\x1b\x1c" );

		/* exit standout mode */
		ADD_CAP( STANDOUT_OFF_SEQ, exit_standout_mode, "" );

		/* return from status line */
		ADD_CAP( END_25TH_LINE_SEQ, from_status_line, "" );

		/* newline (behave like cr followed by lf) */
		ADD_CAP( NEW_LINE_SEQ, newline, "" );

		/* delete #1 characters (P*) */
		ADD_CAP( DELETE_CHARS_SEQ, parm_dch, 
			"\xFF\xFF%c" );

		/* delete #1 lines (P*) */
		ADD_CAP( DELETE_LINES_SEQ, parm_delete_line, 
			"\xFF%c" );

		/* insert #1 characters (P*) */
		ADD_CAP( INSERT_CHARS_SEQ, parm_ich, 
			"\xFF\xFF%c" );

		/* insert #1 lines (P*) */
		ADD_CAP( INSERT_LINES_SEQ, parm_insert_line, 
			"\xFF%c" );

		/* scroll text up (P) */
		ADD_CAP( SCROLL_UP_SEQ, scroll_forward, "" );

		/* scroll text down (P) */
		ADD_CAP( SCROLL_DOWN_SEQ, scroll_reverse, "" );

		/* move to status line, column #1 */
		ADD_CAP( START_25TH_LINE_SEQ, to_status_line, "" );

		/* begin underline mode */
		ADD_CAP( UNDERSCORE_ON_SEQ, enter_underline_mode, "" );

		/* exit underline mode */
		ADD_CAP( UNDERSCORE_OFF_SEQ, exit_underline_mode, "" );

		/* line drawing graphics */
		ADD_CAP( 0, acs_chars, 
			"l\6m\5k\7j\10u\14t\15v\17w\16q\13x\12n\11" );
	}

	for (j = 0; j <= HB_FUNCTION_KEYS; j++)
	{
	    for (k = 0; k < 2; k++)
	    {
		int key_code = k << 9 | j;

		input_key_cap[k][j] = g.stringsp + g.free_string;
		g.stringsp[g.free_string++] = XCI;
		g.stringsp[g.free_string++] = 0x40 | ((key_code >> 6) & 0x3f);
		g.stringsp[g.free_string++] = 0x40 | (key_code & 0x3f);
		g.stringsp[g.free_string++] = '\0';
	    }
	}

	for (j = 0; j <= HB_REQS; j++)
	{
		input_req_cap[j] = g.stringsp + g.free_string;
		g.stringsp[g.free_string++] = XCI;
		g.stringsp[g.free_string++] = 0x30 | ((j >> 6) & 0x0f);
		g.stringsp[g.free_string++] = 0x40 | (j & 0x3f);
		g.stringsp[g.free_string++] = '\0';
	}

	for (j = 0; ; j++)
	{
		int keyno = _nc_tinfo_fkeys[j].code;
		int strno = _nc_tinfo_fkeys[j].offset;

		if (strno == 0)
			break;

		strcap_type[strno] = INPUT_CAPTYPE;
		key_str_index[keyno] = strno;
	}

	label_index[0] = (&(lab_f0) - &(CUR Strings[0]));
	label_index[1] = (&(lab_f1) - &(CUR Strings[0]));
	label_index[2] = (&(lab_f2) - &(CUR Strings[0]));
	label_index[3] = (&(lab_f3) - &(CUR Strings[0]));
	label_index[4] = (&(lab_f4) - &(CUR Strings[0]));
	label_index[5] = (&(lab_f5) - &(CUR Strings[0]));
	label_index[6] = (&(lab_f6) - &(CUR Strings[0]));
	label_index[7] = (&(lab_f7) - &(CUR Strings[0]));
	label_index[8] = (&(lab_f8) - &(CUR Strings[0]));
	label_index[9] = (&(lab_f9) - &(CUR Strings[0]));
	label_index[10] = (&(lab_f10) - &(CUR Strings[0]));

	for (j = 0; j <= 10; j++)
	{
		strcap_type[label_index[j]] = LABEL_CAPTYPE;
	}
}

static void
insert_in_cap_table( TABLE_LOCALS *gp, int seq_no, char **curses_table,
			const char *params )
{
	int len = strlen(params);

	if (gp->pass == 1)
	{
		gp->strings_size += ((seq_no > 0) ? 3 : 1) + len;
	}
	else
	{
		TERMINAL *cur_term = gp->ct;	/* for the CUR macro */
		output_caps[seq_no].curses_table_index = 
				(curses_table - &(CUR Strings[0]));

		output_caps[seq_no].curses_cap = gp->stringsp + gp->free_string;

		if (seq_no > 0)
		{
		    gp->stringsp[gp->free_string++] = GSI;
		    gp->stringsp[gp->free_string++] = seq_no;
		}
		memcpy(gp->stringsp + gp->free_string, params, len);
		gp->free_string += len;
		gp->stringsp[gp->free_string++] = '\0';;
	}
}


/*
 * insert_keys:
 *
 * This is called to insert the mappings for VOS function keys into
 * the ncurses tables.  It inserts both shifted and unshifted mappings
 * if it can.  The input keycode can either be a function key or a
 * generic request.  If it's a generic request, this routine expands
 * the underlying key definitions (if they are single function key
 * sequences).
 */

static void
insert_keys (iexten_setup_globals *gp, int p_keycode, int p_ix) 
{
    if (p_keycode >= FKEY_OFFSET)
    {
	int check_key_code = p_keycode - FKEY_OFFSET;
	int key_no = (check_key_code & 0x1FF);
	int key_shift = 0;

	for( key_shift = 0; key_shift <= 1; key_shift++)
	{
	    short key_mask = (0x1 << key_shift);
	    int ncurses_key = vos_to_ncurses_map[p_ix].to[key_shift];

	    if (gp->ncurses_key_defined[ncurses_key])
		continue;

	    if (!(gp->defined_keys[key_no] & key_mask))
	        continue;

	    if (gp->used_keys[key_no] & key_mask)
	        continue;

	    if (set_cap_table (gp, input_key_cap[key_shift][key_no],
				p_keycode + key_shift * SHIFT_MULTIPLIER,
				ncurses_key, 1))
	    {
	        gp->used_keys[key_no] |= key_mask;
	    }
	}
    }
    else
    {
	/* We have an appropriate generic request, but we are being 
	   asked to use function keys.  Expand the generic request
	   and use any single function key expansions with the same
	   shift as the ncurses key.  */

	short req_no = p_keycode;
	short def_no = 1;

	for (def_no = 1; ; def_no++)
	{
	    short code;
	    short num;
	    short components[128];
	    int comp;

	    get_generic_req_components( gp, req_no, def_no, 128, &num, 
					components, &code);
	    if (code || num <= 0)
		break;

	    comp = components[0];

	    if (num != 1)
		continue;

	    if (comp >= FKEY_OFFSET)
	    {
		int check_key_code = comp - FKEY_OFFSET;
		int key_no = (check_key_code & 0x1FF);
		int key_shift = (check_key_code >> 9);
		short key_mask = (0x1 << key_shift);
		int ncurses_key;

		if (key_shift > 1)
		    continue;

		if (gp->used_keys[key_no] & key_mask)
		    continue;

		ncurses_key = vos_to_ncurses_map[p_ix].to[key_shift];

		if (gp->ncurses_key_defined[ncurses_key])
		    continue;

		if ( set_cap_table (gp, input_key_cap[key_shift][key_no],
					req_no, ncurses_key, def_no) )
		{
		    gp->used_keys[key_no] |= key_mask;
		}
	    }
	}
    }
}


/*
 * insert_req:
 *
 * This is called to insert the mapping for a vos generic input request
 * to an ncurses key.
 */

static int
insert_req (iexten_setup_globals *gp, int p_req_no, int p_ncurses_key, 
		int legend_instance)
{
    if (p_ncurses_key < 0 || p_ncurses_key > KEY_MAX)
	return 0;

    if (gp->ncurses_key_defined[p_ncurses_key])
	return 0;

    return set_cap_table(gp, input_req_cap[p_req_no], p_req_no, 
				p_ncurses_key, legend_instance);
}


/*
 * get_legend:
 *
 * This is called to obtain the keytop legend for F0-F10.
 */

static void
get_legend (iexten_setup_globals *gp,
		short p_label_index, short p_max, short *p_nump, 
		char *p_string, short *p_codep)
{
    short key_code = gp->label_table[p_label_index].keycode;
    short def_no = gp->label_table[p_label_index].legend_instance;
    int  total_len;
 
    *p_nump = 0;
    *p_codep = 0;

    if (!def_no)
	return;

    if (key_code >= FKEY_OFFSET)
    {
	ttp_char_varying_32 modifier;
	ttp_char_varying_32 key_legend;
	int  modlen;
	int  keylen;

	key_code -= FKEY_OFFSET;

	s$ttp_get_legend(&gp->keyboard_db, &key_code, &modifier, &key_legend);

	modlen = strlen_vstr(&modifier);
	keylen = strlen_vstr(&key_legend);
	total_len = modlen + keylen + (modlen > 0);
	*p_nump = total_len;

	if (total_len > p_max || total_len > 65)
	{
	    *p_codep = e$buffer_too_small;
	}
	else
	{
	    if (modlen > 0)
	    {
		char_varying(65) name;

		strcpy_vstr_vstr(&name, &modifier);
		strcat_vstr_nstr(&name, "-");
		strcat_vstr_vstr(&name, &key_legend);
		strncpy_nstr_vstr(p_string, &name, total_len);
	    }
	    else
	    {
		strncpy_nstr_vstr(p_string, &key_legend, total_len);
	    }

	    *p_codep = 0;
	}
    }
    else 
    {
	s$ttp_get_generic_reqN_legend (&gp->keyboard_db, &gp->input_db,
					&gp->section_name, &key_code, &def_no, 
					&p_max, p_nump, p_string, p_codep);
    }

    /* If the label is simply Fn, we aren't supposed to define it. */

    if ( *p_codep == 0 && (total_len = *p_nump) >= 1
      && (*p_string == 'f' || *p_string == 'F') )
    {
	if (p_label_index == 10)
	{
	    if (total_len == 3 && p_string[1] == '1' && p_string[2] == '0')
		*p_nump = 0;
	}
	else
	{
	    if (total_len == 2 && p_string[1] == '0' + p_label_index)
		*p_nump = 0;
	}
    }
}

/*
 * set_cap_table:
 *
 * This is called to set a capabilty string for an ncurses key. 
 * It also maintains the ncurses_key_defined array and captures
 * the parameters needed to generate keytop legends for F0-F10.
 */

static int
set_cap_table (iexten_setup_globals *gp, char *cap_string, int p_keycode, 
		int p_ncurses_key, int generate_legend)
{
    if (gp->ncurses_key_defined[p_ncurses_key])
	return 0;

    gp->ncurses_key_defined[p_ncurses_key] = 1;

    gp->termp->type.Strings[key_str_index[p_ncurses_key]] = cap_string;

    if ( generate_legend 
      && p_ncurses_key >= KEY_F(0) 
      && p_ncurses_key <= KEY_F(10) )
    {
	int ix = p_ncurses_key-KEY_F(0);

	gp->label_table[ix].keycode = p_keycode;
	gp->label_table[ix].legend_instance = generate_legend;
    }
    return 1;
}


/* _nc_vos_get_window_size:
 *
 * Gets the size of the primary window associated with
 *  a given port id.
 */

static int
_nc_vos_get_window_size( short port_id,		/* input */
			 short *width,		/* output */
			 short *height )	/* output */
{
/* auto */
	PRIMARY_WINDOW_BOUNDS_V1	bounds;
	short				opcode;
	short				error_code;

/* program */

	bounds.version = 1;
	opcode = TERM_GET_PWIN_BOUNDS_OPCODE;
	s$control(&port_id, &opcode, &bounds.version, &error_code);
	if (error_code)
	{
		return s$c_set_errno (error_code);
	}

	*width = bounds.width;
	*height = bounds.height;
	return 0;
}
#endif


/*
 * The default encapsulation routines begin here.
 */


#ifndef VENDOR_CAN_DO_CAPS_DEFINED

/*
 * _nc_vendor_can_do_caps:
 *
 * This routine should return 1 if a call to _nc_opost_setup followed by
 * a call to _nc_iexten_setup will completely initialize the TERMINAL
 * structure if the TERMINAL structure has been passed in as all zeros.
 */

int
_nc_vendor_can_do_caps(void)
{
	return 0;
}

#endif

#ifndef OPOST_SETUP_DEFINED

/*
 * _nc_opost_setup:
 *
 * This subroutine performs any adjustments to the TERMINAL structure 
 * needed for vendor specific OPOST behavior.  If both _nc_opost_setup
 * and _nc_iexten_setup are going to be called, _nc_opost_setup is
 * called first.
 */

int
_nc_opost_setup(TERMINAL *term_ptr, int Filedes, struct termios *tios)
{
	return 1;
}

#endif

#ifndef IEXTEN_SETUP_DEFINED

/*
 * _nc_iexten_setup:
 *
 * This subroutine performs any adjustments to the TERMINAL structure 
 * needed for vendor specific IEXTEN behavior.  If both _nc_opost_setup
 * and _nc_iexten_setup are going to be called, _nc_opost_setup is
 * called first.
 */

int
_nc_iexten_setup(TERMINAL *term_ptr, int Filedes, struct termios *tios)
{
	return 1;
}

#endif

#ifndef IEXTEN_INIT_KEYTRY_DEFINED

/*
 * _nc_iexten_init_keytry:
 *
 * This routine is provided for implementations to add IEXTEN dependent
 * strings directly to the keytry.  It should be used if the implementation
 * supports more than one mapping to a given KEY_ value.
 * The keytry added to is SP->_keytry and the term type is the one in
 * cur_term.
 */

void
_nc_iexten_init_keytry(void)
{
}

#endif

#ifndef IEXTEN_TERMIOS_RAW

/*
 * _nc_iexten_termios_raw:
 *
 * This routine is provided for implementations to modify IEXTEN properly
 * when switching to raw mode.  The caller will have made the adjustments
 * to the standard POSIX fields.
 */

void
_nc_iexten_termios_raw(struct termios *tios)
{
    tios->c_lflag &= ~IEXTEN;
}

#endif
