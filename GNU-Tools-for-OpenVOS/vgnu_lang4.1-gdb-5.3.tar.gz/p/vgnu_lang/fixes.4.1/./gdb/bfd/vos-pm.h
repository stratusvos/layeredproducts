#ifndef _VOS_PM_H
#define _VOS_PM_H

struct vos_data_struct
   {
      program_module *pm_header;  /* Points to in-memory copy of pm header */
      vaddrfile_fcb_type *pm_fcb_ptr;
      long symcount;

   };

#define vosdata(abfd)                    ((abfd)->tdata.vos_data)

/* Defines for VOS-specific data attached to the bfd.
   symcount is count of VOS non-debugging symbols, ie
   n_external_vars + n_entries
*/
#define obj_vos_pm_header(abfd)          (vosdata(abfd)->pm_header)
#define obj_vos_pm_fcb_ptr(abfd)         (vosdata(abfd)->pm_fcb_ptr)
#define obj_vos_symcount(abfd)           (vosdata(abfd)->symcount)

/* Defines for PM header fields for VOS data PM header pointer */

#define obj_vos_link_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->link_map_address)
#define obj_vos_link_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->link_map_len)

#define obj_vos_link_names_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->link_names_map_address)
#define obj_vos_link_names_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->link_names_map_len)

#define obj_vos_external_vars_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->external_vars_map_address)
#define obj_vos_external_vars_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->external_vars_map_len)

#define obj_vos_entry_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->entry_map_address)
#define obj_vos_entry_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->entry_map_len)

#define obj_vos_section_map_file_address(abfd)  \
     ((obj_vos_pm_header(abfd))->section_map_file_address)
#define obj_vos_section_map_address(abfd)  \
     ((obj_vos_pm_header(abfd))->section_map_address)
#define obj_vos_section_map_len(abfd)  \
     ((obj_vos_pm_header(abfd))->section_map_len)

#define obj_vos_string_pool_address(abfd)  \
     ((obj_vos_pm_header(abfd))->string_pool_address)
#define obj_vos_string_pool_len(abfd) \
     ((obj_vos_pm_header(abfd))->string_pool_len)
#define obj_vos_string_pool_ptr(abfd) \
     ((obj_vos_pm_header(abfd))->string_pool_address)

#define obj_vos_dynamic_table_address(abfd) \
     ((obj_vos_pm_header(abfd))->dynamic_table_address)
#define obj_vos_dynamic_table_len(abfd) \
     ((obj_vos_pm_header(abfd))->dynamic_table_len)

#define obj_vos_dynsym_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->dynsym_map_address)
#define obj_vos_dynsym_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->dynsym_map_len)
#define obj_vos_n_dynsyms(abfd) \
     ((obj_vos_pm_header(abfd))->n_dynsyms)

#define obj_vos_user_boundary(abfd) \
     ((obj_vos_pm_header(abfd))->user_boundary)

#define obj_vos_processor_family(abfd) \
     ((obj_vos_pm_header(abfd))->processor_family)
#define obj_vos_processor(abfd) \
     ((obj_vos_pm_header(abfd))->processor)

#define obj_vos_header_address(abfd) \
     ((obj_vos_pm_header(abfd))->header_address)
#define obj_vos_header_len(abfd) \
     ((obj_vos_pm_header(abfd))->header_len)

#define obj_vos_n_sections(abfd)  \
     ((obj_vos_pm_header(abfd))->n_sections)

#define obj_vos_n_header_pages(abfd)  \
     ((obj_vos_pm_header(abfd))->n_header_pages)

#define obj_vos_n_unsnapped_links(abfd)  \
     ((obj_vos_pm_header(abfd))->n_unsnapped_links)

#define obj_vos_n_link_names(abfd)  \
     ((obj_vos_pm_header(abfd))->n_link_names)

#define obj_vos_n_external_vars(abfd)  \
     ((obj_vos_pm_header(abfd))->n_external_vars)

#define obj_vos_n_entries(abfd)  \
     ((obj_vos_pm_header(abfd))->n_entries)

#define obj_vos_pm_info(abfd) \
     ((obj_vos_pm_header(abfd))->info)

#define obj_vos_main_code_address(abfd) \
     ((obj_vos_pm_header(abfd))->main_entry_link.code_address)
#define obj_vos_main_static_address(abfd) \
     ((obj_vos_pm_header(abfd))->main_entry_link.static_address)
#define obj_vos_n_modules(abfd) \
     ((obj_vos_pm_header(abfd))->n_modules)
#define obj_vos_module_map_address(abfd) \
     ((obj_vos_pm_header(abfd))->module_map_address)
#define obj_vos_module_map_len(abfd) \
     ((obj_vos_pm_header(abfd))->module_map_len)
#define obj_vos_n_tasks(abfd) \
     ((obj_vos_pm_header(abfd))->n_tasks)
#define obj_vos_global_offset_table_address \
     ((obj_vos_pm_header(abfd))->global_offset_table_address)
#define obj_vos_block_map_address \
     ((obj_vos_pm_header(abfd))->block_map_address)
#define obj_vos_block_map_len \
     ((obj_vos_pm_header(abfd))->block_map_len)

/* Macros */
#ifdef TEST
#define PRINT_ENTER(name) \
     printf("\n******entering  %s \n",name)
#define PRINT_EXIT(name) \
     printf("\n******exiting %s\n",name)
#define XXXPRINTF printf
#define XXXPARAMS(arglist) arglist
/* Usage: PRINT_VAL(("this is a string", string)) */
#define PRINT_VAL(arglist) XXXPRINTF XXXPARAMS(arglist)
#else
#define PRINT_ENTER(name)
#define PRINT_ENTER_VAL(name,val)
#define PRINT_VAL(arglist)
#endif


#endif
