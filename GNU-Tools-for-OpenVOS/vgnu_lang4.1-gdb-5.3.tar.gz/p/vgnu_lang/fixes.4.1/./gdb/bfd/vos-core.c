/* Include files */

#include "bfd.h"
#include "sysdep.h"
#include "libbfd.h"

#include <stdio.h>
#include <sys/types.h>
#include <signal.h>

#if defined(HOST_HPPAVOS) || defined(HOST_X86VOS)

#include "vos-defs.h"
#include <voslib.incl.c>
#include <string.h>
#include <object_constants.incl.c>
#include <system_io_constants.incl.c>
#include <cpu_version.incl.c>
#include <keep_module.incl.c>
#include <vaddrfile_dcls.incl.c>

/* Necessary because gcc doesn't support shortmap */
#ifdef __GNUC__
#define $shortmap
#pragma pack(2)
#endif
#include <program_module.incl.c>
#ifndef   _INCLUDED_MC_H
#include <mc.incl.c>
#define   _INCLUDED_MC_H /* see <sys/ucontext.h */
#endif /* _INCLUDED_MC_H */
#if defined(HOST_X86VOS)
#include <ia32_regs.incl.c>
#endif
#ifdef __GNUC__
#undef $shortmap
#pragma pack()
#endif

#include "vos-pm.h"
#include "vos-core.h"

#include <fault_codes.h>

/* Type definitions */


/* Externally visible entry points defined in this module.
   These entries are called through function pointers */

const bfd_target               *vos_core_core_file_p PARAMS((bfd *abfd));
char                     *vos_core_core_file_failing_command PARAMS((bfd *abfd));
int                      vos_core_core_file_failing_signal PARAMS((bfd *abfd));
boolean                  vos_core_core_file_matches_executable_p 
     PARAMS((bfd *core_bfd, bfd *exec_bfd));
boolean                  vos_core_close_and_cleanup PARAMS((bfd *abfd));
boolean                  vos_core_bfd_free_cached_info PARAMS((bfd *abfd));
boolean                  vos_core_get_section_contents 
 PARAMS((bfd *abfd, sec_ptr sec, PTR loc, file_ptr offset, bfd_size_type cnt));
asymbol *                vos_core_make_empty_symbol PARAMS((bfd *abfd));

/* Static Entries */
static int               fake_machine_conditions PARAMS((bfd *abfd));
static long              swap_32 PARAMS ((long val));
static void              swap_abort PARAMS((void));
static boolean           vos_core_setup_sections PARAMS((bfd *abfd));
static asection          *vos_core_make_section 
     PARAMS((bfd *abfd, unsigned long sec_vaddr, unsigned long sec_fileaddr, \
     long sec_len, char *sec_name));
static asection * make_a_section 
 PARAMS((bfd *abfd, region_struc *region_info, char *name, flagword flags));

/* External Entries */
extern void s$attach_port 
  PARAMS((char_varying *portname, char_varying *qpath, short *switches,  short *port_id, short *code));
void s$display_pm_header PARAMS((program_module *pm_header));
void s$error 
   PARAMS((short *err, char_varying *caller,  char_varying  *msg));
void s$lookup_kernel_address
   PARAMS((short *module_id, char_varying_32 *name, short * flags, 
           void ** link, short *error_code));
void *s$mc_get_coproc_data PARAMS((void *mcp, short *coproc_type));
void s$open PARAMS((short *port_id, short *file_org, short *maxlen, \
 short *io_type, short *lockmode, short *accmode, \
 char_varying *index_name, short *code));

void s$rel_read PARAMS((short *port_id, long *recnum, short *buflen, \
     short *reclen, char *buffer, short *code));
extern void s$c_expand_path (const char ** pathp,
               char_varying * cv_pathp,
               short * code);

int vos_fault_to_signal_no PARAMS((int));

int 
vos_fault_to_signal_no(faultnum)
     int faultnum;
{
     int signum;
          
     switch (faultnum) {
        case PAGE_FAULT:
          signum = SIGBUS;
          break;
        case ADDRESS_ERROR:
          signum = SIGSEGV;
          break;
        case ILLEGAL_INSTRUCTION:
        case PRIVILEGE_VIOLATION:
          signum = SIGILL;
          break;
        case ZERO_DIVIDE:
        case INEXACT_RESULT:
        case FP_DIVIDE_BY_ZERO:
        case OVERFLOW:
        case UNDERFLOW:
        case OPERAND_ERROR:
        case SIGNALLING_NAN:
        case FP_BOTH_ZERO:
          signum = SIGFPE;
          break;
        case PROGRAM_INTERRUPT:
          signum = SIGINT;
          break;
        case TRAPV_INSTRUCTION:
        case TRACE:
        case TRAP_0_INSTRUCTION:
        case TRAP_1_INSTRUCTION:
        case TRAP_2_INSTRUCTION:

#if defined(HOST_HPPAVOS)
        case TRAP_3_INSTRUCTION:
#endif  /* defined(HOST_HPPAVOS) */
#if defined(HOST_X86VOS)
	case INT3_INSTRUCTION:
        case BAD_STACK:
#endif /* defined (HOST_X86VOS) */

        case TRAP_4_INSTRUCTION:
        case TRAP_5_INSTRUCTION:
        case TRAP_6_INSTRUCTION:
        case TRAP_7_INSTRUCTION:
        case TRAP_8_INSTRUCTION:
        case TRAP_10_INSTRUCTION:
        case TRAP_11_INSTRUCTION:
        case TRAP_12_INSTRUCTION:
        case TRAP_13_INSTRUCTION:
        case TRAP_14_INSTRUCTION:
        case TRAP_15_INSTRUCTION:
          signum = SIGTRAP;
          break;
        default:
          signum = SIGABRT;
          break;
     }
     return signum;
}
static asection *
vos_core_make_section(abfd, sec_vaddr, sec_fileaddr, 
sec_len, sec_name)
bfd *abfd;
unsigned long sec_vaddr;
unsigned long sec_fileaddr;
long sec_len;
char *sec_name;
{
 asection *newsect;
 char *newname;

 PRINT_ENTER("vos_core_make_section");

 newname  = bfd_alloc(abfd, strlen(sec_name) + 1);
 if (newname == 0)
   return false;
 strcpy(newname, sec_name);

 newsect = bfd_make_section_anyway (abfd, newname);
 if (newsect == NULL)
   return NULL;

 newsect->alignment_power = 16; /* 4096 */
 if (! bfd_set_section_vma(abfd, newsect, sec_vaddr)
     || ! bfd_set_section_size(abfd, newsect, sec_len)
     || !  bfd_set_section_alignment (abfd, newsect, bfd_log2(4096) ))
   return NULL;

 newsect->flags = SEC_NO_FLAGS;
 newsect->filepos = sec_fileaddr;
 return newsect;

}


static asection *
make_a_section(abfd, region_info, name,  flags)
bfd *abfd;
region_struc *region_info;
char *name;
flagword flags;
{ 
  asection *sec_ptr = NULL;
  unsigned long fileaddr;
  long len;
  unsigned long addr;

  addr=region_info->base_addr;  
  len =region_info->n_pages *PM_RECORD_LENGTH; 
  fileaddr = region_info->record_no*PM_RECORD_LENGTH; 

  if (len != 0)  
  { 
    sec_ptr = vos_core_make_section(abfd,addr,fileaddr,len, name);
    if (sec_ptr != NULL) 
        sec_ptr->flags |= (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_DATA);
   } 
   return sec_ptr;
} 


/*  Setup BFD sections for VOS core file.  A BFD section is a canonicalized
    version of a part of the information in the file at contiguous addresses.
    It has no a-priori relation to a VOS section. */
static boolean 
vos_core_setup_sections (abfd)
bfd *abfd;
{
  km_template *km_header;
  int i;
  flagword flags;

  km_header = core_km_header(abfd);

  flags = (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_DATA );
  for (i = wired_section; i <= paged_section; i++)
     {
       if ( make_a_section(abfd,
               &(km_header->unshared_static[i-1]),
               vos_static_data_section_name,
               flags) == (asection *) NULL)
          return false;
        if (make_a_section(abfd, &(km_header->shared_static[i-1]),
          vos_external_static_data_section_name,
          flags) == (asection *) NULL)
          return false;
     }

 if ( make_a_section(abfd, &(km_header->user_heap), 
     vos_data_section_name, flags)
         == (asection *) NULL)
   return false;

 if ( make_a_section(abfd,&(km_header->stack),
     vos_data_section_name, flags)
         == (asection *) NULL)
   return false;
     
  flags = (SEC_ALLOC | SEC_HAS_CONTENTS | SEC_CODE);
  for (i = 0; i < km_header->num_code_entries; i++)
    if (make_a_section(abfd,&(km_header->code_pages[i]),
     vos_text_section_name, flags) 
         == (asection *) NULL)
      return false;

  return true;
}

static void
vos_core_kp_read(program_path_ptr, pm_fcb_ptr, port_id_ptr, code_ptr)
char_varying_256 *program_path_ptr;
vaddrfile_fcb_type *pm_fcb_ptr;
short *port_id_ptr;
short *code_ptr;
{
 short io_type = INPUT_TYPE;  
 static char_varying_32 caller = {11, "vos_pm_read"};

/* Attach port, open in random mode for input, read PM header */
 
 PRINT_ENTER("vos_core_kp_read");

 *port_id_ptr = 0;

 vaddrfile_open_pm(program_path_ptr, &io_type, port_id_ptr, code_ptr);

 if (*code_ptr != 0) goto return_to_caller;

  vaddrfile_init_kp(port_id_ptr, pm_fcb_ptr, code_ptr);
    
return_to_caller:
 if (*code_ptr)
   s$error(code_ptr, &caller, program_path_ptr);
 return;
}

const bfd_target *
vos_core_core_file_p (abfd)
bfd *abfd;
{
 vaddrfile_fcb_type *pm_fcb_ptr;
 short code = 0;
 short port_id;
 char_varying_256 filename;
 
 PRINT_ENTER("vos_core_core_file_p");
 
 pm_fcb_ptr = bfd_alloc(abfd, sizeof(vaddrfile_fcb_type));
 if (pm_fcb_ptr == NULL) goto error_return;

 core_data(abfd) = (struct vos_core_struct *)
      bfd_zalloc (abfd, sizeof (struct vos_core_struct));
 if (core_data(abfd) == NULL) goto error_return;

/* Convert to VOS_style pathname */

 s$c_expand_path(&abfd->filename, &filename, &code);

 vos_core_kp_read(&filename, pm_fcb_ptr, &port_id, &code);
 if (code)
   goto error_return;

 core_fcb_ptr(abfd) = pm_fcb_ptr;
 core_km_header(abfd) = pm_fcb_ptr->keep_module_ptr;

/* Check for supported cpu types. We subtract 1 from the cpu type 
   because write_keep_module records the CPU type as one greater 
   than the values in cpu_version.incl.pl1 */
 core_machine_type(abfd) = core_km_header(abfd)->cpu_type - 1;
   
  switch (core_machine_type(abfd)) {
     case(CPU_TYPE_68000):
     case(CPU_TYPE_68010):
     case(CPU_TYPE_68020):
     case(CPU_TYPE_68030):
     case(CPU_TYPE_I860):
     case(CPU_TYPE_I860XP):
     case(CPU_TYPE_PA7100):
     case(CPU_TYPE_PA8000):
     case(CPU_TYPE_PA8500):
     case(CPU_TYPE_PA8600):
      bfd_set_error(bfd_error_wrong_format);
      bfd_perror("Core file CPU type not supported\n");
      goto error_return;
      break;

#if defined (HOST_X86VOS)
     case(CPU_TYPE_P4):
       break;
#endif /* defined (HOST_X86VOS) */

     default:
       /* Print warning message, then continue */
       fprintf(stderr, "Warning: Core file CPU type not recognized\n");
       break;

     }

 strcpy_nstr_vstr(core_command(abfd), &(core_km_header(abfd)->program_path));

 if (vos_core_setup_sections (abfd) == false )
    goto error_return;
 return abfd->xvec;

error_return:
  vaddrfile_done(pm_fcb_ptr);
  return NULL;
}

/* For now ... */

char *
vos_core_core_file_failing_command (abfd)
     bfd *abfd;
{
  /* CODE ME */

  PRINT_ENTER("vos_core_core_file_failing_command");    

  return core_command(abfd);
}


int
vos_core_core_file_failing_signal (abfd)
bfd *abfd;
{
  short code;
  long count;
  void *loc;
  unsigned long vaddr;
  static char_varying_256 msg = {33,"vos_core_core_file_failing_signal"};

  PRINT_ENTER("vos_core_core_file_failing_signal");

  loc = &(core_regs(abfd));
  vaddr =(unsigned long) core_km_header(abfd)->mc_addr;
  if ((vaddr ==(unsigned long) NULL) 
          || (vaddr == (unsigned long) OS_NULL_PTR)) /* gnu_gdb-108 */
     {
       fprintf(stderr, "Warning, Core file contains no machine conditions. \n");
       if (fake_machine_conditions (abfd))
          {
            fprintf(stderr, "Gdb has faked machine conditions. \n");
            return 0;
          }
       return -1;
     }

  switch (core_machine_type(abfd)) {
     case(CPU_TYPE_68000):
     case(CPU_TYPE_68010):
     case(CPU_TYPE_68020):
     case(CPU_TYPE_68030):
     case(CPU_TYPE_I860):
     case(CPU_TYPE_I860XP):
     case(CPU_TYPE_PA7100):
     case(CPU_TYPE_PA8000):
     case(CPU_TYPE_PA8500):
     case(CPU_TYPE_PA8600):
      bfd_set_error(bfd_error_wrong_format);
      bfd_perror("Core file CPU type not supported\n");
      return -1;

#if defined(HOST_X86VOS)

     case(CPU_TYPE_P4):
       count = x86_reg_size;
       vaddrfile_read(core_fcb_ptr(abfd), &vaddr, (char **)&loc, &count, &code);
       if (code != 0)
         goto error_return;
       core_signal(abfd) = 
          vos_fault_to_signal_no(x86_regs(abfd).common.faultno);
       break;       

#endif /* defined (HOST_X86VOS) */

     default:
       /* Print warning message, then assume it's a PA8xxx */
       fprintf(stderr, "Warning: Core file CPU type not recognized\n");

      }

  return core_signal(abfd);

error_return:
  s$error(&code, &null_string, &msg);
  return -1;
}

#define  DEADVAL              0xdeaddead
static int
fake_machine_conditions (bfd *abfd)
{
  short                       code;
#if defined(HOST_X86VOS)
  short                       deadval_le15;
  long                        deadval_le31;
#endif
  long                        fake_pc;
  static short                flags = 0;
  short                       i;
#if defined(HOST_X86VOS)
  short                       j;
#endif
  void                        *link[2];
  void                        **linkp;
  static short                module_id = 0;
  static char_varying_32      pc_name = {26, "s$write_keep_module_return"};
  long                        stack_a6;

  PRINT_ENTER("fake_machine_conditions");

  stack_a6 = core_km_header(abfd)->stack_a6;

  if (stack_a6 == (long) NULL ||
      stack_a6 == (long) OS_NULL_PTR)
     {
/*     fprintf (stderr, "stack_a6 is NULL.\n"); */
       return 0;
     }

  linkp = (void **)&link;
  s$lookup_kernel_address(&module_id, &pc_name, &flags, linkp, &code);

  if (code != 0)
     {
/*      fprintf (stderr, "s$lookup_kernel_address returns %d.\n", code); */
        return 0;
     }

  fake_pc = (long) link[0];

  switch (core_machine_type(abfd)) {
     case(CPU_TYPE_68000):
     case(CPU_TYPE_68010):
     case(CPU_TYPE_68020):
     case(CPU_TYPE_68030):
     case(CPU_TYPE_I860):
     case(CPU_TYPE_I860XP):
     case(CPU_TYPE_PA7100):
     case(CPU_TYPE_PA8000):
     case(CPU_TYPE_PA8500):
     case(CPU_TYPE_PA8600):
        bfd_set_error(bfd_error_wrong_format);
        bfd_perror("Core file CPU type not supported\n");
        return 0;

#if defined(HOST_X86VOS)
     case(CPU_TYPE_P4):
        deadval_le31 = 0xaddeadde;      /* 0xdeaddead byte-swapped */
        deadval_le15 = 0xadde;          /* .. */

        memset(&x86_regs(abfd), 0, x86_reg_size);

        x86_regs(abfd).flags.n_bytes               = x86_reg_size;
        x86_regs(abfd).flags.n_other_coprocs       = 1;
        x86_regs(abfd).flags.coproc_data[0].type   = MC_EXT_CPU_P4;
        x86_regs(abfd).flags.coproc_data[0].offset = MC_X86_EXT_OFFSET;
        x86_regs(abfd).flags.coproc_data[1].type   = MC_COMMON_TYPE_P4;
        x86_regs(abfd).flags.coproc_data[1].offset = MC_X86_COMMON_OFFSET;
        x86_regs(abfd).flags.coproc_data[2].type   = MC_FT_IA32;
        x86_regs(abfd).flags.coproc_data[2].offset = MC_X86_FLOAT_OFFSET;

        x86_regs(abfd).common.eip = deadval_le31;

        for (i = 0; i <= 7; i++)
          x86_regs(abfd).common.gregs[i] = deadval_le31;

        for (i = 0; i <= 5; i++)
          x86_regs(abfd).common.sregs[i] = deadval_le15;

        for (i = 0; i <= 7; i++)
          for (j = 0; j <= 3; j++)
             x86_regs(abfd).floating_point.stregs[i].word[j] = deadval_le31;

        for (i = 0; i <= 7; i++)
          for (j = 0; j <= 3; j++)
             x86_regs(abfd).floating_point.xmmregs[i].word[j] = deadval_le31;

        /* Now fill in the few real values we have.  We have to guess the
           sp value from the comments and code about write_keep_module in 
           start_keep_module.  */

        x86_regs(abfd).common.eip = swap_32(fake_pc);
        x86_regs(abfd).common.gregs[R_EBP] = swap_32(stack_a6);
        x86_regs(abfd).common.gregs[R_ESP] = swap_32(stack_a6-40);
        break;
#endif

     default:
        fprintf(stderr, "Warning: Core file CPU type not recognized\n");
        return 0;
     }

  return 1;
}

static long
swap_32 (long value)
{
  typedef union
  {
    long  val;
    char  byte[4];
  } swaptype;

  swaptype result;
  swaptype source;

  source.val = value;

  result.byte[0] = source.byte[3];
  result.byte[1] = source.byte[2];
  result.byte[2] = source.byte[1];
  result.byte[3] = source.byte[0];

  return result.val;
}

boolean
vos_core_core_file_matches_executable_p (core_bfd, exec_bfd)
bfd *core_bfd;
bfd *exec_bfd;
{
  char_varying_256 v_pm_name;
  short  code;

 
  /* Check whether path name in keep file matches name of executable.
     Gdb will warn on mismatch but permits debugging anyway. 
     */
  PRINT_ENTER("vos_core_core_file_matches_executable_p");

  /* Make into VOS-style path name and see if it matches core path */
 
  s$c_expand_path(&exec_bfd->filename, &v_pm_name, &code);
  if (code != 0)
     return false;
  
  if  ( strcmp_vstr_vstr(&v_pm_name, &(core_km_header(core_bfd)->program_path))
          != 0 )
     return false;

  return true;      

}

boolean 
vos_core_get_section_contents (abfd, section, location, offset, count)
bfd *abfd;
sec_ptr section;
PTR location;
file_ptr offset;
 bfd_size_type count;
{
  vaddrfile_fcb_type *pm_fcb_ptr;
  unsigned long sec_vaddr;
  short code; 

  PRINT_ENTER("vos_get_section_contents");
  
  if (count == 0 || ((section->flags & SEC_HAS_CONTENTS) == 0))
    return true;
  if ((bfd_size_type)(offset+count) > section->_raw_size)
    return false;

  pm_fcb_ptr = core_fcb_ptr (abfd);
  sec_vaddr = section->vma + offset;
  vaddrfile_read(pm_fcb_ptr, &sec_vaddr, (char **)&location, &count, &code);
  if (code != 0)
    {
      bfd_perror("Unable to get section contents\n");
      return false;
    }
  
  return true;
}


boolean 
vos_core_bfd_free_cached_info (abfd)
bfd *abfd;
{
     PRINT_ENTER("vos_core_bfd_free_cached_info");
     
     if (bfd_get_format(abfd) != bfd_core)
       return true;

     if (core_data(abfd) != NULL)
       free(core_data(abfd));

}

boolean 
vos_core_close_and_cleanup (abfd)
bfd *abfd;
{
     PRINT_ENTER("vos_core_free_cached_info");

     if (bfd_get_format (abfd) != bfd_core)
          return true;

     if  ( (abfd->tdata.vos_core_data != (struct vos_core_struct *) NULL)
         && (core_fcb_ptr(abfd) != (vaddrfile_fcb_type *) NULL) )
       vaddrfile_done(core_fcb_ptr(abfd));

     vos_core_bfd_free_cached_info(abfd);
}

asymbol *
vos_core_make_empty_symbol (abfd)
     bfd *abfd;
{
  asymbol *new = (asymbol *) bfd_zalloc (abfd, sizeof (asymbol));
  if (new)
    new->the_bfd = abfd;
  return new;
}

/* If somebody calls any byte-swapping routines, shoot them.  */

static void
swap_abort()
{
  abort(); /* This way doesn't require any declaration for ANSI to fuck up */
}

#define NO_GET \
    ((bfd_vma (*) PARAMS ((   const bfd_byte *))) swap_abort )
#define NO_PUT  \
    ((void    (*) PARAMS ((bfd_vma, bfd_byte *))) swap_abort )
#define NO_SIGNED_GET \
  ((bfd_signed_vma (*) PARAMS ((const bfd_byte *))) swap_abort )

#define vos_core_new_section_hook _bfd_generic_new_section_hook
#define vos_core_get_section_contents_in_window \
     _bfd_generic_get_section_contents_in_window
#define vos_core_get_symtab_upper_bound _bfd_nosymbols_get_symtab_upper_bound
#define vos_core_get_symtab _bfd_nosymbols_get_symtab
#define vos_core_print_symbol _bfd_nosymbols_print_symbol
#define vos_core_get_symbol_info _bfd_nosymbols_get_symbol_info
#define vos_core_bfd_is_local_label_name \
  _bfd_nosymbols_bfd_is_local_label_name
#define vos_core_get_lineno _bfd_nosymbols_get_lineno
#define vos_core_find_nearest_line _bfd_nosymbols_find_nearest_line
#define vos_core_bfd_make_debug_symbol _bfd_nosymbols_bfd_make_debug_symbol
#define vos_core_read_minisymbols _bfd_nosymbols_read_minisymbols
#define vos_core_minisymbol_to_symbol _bfd_nosymbols_minisymbol_to_symbol

const bfd_target vos_core_vec =
  {
    "vos-core",
    bfd_target_vos_flavour,
#if defined (HOST_HPPAVOS)
    BFD_ENDIAN_BIG,            /* target byte order */
    BFD_ENDIAN_BIG,           /* target headers byte order */
#else
#if defined (HOST_X86VOS)
    BFD_ENDIAN_LITTLE,
    BFD_ENDIAN_LITTLE,
#else
#error CPU type not supported.
#endif /* defined (HOST_X86VOS) */
#endif /* defined (HOST_HPPAVOS) */

    (HAS_RELOC | EXEC_P |     /* object flags */
     HAS_LINENO | HAS_DEBUG |
     HAS_SYMS | HAS_LOCALS | WP_TEXT | D_PAGED),
    (SEC_HAS_CONTENTS | SEC_ALLOC | SEC_LOAD | SEC_RELOC), /* section flags */
    0,                                                  /* symbol prefix */
    ' ',                                 /* ar_pad_char */
    16,                                      /* ar_max_namelen */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 64 bit data */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 32 bit data */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 16 bit data */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 64 bit hdrs */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 32 bit hdrs */
    NO_GET, NO_SIGNED_GET, NO_PUT,     /* 16 bit hdrs */

    {                    /* bfd_check_format */
     _bfd_dummy_target,          /* unknown format */
     _bfd_dummy_target,          /* object file */
     _bfd_dummy_target,          /* archive */
     vos_core_core_file_p     /* a core file */
    },
    {                    /* bfd_set_format */
     bfd_false, bfd_false,
     bfd_false, bfd_false
    },
    {                    /* bfd_write_contents */
     bfd_false, bfd_false,
     bfd_false, bfd_false
    },

       BFD_JUMP_TABLE_GENERIC(vos_core),
       BFD_JUMP_TABLE_COPY (_bfd_generic),
       BFD_JUMP_TABLE_CORE (vos_core), /* See comment at top */
       BFD_JUMP_TABLE_ARCHIVE (_bfd_noarchive),
       BFD_JUMP_TABLE_SYMBOLS (vos_core),
       BFD_JUMP_TABLE_RELOCS (_bfd_norelocs),
       BFD_JUMP_TABLE_WRITE (_bfd_generic),
       BFD_JUMP_TABLE_LINK (_bfd_nolink),
       BFD_JUMP_TABLE_DYNAMIC (_bfd_nodynamic),

    (PTR) 0               /* backend_data */
};

#else
#error CPU type not supported.
#endif /* defined (HOST_HPPAVOS) || defined (HOST_X86VOS) */ 

