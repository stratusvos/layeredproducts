#ifndef TM_I386VOS_H
#define TM_I386VOS_H 1
/*  i386 machine native support for VOS              */

/* Mostly it's common to all i386's.  */
#include "i386/tm-i386.h"

#define VOS_TARGET
#define HOST_X86VOS
#define DEADVAL 0xdeaddead /* same in debug.pl1 */


/* Bug gnu_gdb-36.  VOS target dependent code has the pc pointing
   to the pc of the instruction making the call and not to the
   instruction following it. blockframe.c depends on this.
   */
#define DECR_PC_AFTER_CALL_IN_TRACEBACK(pc)  

/* Start of definition of VOS target-specific functions.
   */


/* From stack_frame_constants -- this value is only used in vos-read 
   gnu_gdb-95*/
#define ARGWORD0_OFFSET_MINUS_4    4
#define PARAMETER_LIST_VIRTUAL_ORIGIN ARGWORD0_OFFSET_MINUS_4


/* This macro has not been converted to set_gdbarch yet. */
#define PRINT_EXTRA_FRAME_INFO(fi) \
 i386_vos_print_extra_frame_info(fi);

void i386_vos_print_extra_frame_info(struct frame_info *fi);


/* MLF: added this new macro (used in breakpoint.c) as we have
     "extra" longjmp entry points due to second implementation
     created for POSIX/gcc. Use only one of _ux_longjmp, _ux_siglongjmp,
     as they are at the same address .. 
    */
#define MORE_LONGJMP_BREAKPOINTS create_longjmp_breakpoint("_ux_longjmp"); 


#define	EAX_REGNUM			0
#define ECX_REGNUM			1
#define EDX_REGNUM			2
#define EBX_REGNUM			3
#define ESP_REGNUM			4
#define EBP_REGNUM			5
#define ESI_REGNUM			6
#define EDI_REGNUM			7
#define LAST_INT_REGNUM			7

#define EIP_REGNUM			8
#define EFLAGS_REGNUM			9

#define FIRST_SR_REGNUM			10
#define CS_REGNUM			10
#define SS_REGNUM			11
#define DS_REGNUM			12
#define ES_REGNUM			13
#define FS_REGNUM			14
#define GS_REGNUM			15
#define LAST_SR_REGNUM			15

#include "solib.h"		/* Support for shared libraries. */


#endif /* ifndef TM_I386VOS_H */
