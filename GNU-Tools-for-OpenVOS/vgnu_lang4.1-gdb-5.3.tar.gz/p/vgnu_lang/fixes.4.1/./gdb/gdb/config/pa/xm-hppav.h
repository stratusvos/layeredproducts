/*  HP PA-RISC machine native support for VOS              */

#define READLINE_BROKEN

#define PTRACE_IN_WRONG_PLACE

#define LSEEK_NOT_LINEAR

#define   USE_FTELL

#include "pa/xm-pa.h"

#define IS_DIR_SEPARATOR(X) ((X) == '>' || (X) == '<' || (X) == '/')

#define IS_ABSOLUTE_PATH(X) (((X)[0] == '>') || ((X)[0] == '/') || ((X)[0] == '%') || \
 ((X)[0] == '#'))

#define ROOTED_P(X) (((X)[0] == '>') || ((X)[0] == '/') || ((X)[0] == '%') || \
 ((X)[0] == '#'))

#define SLASH_STRING ">"

#define USG

#define HAVE_TERMIOS

#define STRICT_CASTING_RULES

#define NO_INCOMPLETE_STRUCT_DEFS

#define NO_SYS_DIR_H

#define NO_SYS_FILE_H

#define NO_SYS_PARAM_H

