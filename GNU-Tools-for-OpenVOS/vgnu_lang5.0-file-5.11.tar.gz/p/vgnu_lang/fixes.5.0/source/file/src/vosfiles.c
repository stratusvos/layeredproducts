/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Ian F. Darwin and others.
 * 4. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "file.h"

#include <string.h>		/* for char_varying */

/*
 * object_groups.h and program_module.h contain shortmap (pack 2)
 * data structures.  Change the packing before including them,
 * then change it back again.
 */

#define $shortmap
#pragma pack(push,2)
#include "object_groups.h"
#include "program_module.h"
#include "keep_module.h"
#pragma pack(pop)
#undef $shortmap

/*
 *
 * VOS file headers are always big-endian.  If we are running in
 * a little-endian environment, we'll need to byte-swap values
 * larger than one byte.  If we're running on VOS, we can determine
 * at compile time whether we're running little-endian.  Otherwise,
 * we'll have to do a test at runtime.
 */

#define SWAPSHORT(val)	((short)((((val) >> 8) & 0x00FF) | \
				 (((val) << 8) & 0xFF00)))

#define SWAPLONG(val)	((long)((((val) >> 24) & 0x000000FF) | \
				(((val) >>  8) & 0x0000FF00) | \
				(((val) <<  8) & 0x00FF0000) | \
				(((val) << 24) & 0xFF000000)))

#ifdef __VOS__
#  ifdef __LITTLE_ENDIAN__
#    define BESHORT(val) (SWAPSHORT(val))
#    define BELONG(val) (SWAPLONG(val))
#  else
#    define BESHORT(val) (val)
#    define BELONG(val) (val)
#  endif
#else /* !VOS */

static const union {
    char c[2];
    int16_t s;
} swaptest = {0x00, 0x01};

#  define BEHOST (swaptest.s == 1)

#  define BESHORT(val) (BEHOST ? (val) : SWAPSHORT(val))
#  define BELONG(val) (BEHOST ? (val) : SWAPLONG(val))

#endif /* !VOS */


private const char *
processor_name(int processor)
{
    const char *result;

    switch (processor)	/* see lang_processor_numbers.h */
    {
    case (0):		result = "m68000";		break;
    case (1):		result = "m68010";		break;
    case (2):		result = "m68010 with SAP";	break;
    case (3):		result = "m68020";		break;
    case (4):		result = "m68020 with 68881";	break;
    case (5):		result = "m68030";		break;
    case (6):		result = "m68030 with 68882";	break;
    case (256):
    case (257):		result = "Intel 80860";		break;
    case (768):		result = "PA-RISC1.1";		break;
    case (769):		result = "PA-RISC2.0";		break;
    case (1280):	result = "Intel 80386";		break;
    default:		result = "unknown processor";	break;
    }

    return result;
}


private const char *
km_cpu_name(int cpu)
{
    const char *result;

    switch (cpu)	/* see cpu_version.h */
    {
    case (0):	result = "m68000";	break;
    case (1):	result = "m68010";	break;
    case (2):	result = "m68020";	break;
    case (3):	result = "m68030";	break;
    case (4):
    case (5):	result = "Intel 80860";	break;
    case (6):	result = "PA-RISC1.1";	break;
    case (7):
    case (8):
    case (9):	result = "PA-RISC2.0";	break;
    case (10):	result = "Intel 80386";	break;
    default:	result = "unknown cpu";	break;
    }

    return result;
}


private const char *
km_fp_cpu_name(int cpu)
{
    const char *result;

    switch (cpu)	/* see cpu_version.h */
    {
    case (1):	result = " with SAP";	break;
    case (2):	result = " with 68881";	break;
    case (3):	result = " with 68882";	break;
    default:	result = "";		break;
    }

    return result;
}


/*
 * file_is_vos: is the file in question a VOS relocatable object file,
 * 	program file, or keep (core) file?  Since these files don't
 *	have magic numbers, we have to look at multiple fields in their
 * 	headers and make an educated guess.
 */

protected int
file_is_vos(struct magic_set *ms, const unsigned char *buf, size_t nbytes)
{
    const char *dynamically_linked;
    const char *executable_type;
    const def_module_group *def_module_group_ptr;
    const program_module *program_module_ptr;
    const km_template *keep_module_ptr;

    /*
     * Is this a VOS relocatable object (*.obj) file?
     * If so, it should begin with a def_module group record.
     */

    def_module_group_ptr = (const def_module_group *)buf;

    if ((nbytes >= def_module_group_size) &&
	(def_module_group_ptr->gtype == def_module_gp) &&
	(def_module_group_ptr->gsize >= def_module_group_size / 2) &&
	(def_module_group_ptr->gsize <= sizeof(def_module_group) / 2) &&
	(BESHORT(def_module_group_ptr->compiler.len) >= 0) &&
	(BESHORT(def_module_group_ptr->compiler.len) <= 32) &&
	(BESHORT(def_module_group_ptr->options.len) >= 0) &&
	(BESHORT(def_module_group_ptr->options.len) <= 32) &&
	(BELONG(def_module_group_ptr->code_size) >= 0) &&
	(BELONG(def_module_group_ptr->static_size) >= 0) &&
	(BELONG(def_module_group_ptr->symtab_size) >= 0) &&
	(BESHORT(def_module_group_ptr->version) == 1) &&
	(BESHORT(def_module_group_ptr->user_name.len) >= 0) &&
	(BESHORT(def_module_group_ptr->user_name.len) <= 65) &&
	(BESHORT(def_module_group_ptr->system_name.len) >= 0) &&
	(BESHORT(def_module_group_ptr->system_name.len) <= 32) &&
	(BESHORT(def_module_group_ptr->source_path.len) >= 0) &&
	(BESHORT(def_module_group_ptr->source_path.len) <= 256))
    {
	if (file_printf(ms,
			"VOS relocatable, %s", 
			processor_name(BESHORT(def_module_group_ptr->processor))
			) == -1)
	    return -1;

	return 1;	

    } /* VOS relocatable object */

    /*
     * Is this a VOS executable program module?
     * Look for it to start with a program module header.
     */

    program_module_ptr = (const program_module *)buf;

    if ((nbytes >= sizeof(program_module)) &&
	(BESHORT(program_module_ptr->version) >= 1) &&
	(BESHORT(program_module_ptr->version) <= 2) &&
	(BESHORT(program_module_ptr->binder_version.len) >= 0) &&
	(BESHORT(program_module_ptr->binder_version.len) <= 32) &&
	(BESHORT(program_module_ptr->binder_options.len) >= 0) &&
	(BESHORT(program_module_ptr->binder_options.len) <= 32) &&
	(BESHORT(program_module_ptr->system_name.len) >= 0) &&
	(BESHORT(program_module_ptr->system_name.len) <= 32) &&
	(BESHORT(program_module_ptr->user_name.len) >= 0) &&
	(BESHORT(program_module_ptr->user_name.len) <= 65) &&
	(BESHORT(program_module_ptr->n_header_pages) == 1) &&
	(BELONG(program_module_ptr->header_len) >= 0) &&
	(BELONG(program_module_ptr->header_len) <= sizeof(program_module)) &&
	(BESHORT(program_module_ptr->release_name.len) >= 0) &&
	(BESHORT(program_module_ptr->release_name.len) <= 32) &&
	(BESHORT(program_module_ptr->copyright_notice.len) >= 0) &&
	(BESHORT(program_module_ptr->copyright_notice.len) <= 256) &&
	(BESHORT(program_module_ptr->program_name.len) >= 0) &&
	(BESHORT(program_module_ptr->program_name.len) <= 32))
    {
	executable_type =
		(BELONG(program_module_ptr->flags) &
		        program_module_flags_shared_library) ?
				"shared library" : "executable";

	dynamically_linked =
		(BELONG(program_module_ptr->dynamic_table_len) > 0) ?
				", dynamically linked" : "";

	if (file_printf(ms,
			"VOS %s, %s%s", 
			executable_type,
			processor_name(BESHORT(program_module_ptr->processor)),
			dynamically_linked
			) == -1)
	    return -1;

	return 1;
    }

    /*
     * Is this a VOS keep file?
     * Look for it to start with a keep module header.
     */

    keep_module_ptr = (const km_template *)buf;

    if ((nbytes >= sizeof(km_template)) &&
	(BESHORT(keep_module_ptr->version) >= 1) &&
	(BESHORT(keep_module_ptr->version) <= 5) &&
	(BESHORT(keep_module_ptr->keeper_version.len) >= 0) &&
	(BESHORT(keep_module_ptr->keeper_version.len) <= 32) &&
	(BESHORT(keep_module_ptr->keeper_options.len) >= 0) &&
	(BESHORT(keep_module_ptr->keeper_options.len) <= 32) &&
	(BESHORT(keep_module_ptr->system_name.len) >= 0) &&
	(BESHORT(keep_module_ptr->system_name.len) <= 32) &&
	(BESHORT(keep_module_ptr->user_name.len) >= 0) &&
	(BESHORT(keep_module_ptr->user_name.len) <= 65) &&
	(BESHORT(keep_module_ptr->program_path.len) >= 0) &&
	(BESHORT(keep_module_ptr->program_path.len) <= 256))
    {
	if (file_printf(ms,
			"VOS core file, %s%s, from '%v'", 
			km_cpu_name(BESHORT(keep_module_ptr->cpu_type)-1),
			km_fp_cpu_name(BESHORT(keep_module_ptr->fp_cpu_type)),
			&(keep_module_ptr->program_path)
			) == -1)
	    return -1;

	return 1;
    }

    /*
     * Not a VOS file type.
     */

    return 0;
}
