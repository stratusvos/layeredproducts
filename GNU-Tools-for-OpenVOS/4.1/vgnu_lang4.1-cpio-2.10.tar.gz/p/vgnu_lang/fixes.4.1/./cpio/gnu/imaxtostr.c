/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define inttostr imaxtostr
#define inttype intmax_t
#include "inttostr.c"
