#!/bin/sh

# Test a CP936 locale.
${CHECKER} ./test-mbrlen-w32${EXEEXT} Chinese_China 936
