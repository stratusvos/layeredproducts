#!/bin/sh

# Test a CP932 locale.
${CHECKER} ./test-mbrlen-w32${EXEEXT} Japanese_Japan 932
