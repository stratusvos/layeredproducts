#!/bin/sh

# Test a CP932 locale.
${CHECKER} ./test-c32rtomb-w32${EXEEXT} Japanese_Japan 932
