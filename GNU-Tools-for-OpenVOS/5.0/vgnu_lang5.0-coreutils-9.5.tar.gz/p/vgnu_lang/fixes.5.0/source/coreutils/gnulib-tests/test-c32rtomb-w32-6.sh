#!/bin/sh

# Test a CP950 locale.
${CHECKER} ./test-c32rtomb-w32${EXEEXT} Chinese_Taiwan 950
