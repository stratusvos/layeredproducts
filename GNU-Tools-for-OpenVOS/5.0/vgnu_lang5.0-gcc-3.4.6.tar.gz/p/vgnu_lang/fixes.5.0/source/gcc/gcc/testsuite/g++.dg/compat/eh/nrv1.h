struct A
{
  A();
  ~A();
};
