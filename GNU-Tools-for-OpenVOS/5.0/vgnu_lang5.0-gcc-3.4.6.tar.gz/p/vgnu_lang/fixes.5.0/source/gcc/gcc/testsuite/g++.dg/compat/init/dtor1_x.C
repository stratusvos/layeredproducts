#include "dtor1.h"

void
dtor1_x (void)
{
  A a;
}
