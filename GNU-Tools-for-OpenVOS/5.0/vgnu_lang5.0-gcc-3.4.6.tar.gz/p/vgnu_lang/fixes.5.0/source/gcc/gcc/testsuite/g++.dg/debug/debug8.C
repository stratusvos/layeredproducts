struct t{};
struct g : public t{};
