/* Definitions for PA_RISC with ELF format for Stratus VOS
   Copyright 1999, 2000, 2001, 2002 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* The VOS runtime conventions are a mix of the HPUX/PRO conventions
   and the portable conventions.  Here is a brief summary:
   * Register argument passing follows the portable conventions.
   * %r27 is the combined DP, DLT and TP (thread pointer), so it is not
     constant, but changes at executable boundaries and thread switches.
     Any function that changes %r27 is responsible for restoring it.
   * Static and external data are thread-private by default,
     and should always be addressed using %r27.  External data
     shared between threads should be addressed indirectly (a la PIC).
   * Indirect calls must set up %r29 (the static chain ptr)
     as well as %r27 for the called function.
   * Function pointers always point to three-word entry variables,
     which contain a code address, DP and static chain ptr.
   * Data space is execute-protected, so trampolines cannot contain code.
     Instead, they consist entirely of a three-word entry variable.
   * The VOS linker (bind) can create import stubs (glue code), which
     automatically save and restore %r27 themselves.  There are no
     export stubs.
   * The VOS binder cannot create long branch stubs, so all calls must
     be able to reach the entire address space. */

#undef TARGET_VOS_RUNTIME
#define TARGET_VOS_RUNTIME 1

/* Make GCC agree with types.h.  */
#undef SIZE_TYPE
#undef PTRDIFF_TYPE

#define SIZE_TYPE "long unsigned int"
#define PTRDIFF_TYPE "long int"

#undef WCHAR_TYPE
#define WCHAR_TYPE "long int"

#undef WCHAR_TYPE_SIZE
#define WCHAR_TYPE_SIZE BITS_PER_WORD

/* On VOS, char's are unsigned by default. */
#undef DEFAULT_SIGNED_CHAR
#define DEFAULT_SIGNED_CHAR 0

/* Turn off various SOM crap we don't want. [pa32-linux-h, verbatim] */
#undef TARGET_ELF32
#define TARGET_ELF32 1

/* gcc on HPPA VOS uses stabs, not dwarf or dwarf2. */
#define DBX_DEBUGGING_INFO 1
#undef DWARF_DEBUGGING_INFO
#undef DWARF2_DEBUGGING_INFO

#undef PREFERRED_DEBUGGING_TYPE
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG

/* System header files have C-linkage by default. */
/* #define NO_IMPLICIT_EXTERN_C */

/* Use SVR4 semantics for __STDC__ (1==strict ANSI, 0==ANSI)
   when processing system header files. */
#define STDC_0_IN_SYSTEM_HEADERS 1

/* Enable parsing of #pragma pack(push,<n>) and #pragma pack(pop).  */
#define HANDLE_PRAGMA_PACK_PUSH_POP 1

/* Don't weaken references to pthread runtimes, because then the binder
   won't load them from the object library. */
#define GTHREAD_USE_WEAK 0

/* VOS trampoline stuff.  We don't need a trampoline template.
   Initializing a trampoline is a matter of copying the entry variable
   and replacing the first word with the static chain pointer. */

#undef TRAMPOLINE_TEMPLATE

#undef TRAMPOLINE_SIZE
#define TRAMPOLINE_SIZE (3 * 4)

#undef INITIALIZE_TRAMPOLINE
#define INITIALIZE_TRAMPOLINE(TRAMP, FNADDR, CXT) \
{									\
  rtx src_addr, dest_addr;						\
									\
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 0)); \
  emit_move_insn (gen_rtx (MEM, Pmode, dest_addr), (CXT));        \
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 4)); \
  src_addr = memory_address (Pmode, plus_constant ((FNADDR), 4)); \
  emit_move_insn (gen_rtx (MEM, Pmode, dest_addr),                \
                  gen_rtx (MEM, Pmode, src_addr));                \
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 8)); \
  src_addr = memory_address (Pmode, plus_constant ((FNADDR), 8)); \
  emit_move_insn (gen_rtx (MEM, Pmode, dest_addr),                \
                  gen_rtx (MEM, Pmode, src_addr));                \
}

/* Use the .ctors and .dtors section for constructors and
   destructors, but don't use the .init and .fini sections,
   since VOS does not support their special semantics. */
#define CTORS_SECTION_ASM_OP    "\t.section\t.ctors,\"aw\""
#define DTORS_SECTION_ASM_OP    "\t.section\t.dtors,\"aw\""

#undef INIT_SECTION_ASM_OP
#undef FINI_SECTION_ASM_OP

/* Tell libgcc that __CTOR_LIST__ and __DTOR_LIST__ are defined externally,
   ie in our crti and crtn. */
#define CTOR_LISTS_DEFINED_EXTERNALLY

/* While the VOS binder does support weak symbols, it does not support
   COMDAT functionality, ie the removal of code and/or data associated
   with redundant weak symbols.  And the long section names generated
   to support this aren't accepted by the VOS binder. */
#define SUPPORTS_ONE_ONLY 0

/* Start of copy from pa-linux.h. */

#undef STRING_ASM_OP
#define STRING_ASM_OP	"\t.stringz\t"

#undef ASM_FILE_START
#define ASM_FILE_START(FILE) \
  do								\
    {								\
      if (write_symbols != NO_DEBUG)				\
	{							\
	  output_file_directive (FILE, main_input_filename);	\
	}							\
      if (TARGET_PA_20)						\
	fputs("\t.LEVEL 2.0\n", FILE);				\
      else if (TARGET_PA_11)					\
	fputs("\t.LEVEL 1.1\n", FILE);				\
      else							\
	fputs("\t.LEVEL 1.0\n", FILE);				\
      if (profile_flag)						\
	fputs ("\t.IMPORT _mcount, CODE\n", FILE);		\
    }								\
   while (0)

/* We want local labels to start with period if made with asm_fprintf.  */
#undef LOCAL_LABEL_PREFIX
#define LOCAL_LABEL_PREFIX "."

/* Define these to generate the Linux/ELF/SysV style of internal
   labels all the time - i.e. to be compatible with
   ASM_GENERATE_INTERNAL_LABEL in <elfos.h>.  Compare these with the
   ones in pa.h and note the lack of dollar signs in these.  FIXME:
   shouldn't we fix pa.h to use ASM_GENERATE_INTERNAL_LABEL instead? */

#undef ASM_OUTPUT_ADDR_VEC_ELT
#define ASM_OUTPUT_ADDR_VEC_ELT(FILE, VALUE) \
  if (TARGET_BIG_SWITCH)					\
    fprintf (FILE, "\tstw %%r1,-16(%%r30)\n\tldil LR'.L%d,%%r1\n\tbe RR'.L%d(%%sr4,%%r1)\n\tldw -16(%%r30),%%r1\n", VALUE, VALUE);		\
  else								\
    fprintf (FILE, "\tb .L%d\n\tnop\n", VALUE)

#undef ASM_OUTPUT_ADDR_DIFF_ELT
#define ASM_OUTPUT_ADDR_DIFF_ELT(FILE, BODY, VALUE, REL) \
  if (TARGET_BIG_SWITCH)					\
    fprintf (FILE, "\tstw %%r1,-16(%%r30)\n\tldw T'.L%d(%%r19),%%r1\n\tbv %%r0(%%r1)\n\tldw -16(%%r30),%%r1\n", VALUE);				\
  else								\
    fprintf (FILE, "\tb .L%d\n\tnop\n", VALUE)

/* Use the default.  */
#undef ASM_OUTPUT_LABEL

/* NOTE: ASM_OUTPUT_INTERNAL_LABEL() is defined for us by elfos.h, and
   does what we want (i.e. uses colons).  It must be compatible with
   ASM_GENERATE_INTERNAL_LABEL(), so do not define it here.  */

/* Use the default.  */
#undef TARGET_ASM_GLOBALIZE_LABEL
/* Globalizing directive for a label.  */
#define GLOBAL_ASM_OP "\t.globl\t"

/* FIXME: Hacked from the <elfos.h> one so that we avoid multiple
   labels in a function declaration (since pa.c seems determined to do
   it differently)  */

#undef ASM_DECLARE_FUNCTION_NAME
#define ASM_DECLARE_FUNCTION_NAME(FILE, NAME, DECL)		\
  do								\
    {								\
      ASM_OUTPUT_TYPE_DIRECTIVE (FILE, NAME, "function");	\
      ASM_DECLARE_RESULT (FILE, DECL_RESULT (DECL));		\
    }								\
  while (0)

/* As well as globalizing the label, we need to encode the label
   to ensure a plabel is generated in an indirect call.  */

#undef ASM_OUTPUT_EXTERNAL_LIBCALL
#define ASM_OUTPUT_EXTERNAL_LIBCALL(FILE, FUN)  		\
  do								\
    {								\
      if (!FUNCTION_NAME_P (XSTR (FUN, 0)))			\
	hppa_encode_label (FUN);				\
      (*targetm.asm_out.globalize_label) (FILE, XSTR (FUN, 0));	\
    }								\
  while (0)

/* End of copy from pa-linux.h */

/* Specfile stuff. */

#undef TARGET_CPU_CPP_BUILTINS
#define TARGET_CPU_CPP_BUILTINS()				\
  do								\
    {								\
	builtin_assert ("cpu=hppa");				\
	builtin_assert ("machine=hppa");			\
								\
	builtin_define_std ("hppa");				\
								\
	builtin_define ("__HPPA__");				\
								\
	if (TARGET_PA_20)					\
	  {							\
	    builtin_define ("__HPPA20__");			\
	    builtin_define ("__PA8000__");			\
	    builtin_define ("_PA_RISC2_0");			\
	  }							\
	else if (TARGET_PA_11)					\
	  {							\
	    builtin_define ("__HPPA11__");			\
	    builtin_define ("__PA7100__");			\
	    builtin_define ("_PA_RISC1_1");			\
	  }							\
	else							\
	  {							\
	    builtin_define ("__HPPA10__");			\
	    builtin_define ("_PA_RISC1_0");			\
	  }							\
    }								\
  while (0)


#undef TARGET_OS_CPP_BUILTINS
#define TARGET_OS_CPP_BUILTINS()				\
  do								\
    {								\
	builtin_assert ("system=vos");				\
								\
	builtin_define ("__VOS__=14");				\
	builtin_define ("_UX_SETJMP");				\
	builtin_define ("__NO_GENERIC_FUNCTIONS__");		\
								\
	if ((c_language != clk_c) || !preprocessing_trad_p())	\
	  builtin_define ("__PROTOTYPES__");			\
								\
	if (!preprocessing_asm_p())				\
	  if (!flag_iso || !pedantic)				\
	    builtin_define ("$longmap=");			\
								\
	if (flag_signed_char)					\
	  builtin_define ("__CHAR_IS_SIGNED__");		\
    }								\
  while (0)

/* Linking specs. */

#undef MD_EXEC_PREFIX
#define MD_EXEC_PREFIX "/system/command_library/"

#undef LINK_SPEC
#define LINK_SPEC ""

/* LINK_LIBGCC_SPECIAL causes the gcc driver to search for libgcc itself.
   LINK_LIBRARIES_SPECIAL is a Stratus addition to gcc, and causes the
   driver to search for all libraries the same way. */
#define LINK_LIBGCC_SPECIAL
#define LINK_LIBRARIES_SPECIAL

#undef LIB_SPEC
#define LIB_SPEC ""

#undef LINK_GCC_C_SEQUENCE_SPEC
#define LINK_GCC_C_SEQUENCE_SPEC "%G %L"

#undef STARTFILE_SPEC
#define STARTFILE_SPEC "-object_modules_before s_start_c_program.obj%s crti.o%s"

#undef ENDFILE_SPEC
#define ENDFILE_SPEC "-object_modules_after crtn.o%s"

/* Tell gcc how to invoke the VOS binder.  This spec is cloned from
   link_command_spec in gcc.c.  The %-sequences it uses are:
     %l   LINK_SPEC
     %X   accumulated linker options from compilations
     %S   STARTFILE_SPEC
     %o   all object file names
     %G   LIBGCC_SPEC 
     %L   LIB_SPEC
     %E   ENDFILE_SPEC
   These are the gcc command-line options that get passed to the
   linker:
     -o   name output file
     -e   define entry point
     -r   create a relocatable .o output file
     -s   strip symbol table
     -l   archive library name (may be repeated)
     -L   archive library search directory (may be repeated)
   Note the -l and -L are more like arguments than options, since they
   may be repeated, and their position in the command line is significant. */

#define LINKER_NAME "bind"

#define LINK_COMMAND_SPEC \
"%{!fsyntax-only:%{!c:%{!M:%{!MM:%{!E:%{!S:\
 %(linker)\
 -no_dynamic_tasking\
 %l\
 %X\
 %{o*:-pm_name %*}\
 %{!o*:-pm_name %b}\
 %{e*:-entry %*}\
 %{r:%eThe ld -r option is not supported on VOS\n}\
 %{!s:-retain_all} %{s:-no_table}\
 %{static:}\
 %{--help:-usage}\
 %o\
 %{!nostdlib:%{!nodefaultlibs:%(link_gcc_c_sequence)}}\
 %{!nostdlib:%{!nostartfiles:%S}}\
 %{!nostdlib:%{!nostartfiles:%E}}\
 %{L*:-search %*}\
 \n\
}}}}}}"

/* Define this if system has no math library.  This inhibits
   automatic inclusion of "-lm" on the g++ command line. */
#define MATH_LIBRARY ""
#define MATH_LIBRARY_PROFILE ""
