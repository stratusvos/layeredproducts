/* Copyright (C) 2000 Free Software Foundation, Inc.  */

/* { dg-do preprocess } */
/* { dg-options "-std=c++98" } */

/* This file is for testing the preprocessor in -std=c++98 mode.
   Neil Booth, 2 Dec 2000.  */

#if 1LL
#endif
