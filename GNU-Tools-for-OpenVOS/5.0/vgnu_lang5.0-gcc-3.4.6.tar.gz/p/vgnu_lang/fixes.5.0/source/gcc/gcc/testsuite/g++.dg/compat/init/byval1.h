struct C
{
  int m;
  C();
  ~C();
};
