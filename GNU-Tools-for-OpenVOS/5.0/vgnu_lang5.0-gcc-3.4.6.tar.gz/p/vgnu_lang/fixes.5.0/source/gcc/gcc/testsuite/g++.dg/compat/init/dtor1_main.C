// Split into pieces for binary compatibility testing October 2002

extern void dtor1_x (void);

int
main ()
{
  dtor1_x ();
}
