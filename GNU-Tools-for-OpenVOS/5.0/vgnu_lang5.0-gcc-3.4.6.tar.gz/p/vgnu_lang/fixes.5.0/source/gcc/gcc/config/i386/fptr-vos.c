/* Subroutine for function pointer canonicalization on i386 VOS. */

void *
__canonicalize_funcptr_for_compare (void *fptr)
{
  /* Page 0 and -1 are special.  Page 0 includes NULL and some of
     the special values used by signal().  -1 is used in crtend
     to mark the end of a list of function pointers. */
  if (((unsigned int) fptr < 4096) || ((int) fptr == -1))
    return fptr;

  /* The function points to a three-word entry variable.  Return the
     code pointer, which is the middle word. */
  return ((void **)fptr)[1];
}
