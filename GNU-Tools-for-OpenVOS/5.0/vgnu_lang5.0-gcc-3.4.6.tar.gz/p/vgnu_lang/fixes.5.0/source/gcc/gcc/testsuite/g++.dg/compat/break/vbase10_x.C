#include "vbase10.h"

extern void vbase10_y (C&);

void vbase10_x ()
{
  C c;

  c.c1 = 1;
  c.c2 = 2;

  vbase10_y (c);
}
