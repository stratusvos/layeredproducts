/* Subroutine for function pointer canonicalization on PA-RISC VOS.
   Written to be functionally equivalent to ELF32 for PA-RISC in
   config/pa/fptr.c.  Much simpler because it does not have to deal
   with deferred resolution of dynamic links. */

typedef int (*fptr_t) (void);

unsigned int
__canonicalize_funcptr_for_compare (fptr)
     fptr_t fptr;
{
  /* -1 and page 0 are special.  -1 is used in crtend to mark the end of
     a list of function pointers.  Page 0 includes NULL and some of
     the special values used by signal(). */
  if (((int) fptr == -1) || ((unsigned int) fptr < 4096))
    return (unsigned int) fptr;

  /* The function points to a three-word entry variable.  Return the
     code pointer, which is the middle word. */
  return ((unsigned int *)fptr)[1];
}
