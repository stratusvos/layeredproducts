struct Foo
{
  ~Foo ();
};

struct Bar
{
  ~Bar ();
  Foo f;
};
