struct A {};

struct B {
  A a;
  virtual void f () {}
  int i;
};
