const char *getval (const char *);
const char *get_expander (const char *);
void read_config_file (const char *cf);

extern struct dirs cfdirlist;
extern const char *configuration_file;
