# Time-stamp: "Sat Jul 14 00:27:21 2001 by Automatic Bizooty (__blocks2pm.plx)"
$Text::Unidecode::Char[0x04] = [
'Ie', 'Io', 'Dj', 'Gj', 'Ie', 'Dz', 'I', 'Yi', 'J', 'Lj', 'Nj', 'Tsh', 'Kj', 'I', 'U', 'Dzh',
'A', 'B', 'V', 'G', 'D', 'Ie', 'Zh', 'Z', 'I', 'I', 'K', 'L', 'M', 'N', 'O', 'P',
'R', 'S', 'T', 'U', 'F', 'Kh', 'Ts', 'Ch', 'Sh', 'Shch', "", 'Y', qq{'}, 'E', 'Iu', 'Ia',
'a', 'b', 'v', 'gh', 'd', 'ie', 'zh', 'z', 'i', 'i', 'k', 'l', 'm', 'n', 'o', 'p',
'r', 's', 't', 'u', 'f', 'kh', 'ts', 'ch', 'sh', 'shch', "", 'y', qq{'}, 'e', 'iu', 'ia',
'ie', 'io', 'dj', 'gj', 'ie', 'dz', 'i', 'yi', 'j', 'lj', 'nj', 'tsh', 'kj', 'i', 'u', 'dzh',
'O', 'o', 'E', 'e', 'Ie', 'ie', 'E', 'e', 'Ie', 'ie', 'O', 'o', 'Io', 'io', 'Ks', 'ks',
'Ps', 'ps', 'F', 'f', 'Y', 'y', 'Y', 'y', 'u', 'u', 'O', 'o', 'O', 'o', 'Ot', 'ot',
'Q', 'q', qq{*1000*}, "", "", "", "", '[?]', qq{*100.000*}, qq{*1.000.000*}, '[?]', '[?]', qq{"}, qq{"}, qq{R'}, qq{r'},
qq{G'}, qq{g'}, qq{G'}, qq{g'}, qq{G'}, qq{g'}, qq{Zh'}, qq{zh'}, qq{Z'}, qq{z'}, qq{K'}, qq{k'}, qq{K'}, qq{k'}, qq{K'}, qq{k'},
qq{K'}, qq{k'}, qq{N'}, qq{n'}, 'Ng', 'ng', qq{P'}, qq{p'}, 'Kh', 'kh', qq{S'}, qq{s'}, qq{T'}, qq{t'}, 'U', 'u',
qq{U'}, qq{u'}, qq{Kh'}, qq{kh'}, 'Tts', 'tts', qq{Ch'}, qq{ch'}, qq{Ch'}, qq{ch'}, 'H', 'h', 'Ch', 'ch', qq{Ch'}, qq{ch'},
qq{`}, 'Zh', 'zh', qq{K'}, qq{k'}, '[?]', '[?]', qq{N'}, qq{n'}, '[?]', '[?]', 'Ch', 'ch', '[?]', '[?]', '[?]',
'a', 'a', 'A', 'a', 'Ae', 'ae', 'Ie', 'ie', qq{\@}, qq{\@}, qq{\@}, qq{\@}, 'Zh', 'zh', 'Z', 'z',
'Dz', 'dz', 'I', 'i', 'I', 'i', 'O', 'o', 'O', 'o', 'O', 'o', 'E', 'e', 'U', 'u',
'U', 'u', 'U', 'u', 'Ch', 'ch', '[?]', '[?]', 'Y', 'y', '[?]', '[?]', '[?]', '[?]', '[?]',
];
1;
