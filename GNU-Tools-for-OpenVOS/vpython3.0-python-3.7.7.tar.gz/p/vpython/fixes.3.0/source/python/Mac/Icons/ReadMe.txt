The icons for use on MacOS X were created by Jacob Rus <jrus@fas.harvard.edu>
with some feedback from the folks on pythonmac-sig@python.org.

