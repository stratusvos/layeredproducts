/* convert.h - definitions for convert.c */
char *convert_to_texinfo (ELEMENT *e);
char *convert_to_text (ELEMENT *e, int *superfluous_arg);
char *node_extra_to_texi (NODE_SPEC_EXTRA *nse);
