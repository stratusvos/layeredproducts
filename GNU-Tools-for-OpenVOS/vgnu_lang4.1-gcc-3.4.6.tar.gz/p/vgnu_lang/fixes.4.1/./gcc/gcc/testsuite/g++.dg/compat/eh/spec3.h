class Base {};

struct A : virtual public Base
{
  A();
};

struct B {};
