/* Copyright (C) 2003 Free Software Foundation, Inc.  */

/* { dg-do preprocess } */
/* { dg-options "-c -include ${srcdir}/g++.dg/cpp/c++_cmd_1.h" } */

/* Contributed by Devang Patel  <dpatel@apple.com>  */

int main ()
{
	return 0;
}

