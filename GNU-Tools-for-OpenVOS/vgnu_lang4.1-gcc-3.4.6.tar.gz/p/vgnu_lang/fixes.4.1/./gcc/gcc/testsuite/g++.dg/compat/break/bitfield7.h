union U {
  int i: 4096;
};
