/* Copyright (C) 2003 Free Software Foundation, Inc.  */

/* Contributed by Devang Patel  <dpatel@apple.com>  */

/* Header file for c++_cmd_1.C */

