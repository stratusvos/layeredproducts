// { dg-options "-w" }

struct S {
  int i : 64;
};
