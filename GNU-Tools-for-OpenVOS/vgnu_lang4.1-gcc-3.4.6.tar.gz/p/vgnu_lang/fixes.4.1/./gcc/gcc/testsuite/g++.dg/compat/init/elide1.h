struct A {
  A ();
  A (const A&);
  ~A ();
};
