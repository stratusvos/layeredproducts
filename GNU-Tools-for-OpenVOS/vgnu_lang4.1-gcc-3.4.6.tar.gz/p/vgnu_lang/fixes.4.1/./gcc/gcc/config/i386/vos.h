/* Definitions for i386 with ELF format for Stratus VOS
   Copyright 1999, 2000, 2001, 2002 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* Make GCC agree with types.h.  */
#undef SIZE_TYPE
#define SIZE_TYPE "long unsigned int"

#undef PTRDIFF_TYPE
#define PTRDIFF_TYPE "long int"

#undef WCHAR_TYPE
#define WCHAR_TYPE "long int"

#undef WCHAR_TYPE_SIZE
#define WCHAR_TYPE_SIZE BITS_PER_WORD

/* On VOS, char's are unsigned by default. */
#undef DEFAULT_SIGNED_CHAR
#define DEFAULT_SIGNED_CHAR 0

/* On VOS, the long double type is 64, not 80, bits in size. */
#undef LONG_DOUBLE_TYPE_SIZE
#define LONG_DOUBLE_TYPE_SIZE 64

#undef LIBGCC2_LONG_DOUBLE_TYPE_SIZE
#define LIBGCC2_LONG_DOUBLE_TYPE_SIZE 64

#undef MAX_LONG_DOUBLE_TYPE_SIZE
#define MAX_LONG_DOUBLE_TYPE_SIZE 64

/* Subtarget options.  */

#define MASK_LITTLE_ENDIAN	0x40000000

#undef SUBTARGET_SWITCHES
#define SUBTARGET_SWITCHES \
  { "little-endian",		MASK_LITTLE_ENDIAN, \
    N_("Produce little endian code") }, \
  { "big-endian",		-MASK_LITTLE_ENDIAN, \
    N_("Produce big endian code") },

/* Optionally, enable compiler support for VOS's big-endian ABI. */
#undef SUPPORT_OTHER_ENDIANNESS
#define SUPPORT_OTHER_ENDIANNESS ((target_flags & MASK_LITTLE_ENDIAN) == 0)

#undef LD_SUPPORT_OTHER_ENDIANNESS
#define LD_SUPPORT_OTHER_ENDIANNESS 1

/* LIBGCC2_WORDS_BIG_ENDIAN is used in compiling libgcc2.c and has to
   be a compile-time constant.  */
#define LIBGCC2_WORDS_BIG_ENDIAN (!defined(__LITTLE_ENDIAN__))

/* VOS always passes a PIC_OFFSET_TABLE pointer, passing it in %edx.  */
#undef FUNCTION_ALWAYS_PASS_PIC_OFFSET_TABLE
#define FUNCTION_ALWAYS_PASS_PIC_OFFSET_TABLE 1

#define PIC_OFFSET_TABLE_INCOMING_REGNUM 1

/* VOS passes the address of the structure return_value in %eax.  */
#undef STRUCT_VALUE
#define STRUCT_VALUE_REGNUM 0

/* VOS cannot support the regparm attribute on IA32.  */
#undef REGPARM_MAX
#define REGPARM_MAX (TARGET_64BIT ? 6 : 0)

#undef STRUCT_VALUE_INCOMING
/* #define STRUCT_VALUE_INCOMING_REGNUM 0 */

/* VOS return never pops arguments.  */
#undef RETURN_POPS_ARGS
#define RETURN_POPS_ARGS(FUNDECL, FUNTYPE, SIZE) 0

/* Always turn on VOS-style stack-integrity checking. */
#undef SUPPORT_CANARIES
#define SUPPORT_CANARIES 1

/* On VOS, function pointers are always indirect. */
#undef SUPPORT_VOS_FUNCTION_POINTERS
#define SUPPORT_VOS_FUNCTION_POINTERS 1

/* We trust the caller of main.  */
#undef FORCE_PREFERRED_STACK_BOUNDARY_IN_MAIN

/* Enable all the other ways that the VOS runtime conventions
   differ from the generic ones. */
#undef TARGET_VOS_RUNTIME
#define TARGET_VOS_RUNTIME 1

#undef TARGET_VERSION
#define TARGET_VERSION fprintf (stderr, " (i386 Stratus VOS)");

/* Change debugging to Dwarf2.  */
#undef PREFERRED_DEBUGGING_TYPE
#define PREFERRED_DEBUGGING_TYPE DWARF2_DEBUG

/* But don't use dwarf2 info for unwind exception handling. */
#undef INCOMING_RETURN_ADDR_RTX

/* Use our extensions to DWARF2. */
#define VOS_DEBUGGING_INFO 1

/* System header files have C-linkage by default. */
/* #define NO_IMPLICIT_EXTERN_C */

/* Use SVR4 semantics for __STDC__ (1==strict ANSI, 0==ANSI)
   when processing system header files. */
#define STDC_0_IN_SYSTEM_HEADERS 1

/* Enable parsing of #pragma pack(push,<n>) and #pragma pack(pop).  */
#define HANDLE_PRAGMA_PACK_PUSH_POP 1

/* Don't weaken references to pthread runtimes, because then the binder
   won't load them from the object library. */
#define GTHREAD_USE_WEAK 0

/* VOS trampoline stuff.  We don't need a trampoline template.
   Initializing a trampoline ias a matter of copying the entry variable,
   replacing the first word with the static chain pointer.  */
#undef TRAMPOLINE_TEMPLATE

#undef TRAMPOLINE_SIZE
#define TRAMPOLINE_SIZE (3 * 4)

#undef INITIALIZE_TRAMPOLINE
#define INITIALIZE_TRAMPOLINE(TRAMP, FNADDR, CXT) \
{                                                 \
  rtx src_base, src_addr, dest_addr, dest_rtx;	  \
  tree hold_expr;                                 \
                                                  \
  src_base = copy_to_mode_reg (Pmode, (FNADDR));                  \
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 0)); \
  dest_rtx = gen_rtx (MEM, Pmode, dest_addr);                     \
  hold_expr = MEM_EXPR (dest_rtx);                                \
  set_mem_expr (dest_rtx, (tree) -1);				  \
  emit_move_insn (dest_rtx, (CXT));				  \
  set_mem_expr (dest_rtx, hold_expr);				  \
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 4)); \
  src_addr = memory_address (Pmode, plus_constant (src_base, 4)); \
  emit_move_insn (gen_rtx (MEM, Pmode, dest_addr),	          \
                  gen_rtx (MEM, Pmode, src_addr));                \
  dest_addr = memory_address (Pmode, plus_constant ((TRAMP), 8)); \
  src_addr = memory_address (Pmode, plus_constant (src_base, 8)); \
  emit_move_insn (gen_rtx (MEM, Pmode, dest_addr),                \
                  gen_rtx (MEM, Pmode, src_addr));                \
}
  
/* Use the .ctors and .dtors section for constructors and
   destructors, but don't use the .init and .fini sections,
   since VOS does not support their special semantics. */
#define CTORS_SECTION_ASM_OP    "\t.section\t.ctors,\"aw\""
#define DTORS_SECTION_ASM_OP    "\t.section\t.dtors,\"aw\""

#undef INIT_SECTION_ASM_OP
#undef FINI_SECTION_ASM_OP

/* Tell libgcc that __CTOR_LIST__ and __DTOR_LIST__ are defined externally,
   ie in our crti and crtn. */
#define CTOR_LISTS_DEFINED_EXTERNALLY

/* Replace the standard __do_global_ctors and __do_global_dtors code
   (in libgcc2.c) with our own code.  Instead of traversing .ctors and
   .dtors themselves, they call our code (in crti and crtn) to do it. */
#define DO_GLOBAL_CTORS_BODY 			\
{						\
   extern void __do_global_ctors_1(void);	\
   __do_global_ctors_1();			\
}

#define DO_GLOBAL_DTORS_BODY			\
{						\
   extern void __do_global_dtors_1(void);	\
   __do_global_dtors_1();			\
}

/* While the VOS binder does support weak symbols, it does not support
   COMDAT functionality, ie the removal of code and/or data associated
   with redundant weak symbols.  And the long section names generated
   to support this aren't accepted by the VOS binder. */
#define SUPPORTS_ONE_ONLY 0

/* While the VOS binder does support named sections, it restricts section
   name lengths.  Therefore, the -ffunction-sections and -fdata-sections
   options must be disabled. */
#define SUBTARGET_OVERRIDE_OPTIONS					\
  do {									\
    if (flag_function_sections)						\
      {									\
	warning ("-ffunction-sections not supported for this target");	\
	flag_function_sections = 0;					\
      }									\
    if (flag_data_sections)						\
      {									\
	warning ("-fdata-sections not supported for this target");	\
	flag_data_sections = 0;						\
      }									\
  } while (0)

/* Override the default comment start "/" with "#" */
#undef ASM_COMMENT_START
#define ASM_COMMENT_START "#"

/* The runtime symbol table should use the same register mapping as
   SVR4 and Linux.  */
#undef DBX_REGISTER_NUMBER
#define DBX_REGISTER_NUMBER(n) \
  (TARGET_64BIT ? dbx64_register_map[n] : svr4_dbx_register_map[n])

/* We use these sequence to modify the endianness of constants.  */

#ifndef ASM_OUTPUT_PUSHENDIAN
#define ASM_OUTPUT_PUSHENDIAN(FILE, VALUE) \
do {                                       \
   fputs ("\t.pushendian\t", FILE);          \
   fputs (VALUE, FILE);                    \
   fputc ('\n', FILE);                     \
   } while (0) 
#endif

#ifndef ASM_OUTPUT_PUSHOTHERENDIAN
#define ASM_OUTPUT_PUSHOTHERENDIAN(FILE) ASM_OUTPUT_PUSHENDIAN((FILE), "big")
#endif

#ifndef ASM_OUTPUT_POPENDIAN
#define ASM_OUTPUT_POPENDIAN(FILE)         \
do {                                       \
   fputs ("\t.popendian\n", FILE);           \
   } while (0)
#endif

/* VOS uses a proprietary set of data structures to do stack tracing and
   unwinding.  A set of lookup tables ("block maps") map code addresses to
   information ("entry blocks" )about the function containing that address. */

#undef ASM_OUTPUT_SPECIAL_POOL_ENTRY
#define ASM_OUTPUT_SPECIAL_POOL_ENTRY(FILE, X, MODE, ALIGN, LABELNO, JUMPTO) \
{                                                                            \
  if (GET_CODE (X) == CONST && GET_CODE (XEXP (X, 0)) == UNSPEC)             \
    switch (XINT (XEXP (X, 0), 1))                                           \
      {                                                                      \
      case UNSPEC_VOS_ENTRY_BLOCK:					     \
        {								     \
          rtx unspec_op = XEXP (X, 0);					     \
          vos_ix86_output_entry_block					     \
				(FILE, ALIGN, LABELNO, 0,		     \
                                 XINT (XVECEXP (unspec_op, 0, 0), 0),	     \
                                 XINT (XVECEXP (unspec_op, 0, 1), 0),	     \
                                 XINT (XVECEXP (unspec_op, 0, 2), 0),	     \
                                 XINT (XVECEXP (unspec_op, 0, 3), 0));	     \
        }								     \
	goto JUMPTO;		                                             \
      default:								     \
        break;								     \
      }									     \
} 

#undef ASM_DECODE_SPECIAL_POOL_ENTRY
#define ASM_DECODE_SPECIAL_POOL_ENTRY(VALUE)                                 \
{									     \
  if (XINT ((VALUE)->un.addr.base, 1) == UNSPEC_VOS_ENTRY_BLOCK)	     \
    {									     \
      int i, units;							     \
      (VALUE)->kind = RTX_UNSPEC + UNSPEC_VOS_ENTRY_BLOCK;		     \
      units = XVECLEN ((VALUE)->un.addr.base, 0);			     \
      for (i = 0; i < units; i++) 					     \
        (VALUE)->un.int_vec[i].low = 					     \
		XINT (XVECEXP ((VALUE)->un.addr.base, 0, i), 0);	     \
      (VALUE)->un.addr.base = 0;					     \
    }									     \
}

/* The following allows us to output the dummy block map entry at the end
   of a function.  */

#undef ASM_DECLARE_FUNCTION_SIZE
#define ASM_DECLARE_FUNCTION_SIZE(FILE, FNAME, DECL)			\
  do {									\
    if (!flag_inhibit_size_directive)					\
      ASM_OUTPUT_MEASURED_SIZE (FILE, FNAME);				\
    vos_ix86_output_dummy_block_map_entry (FILE);			\
  } while (0)

/* The following constants are used in generating block_maps.  */

#define TDESC_TAD_BODY      0
#define TDESC_TAD_PROLOGUE  1
#define TDESC_TAD_EPILOGUE  2
#define TDESC_TAD_BODYPLUS4 3

#define TDESC_NULL_ENTRY_BLOCK_ADDR 0

/* The following entry_block information is derived from VOS's
   entry_block_t.incl.c include file.  */

#define LONGMAP
#define VOS_NULL_PTR ((void *) 1)

/* The following structure is in big-endian byte and bit order.  */

typedef struct LONGMAP
{
     void                    *symtab_addr;
     void                    *block_node_addr;
     long                     frame_size;
     long                     reg_save_area_offset;
  /* struct
     {
          unsigned            entry_block_ptr_saved : 1;
          unsigned            on_unit_ptr_saved : 1;
          unsigned            display_ptr_saved : 1;
          unsigned            orig_frame_end_ptr_saved : 1;
          unsigned            fp_in_reg      : 1;
          unsigned            ebp_saved      : 1;
          unsigned            ebx_saved      : 2;
          unsigned            esi_saved      : 2;
          unsigned            edi_saved      : 2;
          unsigned            rtn_buffer_handling : 2;
          unsigned            rtn_pointer_type : 2;
          unsigned            ds_saved       : 1;
          unsigned            es_saved       : 1;
          unsigned            glue_code      : 1;
          unsigned            mbz            : 10;
          unsigned            prologue_epilogue_type : 3;
     } */
     unsigned long            flags2;

#define entry_block_ia32_flags2_entry_block_saved 0x80000000
#define entry_block_ia32_flags2_on_unit_ptr_saved 0x40000000
#define entry_block_ia32_flags2_display_ptr_saved 0x20000000
#define entry_block_ia32_flags2_orig_frame_end_ptr_saved 0x10000000
#define entry_block_ia32_flags2_fp_in_reg 0x08000000
#define entry_block_ia32_flags2_ebp_saved 0x04000000
#define entry_block_ia32_flags2_ebx_saved_mask 0x03000000
#define entry_block_ia32_flags2_ebx_saved_shift 24
#define entry_block_ia32_flags2_esi_saved_mask 0x00c00000
#define entry_block_ia32_flags2_esi_saved_shift 22
#define entry_block_ia32_flags2_edi_saved_mask 0x00300000
#define entry_block_ia32_flags2_edi_saved_shift 20
#define entry_block_ia32_flags2_rtn_buffer_handling_mask 0x000c0000
#define entry_block_ia32_flags2_rtn_buffer_handling_shift 18
#define entry_block_ia32_flags2_rtn_pointer_type_mask 0x00030000
#define entry_block_ia32_flags2_rtn_pointer_type_shift 16
#define entry_block_ia32_flags2_ds_saved 0x00008000
#define entry_block_ia32_flags2_es_saved 0x00004000
#define entry_block_ia32_flags2_glue_code 0x00002000
#define entry_block_ia32_flags2_mbz_mask 0x00001ff8
#define entry_block_ia32_flags2_mbz_shift 3
#define entry_block_ia32_flags2_prologue_epilogue_type_mask 0x00000007
#define entry_block_ia32_flags2_prologue_epilogue_type_shift 0

     unsigned short           flags;

#define entry_block_ia32_flags_is_subroutine 0x8000
#define entry_block_ia32_flags_is_function 0x4000
#define entry_block_ia32_flags_main     0x2000
#define entry_block_ia32_flags_support  0x1000
#define entry_block_ia32_flags_kernel   0x0800
#define entry_block_ia32_flags_has_fac  0x0400
#define entry_block_ia32_flags_fault_handler 0x0200
#define entry_block_ia32_flags_command_args 0x0100
#define entry_block_ia32_flags_signaller 0x0080
#define entry_block_ia32_flags_full_table 0x0040
#define entry_block_ia32_flags_save_registers 0x0020
#define entry_block_ia32_flags_pop      0x0010
#define entry_block_ia32_flags_unwinder 0x0008
#define entry_block_ia32_flags_mbz_mask 0x0007
#define entry_block_ia32_flags_mbz_shift 0


     short                    fap_offset;
     short                    frame_end_size;
     short                    n_args;
     struct
     {
       short                  len;
       char                   str[34];
     } name;
} entry_block_ia32;

/* Named constants for IA32 prologue_epilogue types, return types and return
   buffer pointer types */
/* Prologue_epilogue types:  2 is type generated by gcc. 
   Type 3 is generated by VOS compilers and all VOS assembly language code.
   Type 1 is for standard, but no compilers of ours are expected to generate
   them. */

#define PROLOGUE_EPILOGUE_TYPE1         (1)
#define PROLOGUE_EPILOGUE_TYPE2         (2)
#define PROLOGUE_EPILOGUE_TYPE3         (3)

/* Return pointer type  is as follows:
     0    32-bit near return pointer
     1    64-bit far return pointer
     2    Interrupt handler: procedure has far return pointer and expects
          a saved EFLAGS register
     3    Interrupt handler: procedure has far return pointer, saved EFLAGS
          register and an error code.
*/

#define RTN_POINTER_NEAR                (0)
#define RTN_POINTER_FAR                 (1)
#define RTN_POINTER_INTERRUPT           (2)
#define RTN_POINTER_INTERRUPT_ERRCODE   (3)

/* Return buffer pointer handling:  0 means no return buffer pointer,
   1 means it is removed from stack in prologue, 2 means removed from
   stack in epilogue */

#define RTN_BUFFER_NONE                 (0)
#define RTN_BUFFER_PROLOGUE             (1)
#define RTN_BUFFER_EPILOGUE             (2)

/* Specfile stuff. */

#undef TARGET_OS_CPP_BUILTINS
#define TARGET_OS_CPP_BUILTINS()				\
  do								\
    {								\
	builtin_assert ("system=vos");				\
								\
	builtin_define ("__IA32__");				\
								\
	if (!SUPPORT_OTHER_ENDIANNESS)				\
	  builtin_define ("__LITTLE_ENDIAN__");			\
								\
	if (TARGET_PENTIUM4)					\
	  builtin_define ("__PENTIUM4__");			\
								\
	builtin_define ("__VOS__=15");				\
	builtin_define ("_UX_SETJMP");				\
	builtin_define ("__NO_GENERIC_FUNCTIONS__");		\
								\
	if ((c_language != clk_c) || !preprocessing_trad_p())	\
	  builtin_define ("__PROTOTYPES__");			\
								\
	if (!preprocessing_asm_p())				\
	  if (!flag_iso || !pedantic)				\
	    builtin_define ("$longmap=");			\
								\
	if (flag_signed_char)					\
	  builtin_define ("__CHAR_IS_SIGNED__");		\
    }								\
  while (0)

/* Linking specs. */

#undef MD_EXEC_PREFIX
#define MD_EXEC_PREFIX "/system/command_library/"

#undef LINK_SPEC
#define LINK_SPEC ""

#undef LIB_SPEC
#define LIB_SPEC ""

#undef LINK_GCC_C_SEQUENCE_SPEC
#define LINK_GCC_C_SEQUENCE_SPEC "%G %L"

#undef STANDARD_STARTFILE_PREFIX_1
#undef STANDARD_STARTFILE_PREFIX_2
#define STANDARD_STARTFILE_PREFIX_1 ""
#define STANDARD_STARTFILE_PREFIX_2 ""

#undef STARTFILE_SPEC
#define STARTFILE_SPEC \
 "-object_modules_before %{!shared:s_start_c_program.obj%s} crti.o%s"

#undef ENDFILE_SPEC
#define ENDFILE_SPEC "-object_modules_after crtn.o%s"

/* Tell gcc how to invoke the VOS binder.  This spec is cloned from
   link_command_spec in gcc.c.  The %-sequences it uses are:
     %l   LINK_SPEC
     %X   accumulated linker options from compilations
     %S   STARTFILE_SPEC
     %o   all object file names
     %G   LIBGCC_SPEC 
     %L   LIB_SPEC
     %(link_libgcc) LINK_LIBGCC_SPEC (expands to %D)
     %E   ENDFILE_SPEC
   These are the gcc command-line options that get passed to the
   linker:
     -o   name output file
     -e   define entry point
     -r   create a relocatable .o output file
     -s   strip symbol table
     -l   archive library name (may be repeated)
     -L   archive library search directory (may be repeated)
   Note the -l and -L are more like arguments than options, since they
   may be repeated, and their position in the command line is significant. */

#define LINKER_NAME "bind"

#define LINK_COMMAND_SPEC \
"%{!fsyntax-only:%{!c:%{!M:%{!MM:%{!E:%{!S:\
 %(linker)\
 -gcc_rules\
 -no_dynamic_tasking\
 %l\
 " LINK_PIE_SPEC "\
 %X\
 %{o*:-pm_name %*}\
 %{!o*:-pm_name %b}\
 %{e*:-entry %*}\
 %{r:%eThe ld -r option is not supported on VOS\n}\
 %{nostdlib|nodefaultlibs:-no_library}\
 %{!s:-retain_all} %{s:-no_table}\
 %{shared}\
 %{!static:-Bdynamic}\
 %{symbolic:-Bsymbolic}\
 %{--help:-usage}\
 %o\
 %{!nostdlib:%{!nodefaultlibs:%(link_gcc_c_sequence)}}\
 %{!nostdlib:%{!nostartfiles:%S}}\
 %{!nostdlib:%{!nostartfiles:%E}}\
 %{L*:-search %*}\
 %(link_libgcc)\
 \n\
}}}}}}"

/* Define this if system has no math library.  This inhibits
   automatic inclusion of "-lm" on the g++ command line. */
#define MATH_LIBRARY ""
#define MATH_LIBRARY_PROFILE ""
