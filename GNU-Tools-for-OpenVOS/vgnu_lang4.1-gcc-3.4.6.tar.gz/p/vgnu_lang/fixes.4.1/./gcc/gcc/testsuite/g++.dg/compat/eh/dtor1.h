struct A {
  ~A();
};

struct B: public A {
  ~B();
};
