/*  +++begin copyright+++ *******************************  */
/*                                                         */
/*  STRATUS CONFIDENTIAL INFORMATION: CLASS II             */
/*  COPYRIGHT (c) 2002 Stratus Technologies Bermuda Ltd.   */
/*  All Rights Reserved.                                   */
/*                                                         */
/*  This  program  contains  confidential and proprietary  */
/*  information of Stratus Technologies Bermuda Ltd., and  */
/*  any reproduction, disclosure, or use in whole  or  in  */
/*  part  is  expressly  prohibited,  except  as  may  be  */
/*  specifically authorized by prior written agreement or  */
/*  permission of Stratus.                                 */
/*                                                         */
/*  +++end copyright+++ *********************************  */

/* Beginning of modification history */
/* Written 03-04-21 by Paul Green.  */
/* End of modification history */

#define _POSIX_C_SOURCE 200112L
#include <grp.h>

int s$c_n_setgroup_calls = 0;

int setgroups (int ngroups, const gid_t *groupset)
{
     s$c_n_setgroup_calls++;
     return 0;
}

